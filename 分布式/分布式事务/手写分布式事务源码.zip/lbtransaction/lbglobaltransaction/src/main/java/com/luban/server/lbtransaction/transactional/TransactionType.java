package com.luban.server.lbtransaction.transactional;

public enum TransactionType {

    commit, rollback;
}
