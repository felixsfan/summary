export const TableMap={
    'MermberDayTable':'t_prepay_stat_YYYYMM_add'
}