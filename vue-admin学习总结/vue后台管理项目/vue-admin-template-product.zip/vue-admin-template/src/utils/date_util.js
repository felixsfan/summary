// 补零函数
export function doHandleZero(zero) {
    var date = zero;
    if (zero.toString().length == 1) {
        date = "0" + zero;
    }
    return date;
}
// 获取每个月一号
export function getDate() {
    var myDate = new Date();
    var tYear = myDate.getFullYear()
    var tMonth = myDate.getMonth()
    tMonth = doHandleZero(tMonth + 1)

    return tYear + "-" + tMonth + "-01"
}
// 获取当前年-月-日
export function getDateNow() {
    var myDate = new Date();
    var tYear = myDate.getFullYear()
    var tMonth = myDate.getMonth()
    var tDay = myDate.getDate()
    tMonth = doHandleZero(tMonth + 1)
    tDay = doHandleZero(tDay)

    return tYear + "-" + tMonth + "-" + tDay
}

export function getDayAll(starDay, endDay) {
        
    　　 var arr = [];
        var dates = [];
    
        // 设置两个日期UTC时间
    　　　var db = new Date(starDay);
    　　　var de = new Date(endDay);
    
        // 获取两个日期GTM时间
    　　　var s = db.getTime() - 24 * 60 * 60 * 1000;
    　　　var d = de.getTime() - 24 * 60 * 60 * 1000;
    
        // 获取到两个日期之间的每一天的毫秒数
    　　　for (var i = s; i <= d;) {
    　　　　　　i = i + 24 * 60 * 60 * 1000;
            arr.push(parseInt(i))
    　　　}
        
        // 获取每一天的时间  YY-MM-DD
        for( var j in arr ){
            var time = new Date(arr[j]);
            var year = time.getFullYear(time);
            var mouth = (time.getMonth() + 1)>=10?(time.getMonth() + 1):('0'+(time.getMonth() + 1));
            var day = time.getDate()>=10?time.getDate():('0'+time.getDate());
            var YYMMDD = year + '-' + mouth + '-' + day;
            dates.push(YYMMDD)
        }
        
        return dates
    }
