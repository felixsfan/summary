<template>
  <div class="app-container">
    <el-dialog
      title="查询"
      :visible.sync="isShow">
    <selectdata-form
      :formLabel="operateFormLabel"
      :form="operateForm"
      :inline="true"
      ref="form"
    ></selectdata-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="cancel">取消</el-button>
      <el-button type="primary" @click="confirm">查询</el-button>
    </div>
    </el-dialog>
    <div class="manage-header">
      <el-button type="primary" @click="simpleSelect">简单查询</el-button>
      <selectdata-form
        :formLabel="searchFormLabel"
        :form="searchForm"
        :inline="true"
        ref="form"
        >
        <el-button type="primary" @click="complexSelect">复杂查询</el-button>
      </selectdata-form>
    </div>
    <selectdata-table
      :tableData="tableData"
      :tableLabel="tableLabel"
      :config="config"
      @changePage="getList">
    </selectdata-table>
  </div>
</template>
<script>
  import { getField,getDayMemberData } from '@/api/select/gettableinformation'
  import SelectdataForm from '@/views/form/SelectdataForm'
  import SelectdataTable from '@/views/table/SelectdataTable'
  import {TableMap} from '@/utils/tablemap'
  export default {
    components: { SelectdataForm,SelectdataTable },
    data() {
      return {
        isShow: false,
        fields: [],
        operateFormLabel:[
          {
            model: 'selectfield',
            label: '选择列名',
            type: 'select',
            opts: []
          },
          {
            model: 'tablename',
            label: '表名',
            type: 'input',
            disabled:true
          },
          {
            model: 'date',
            label: '数据日期',
            type: 'date'
          },
          {
            model: 'channel',
            label: '渠道ID',
            type: 'input'
          },
          {
            model: 'spoaid',
            label: '业务代码',
            type: 'input'
          }
        ],
        operateForm:{
          selectfield: [],
          tablename:TableMap['MermberDayTable'],
          date:"",
          datamonth:"",
          defermonth:"",
          channel:"",
          spoaid:""
        }
        ,
        searchFormLabel:[
          {
              model: 'textarea',
              label: '查询sql',
              type: 'textarea'
          }
        ],
        searchForm:{
          textarea: ""
        },
        tableData: [],
        tableLabel:[],
        config: {
          page : 1,
          total : 30
        }
      };
    },
    created (){
      this.getTableField();
      this.getFormSelect()
      },
    methods: {
      confirm() {
        this.isShow = false
        this.getFormSelect()
      },
      cancel() {
        this.isShow = false
      },
      simpleSelect() {
        this.isShow = true
        this.operateForm = {
          selectfield: [],
          tablename:TableMap['MermberDayTable'],
          date:"",
          datamonth:"",
          defermonth:"",
          channel:"",
          spoaid:""
        },
        this.tableLabel=[]
      },
      complexSelect() {

      },
      getList() {
      },
      getTableField() {
        new Promise((resolve, reject) => {
          getField({ tablename:TableMap['MermberDayTable']}).then(response => {
          const { data } = response
          resolve(data)
          }).catch(error => {
            reject(error)
          })
        }).then((data) => {
            this.fields = data
            this.getSelectList()
          }).catch((error) => {
            console.log(error)
          })
      },
      // 添加可以查询的列名
      getSelectList() {
        for(let item=0;item<this.fields.length;item++){
          let field = this.fields[item]
          this.operateFormLabel[0].opts.push({'label':field,'value':field})
        }
      },
      // 添加要显示的table表格的列名
      getTableList(list) {
         for(var i in list){
           this.tableLabel.push({'label':list[i],'prop':list[i]})
         }
      },
      getFormSelect() {
         new Promise((resolve, reject) => {
          getDayMemberData(this.operateForm).then(response => {
              const { data } = response
              this.tableData = data.day_member_data
              this.getTableList(data.fieldslist)
              this.config.total = this.tableData.length  //分页总数
              console.log(data)
              resolve()
            }).catch(error => {
              reject(error)
            })
         })
      }
    }
  };
</script>
<style lang="sass" scoped>
.manage-header 
	display: flex 
	justify-content: space-between 
	align-items: center
</style>