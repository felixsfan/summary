<template>
  <div class="common-table">
    <el-table :data="tableData.slice((config.page-1)*10,config.page*10)" stripe>
      <el-table-column
        v-for="item in tableLabel"
        :key="item.label"
        :label="item.label"
        :width="item.width ? item.width : ''"
        show-overflow-tooltip
      >
        <template slot-scope="scope">
          <span style="margin-left: 10px">{{ scope.row[item.prop] }}</span>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      class="pager"
      layout="prev, pager, next"
      :total="config.total"
      :current-page.sync="config.page"
      :page-size="10"
      @current-change="changePage"
    />
  </div>
</template>
<script>
export default {
  name: 'SelectdataTable',
  props: {
    tableData: Array,
    tableLabel: Array,
    config: Object
  },
  data() {
    return {}
  },
  methods: {
    changePage(page) {
      this.$emit('changePage', page)
    }
  }
}
</script>
<style lang="sass" scoped>
.common-table
	height: calc(100%-62px)
	background-color: #fff
	position: relative
	.pager
		position: absolute
		bottom: -10
		right: 20px
</style>
