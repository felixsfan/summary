<template>
  <div class="common-table">
    <el-table :data="tableData.slice((config.page-1)*10,config.page*10)" stripe>
      <el-table-column
        v-for="item in tableLabel"
        :key="item.label"
        :label="item.label"
        :width="item.width ? item.width : '' "
        show-overflow-tooltip
      >
        <template slot-scope="scope">
          <span style="margin-left: 10px">{{ scope.row[item.prop] }}</span>
        </template>
      </el-table-column>
      <el-table-column class-name="status-col" label="Status" align="center">
        <template slot-scope="scope">
          <el-tag v-if="scope.row.status=='published'" :type="scope.row.status | statusFilter">成功</el-tag>
          <el-tag v-if="scope.row.status=='running'" :type="scope.row.status | statusFilter">运行中</el-tag>
          <el-tag v-if="scope.row.status=='failed'" :type="scope.row.status | statusFilter">失败</el-tag>
        </template>
      </el-table-column>
      <el-table-column align="center" label="运行">
        <template slot-scope="scope">
          <el-button :class="scope.row.status === 'running' ? 'el-icon-loading' : 'el-icon-video-play'" type="text"/>
        </template>
      </el-table-column>
      <el-table-column label="操作" min-width="180">
        <template slot-scope="scope">
          <el-button size="mini" @click="handleEdit(scope.row)">编辑</el-button>
          <el-button size="mini" type="danger" @click="handleDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      class="pager"
      layout="prev, pager, next"
      :total="config.total"
      :current-page.sync="config.page"
      :page-size="10"
      @current-change="changePage"
    />
  </div>
</template>
<script>
export default {
  name: 'RundataTable',
  filters: {
    statusFilter(status) {
      const statusMap = {
        published: 'success',
        running: 'gray',
        failed: 'danger'
      }
      return statusMap[status]
    }
  },
  props: {
    tableData: Array,
    tableLabel: Array,
    config: Object
  },
  data() {
    return {}
  },
  methods: {
    handleEdit(row) {
      this.$emit('edit', row)
    },
    handleDelete(row) {
      this.$emit('del', row)
    },
    changePage(page) {
      this.$emit('changePage', page)
    }
  }
}
</script>
<style lang="sass" scoped>
.common-table
	height: calc(100%-62px)
	background-color: #fff
	position: relative
	.pager
		position: absolute
		bottom: -10
		right: 20px
</style>
