<template>
  <div style="padding:30px;">
    <router-view />
  </div>
</template>
