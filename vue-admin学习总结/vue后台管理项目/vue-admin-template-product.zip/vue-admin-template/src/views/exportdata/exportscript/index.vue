<template>
  <div class="dashboard-editor-container">
    <el-row style="background:#fff;padding:16px 16px 0;margin-bottom:32px;">
    </el-row>

    <el-row :gutter="32">
      <el-col :xs="24" :sm="24" :lg="8">
        <div class="chart-wrapper">
          <exportdata-form
            :formLabel="operateFormLabel1"
            :form="operateForm1"
            :inline="true"
            ref="form">
          <template v-slot:footer>
            <el-button type="primary" @click="exportdata(this.operateForm1)">导出</el-button>
          </template>
          </exportdata-form>
        </div>
      </el-col>
      <el-col :xs="24" :sm="24" :lg="8">
        <div class="chart-wrapper">
          <exportdata-form
            :formLabel="operateFormLabel2"
            :form="operateForm2"
            :inline="true"
            ref="form">
          <template v-slot:footer>
            <el-button type="primary" @click="exportdata(this.operateForm2)">导出</el-button>
          </template>
          </exportdata-form>
        </div>
      </el-col>
      <el-col :xs="24" :sm="24" :lg="8">
        <div class="chart-wrapper">
          <exportdata-form
            :formLabel="operateFormLabel3"
            :form="operateForm3"
            :inline="true"
            ref="form">
          <template v-slot:footer>
            <el-button type="primary" @click="exportdata(this.operateForm3)">导出</el-button>
          </template>
          </exportdata-form>
        </div>
      </el-col>
    </el-row>
    <el-row :gutter="32">
      <el-col :xs="24" :sm="24" :lg="8">
        <div class="chart-wrapper">
          <exportdata-form
            :formLabel="operateFormLabel4"
            :form="operateForm4"
            :inline="true"
            ref="form">
          <template v-slot:footer>
            <el-button type="primary" @click="exportdata(this.operateForm4)">导出</el-button>
          </template>
          </exportdata-form>
        </div>
      </el-col>
      <el-col :xs="24" :sm="24" :lg="8">
        <div class="chart-wrapper">
          <exportdata-form
            :formLabel="operateFormLabel5"
            :form="operateForm5"
            :inline="true"
            ref="form">
          <template v-slot:footer>
            <el-button type="primary" @click="exportdata(this.operateForm5)">导出</el-button>
          </template>
          </exportdata-form>
        </div>
      </el-col>
      <el-col :xs="24" :sm="24" :lg="8">
        <div class="chart-wrapper">
          <exportdata-form
            :formLabel="operateFormLabel6"
            :form="operateForm6"
            :inline="true"
            ref="form">
          <template v-slot:footer>
            <el-button type="primary" @click="exportdata(this.operateForm6)">导出</el-button>
          </template>
          </exportdata-form>
        </div>
      </el-col>
    </el-row>

  </div>
</template>

<script>
import ExportdataForm from '@/views/form/Exportdataform'
import model from './model'
import { export_file } from '@/api/export_data/export_data'
export default {
  name: 'DashboardAdmin',
  components: {
    ExportdataForm
  },
  data() {
    return {
      operateFormLabel1: model.operateFormLabel1,
      operateForm1: model.operateForm1,
      operateFormLabel2: model.operateFormLabel2,
      operateForm2: model.operateForm2,
      operateFormLabel3: model.operateFormLabel3,
      operateForm3: model.operateForm3,
      operateFormLabel4: model.operateFormLabel4,
      operateForm4: model.operateForm4,
      operateFormLabel4: model.operateFormLabel4,
      operateForm4: model.operateForm4,
      operateFormLabel5: model.operateFormLabel5,
      operateForm5: model.operateForm5,
      operateFormLabel6: model.operateFormLabel6,
      operateForm6: model.operateForm6
    }
  },
  methods: {
    exportdata(form) {
      new Promise((resolve, reject) => {
        export_file(form).then(data => {
            const blob = new Blob([data])
            const link = document.createElement('a')
            link.download = form.scriptname // a标签添加属性
            link.style.display = 'none'
            link.href = URL.createObjectURL(blob)
            document.body.appendChild(link)
            link.click() // 执行下载
            URL.revokeObjectURL(link.href)  // 释放 bolb 对象
            document.body.removeChild(link) // 下载完成移除元素
            resolve()
          }).catch(error => {
            reject(error)
          })
        })
      }
  }
}
</script>

<style lang="scss" scoped>
.dashboard-editor-container {
  padding: 32px;
  background-color: rgb(240, 242, 245);
  position: relative;

  .chart-wrapper {
    background: #fff;
    padding: 16px 16px 0;
    margin-bottom: 32px;
  }
}

@media (max-width:1024px) {
  .chart-wrapper {
    padding: 8px;
  }
}
</style>
