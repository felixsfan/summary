export default {
    operateFormLabel1: [
        {
            model: 'scriptname',
            label: '脚本名称',
            type: 'inputdisable'
        },
        {
            model: 'descripe',
            label: '描述',
            type: 'textarea'
        },
        {
            model: 'sett_group',
            label: '结算组ID',
            type: 'input'
        },
        {
            model: 'sett_month',
            label: '结算月份',
            type: 'month'
        }
    ],
    operateForm1: {
        scriptname: "non_mobile_basic_data",
        descripe: "非手机按天按天、按月结算组日期维度",
        sett_group: "",
        sett_month: ""
    },
    operateFormLabel2: [
        {
            model: 'scriptname',
            label: '脚本名称',
            type: 'inputdisable'
        },
        {
            model: 'descripe',
            label: '描述',
            type: 'textarea'
        },
        {
            model: 'sett_month',
            label: '结算月份',
            type: 'month'
        }
    ],
    operateForm2: {
        scriptname: "qq_defer",
        descripe: "递延余额",
        sett_month: ""
    },
    operateFormLabel3: [
        {
            model: 'scriptname',
            label: '脚本名称',
            type: 'inputdisable'
        },
        {
            model: 'descripe',
            label: '描述',
            type: 'textarea'
        },
        {
            model: 'sett_group',
            label: '结算组ID',
            type: 'input'
        },
        {
            model: 'sett_month',
            label: '结算月份',
            type: 'month'
        }
    ],
    operateForm3: {
        scriptname: "refund",
        descripe: "导出结算组月份维度退款",
        sett_group: "",
        sett_month: ""
    },
    operateFormLabel4: [
        {
            model: 'scriptname',
            label: '脚本名称',
            type: 'inputdisable'
        },
        {
            model: 'descripe',
            label: '描述',
            type: 'textarea'
        },
        {
            model: 'sett_month',
            label: '结算月份',
            type: 'month'
        }
    ],
    operateForm4: {
        scriptname: "tme_defer",
        descripe: "tme递延余额数据",
        sett_month: ""
    },
    operateFormLabel5: [
        {
            model: 'scriptname',
            label: '脚本名称',
            type: 'inputdisable'
        },
        {
            model: 'descripe',
            label: '描述',
            type: 'textarea'
        },
        {
            model: 'sett_month',
            label: '递延月份',
            type: 'month'
        }
    ],
    operateForm5: {
        scriptname: "all_defer",
        descripe: "AR提取全量递延数据，数据月份不限，递延到未来的数据",
        defer_month: ""
    },
    operateFormLabel6: [
        {
            model: 'scriptname',
            label: '脚本名称',
            type: 'inputdisable'
        },
        {
            model: 'descripe',
            label: '描述',
            type: 'textarea'
        },
        {
            model: 'sett_month',
            label: '结算月份',
            type: 'month'
        }
    ],
    operateForm6: {
        scriptname: "video_defer",
        descripe: "video_member_defer",
        sett_month: ""
    }
}