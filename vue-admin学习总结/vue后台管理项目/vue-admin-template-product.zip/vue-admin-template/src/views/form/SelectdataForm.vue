<template>
  <!--是否行内表单-->
  <el-form ref="form" label-width="100px" :model="form" :inline="inline">
    <!--标签显示名称-->
    <el-form-item v-for="item in formLabel" :key="item.label" :label="item.label">
      <!--根据type来显示是什么标签-->
      <el-input
        :placeholder="'请输入' + item.label"
        v-if="item.type === 'input'"
        v-model="form[item.model]"
        :disabled="item.disabled"
      ></el-input>
      <el-switch v-if="item.type === 'switch'" v-model="form[item.model]"></el-switch>
      <el-date-picker
        type="date"
        placeholder="选择日期"
        v-if="item.type === 'date'"
        value-format="yyyy-MM-dd"
        format="yyyy 年 MM 月 dd 日"
        v-model="form[item.model]"
      >
      </el-date-picker>
      <el-date-picker
        type="month"
        placeholder="选择月份"
        v-if="item.type === 'month'"
        value-format="yyyy-MM"
        format="yyyy 年 MM 月"
        v-model="form[item.model]"
      >
      </el-date-picker>
      <el-select 
        v-if="item.type === 'select'"
        :placeholder="'请选择' + item.label" 
        v-model="form[item.model]"
      >
          <!--如果是select或者checkbox 、Radio就还需要选项信息-->
        <el-option v-for="item in item.opts" :key="item.value" :label="item.label" :value="item.value"></el-option>
      </el-select>
      <el-input class="textarea" type="textarea" :autosize="{ minRows: 2, maxRows: 5}" placeholder='请输入sql' v-if="item.type === 'textarea'" v-model="form[item.model]">
      </el-input >
    </el-form-item>
    <slot></slot>
  </el-form>
</template>
<script>
  export default {
    name: 'SelectdataForm',
    // formLabel 是标签数据
    props: {
      formLabel: Array,
      form:Object,
      inline:Boolean 
    }
  };
</script>
<style lang="sass" scoped>
.textarea
  width: 300px
</style>