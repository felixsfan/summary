<template>
  <div class="dashboard-editor-container">
    <el-row>
      <el-col :span="16" :offset="4">
        <div>
          <charts-line-form
          :formLabel="formLabel"
          :form="operateForm"
          :inline="true"
          ref="form">
            <el-button 
              type="primary" 
              @click="gettablecount()" 
              v-loading.fullscreen.lock="fullscreenLoading"
            >查询
            </el-button>
          </charts-line-form>
        </div>
      </el-col>
    </el-row>
    <el-row :gutter="32">
      <el-col :xs="24" :sm="24" :lg="8">
        <div class="chart-wrapper">
          <line-chart :chart-data="lineChartOneData" />
        </div>
      </el-col>
      <el-col :xs="24" :sm="24" :lg="8">
        <div class="chart-wrapper">
          <line-chart :chart-data="lineChartTwoData" />
        </div>
      </el-col>
      <el-col :xs="24" :sm="24" :lg="8">
        <div class="chart-wrapper">
          <line-chart :chart-data="lineChartThreeData" />
        </div>
      </el-col>
      <el-col :xs="24" :sm="24" :lg="8">
        <div class="chart-wrapper">
          <line-chart :chart-data="lineChartFourData" />
        </div>
      </el-col>
      <el-col :xs="24" :sm="24" :lg="8">
        <div class="chart-wrapper">
          <line-chart :chart-data="lineChartFiveData" />
        </div>
      </el-col>
      <el-col :xs="24" :sm="24" :lg="8">
        <div class="chart-wrapper">
          <line-chart :chart-data="lineChartSixData" />
        </div>
      </el-col>
      <el-col :xs="24" :sm="24" :lg="8">
        <div class="chart-wrapper">
          <line-chart :chart-data="lineChartSevenData" />
        </div>
      </el-col>
      <el-col :xs="24" :sm="24" :lg="8">
        <div class="chart-wrapper">
          <line-chart :chart-data="lineChartEightData" />
        </div>
      </el-col>
      <el-col :xs="24" :sm="24" :lg="8">
        <div class="chart-wrapper">
          <line-chart :chart-data="lineChartNineData" />
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { getDataCount } from '@/api/echarts/get_table_count'
import ChartsLineForm from '@/views/form/ChartsLineForm'
import LineChart from './components/LineChart'
import { getDate,getDateNow } from '@/utils/date_util'

export default {
  name: 'DashboardAdmin',
  components: {
    LineChart,ChartsLineForm
  },
  data() {
    return {
      fullscreenLoading:false,
      formLabel:[
        {
          model: 'begindate',
          label: '开始日期',
          type: 'date'
        },
        {
          model: 'enddate',
          label: '结束日期',
          type: 'date'
        }],
      operateForm:{
        begindate:'',
        enddate:''
      },
      lineChartOneData:{
          table_name:'',
          dateData: [],
          countData: []
      },
      lineChartTwoData:{
          table_name:'',
          dateData: [],
          countData: []
      },
      lineChartThreeData:{
          table_name:'',
          dateData: [],
          countData: []
      },
      lineChartFourData:{
          table_name:'',
          dateData: [],
          countData: []
      },
      lineChartFiveData:{
          table_name:'',
          dateData: [],
          countData: []
      },
      lineChartSixData:{
          table_name:'',
          dateData: [],
          countData: []
      },
      lineChartSevenData:{
          table_name:'',
          dateData: [],
          countData: []
      },
      lineChartEightData:{
          table_name:'',
          dateData: [],
          countData: []
      },
      lineChartNineData:{
          table_name:'',
          dateData: [],
          countData: []
      }
    }
  },
  created(){
    this.operateForm.begindate=getDate()
    this.operateForm.enddate=getDateNow()
    this.gettablecount(this.operateForm.begindate,this.operateForm.enddate)
  },
  methods: {
    gettablecount(){
      this.fullscreenLoading=true
      getDataCount(this.operateForm).then(response => {
          const { data } = response
          let options = [this.lineChartOneData,this.lineChartTwoData,this.lineChartThreeData,this.lineChartFourData,this.lineChartFiveData,this.lineChartSixData,this.lineChartSevenData,this.lineChartEightData,this.lineChartNineData]
          let i = 0
          for (var tablename in data){
            var that = options[i]
            that.table_name=tablename
            that.dateData=data[tablename].date_count
            that.countData=data[tablename].data_count
            i++
          this.fullscreenLoading=false
          }
        }).catch(error => {
          this.fullscreenLoading=false
          console.log(error)
        })
    }
  }
}
</script>

<style lang="scss" scoped>
.dashboard-editor-container {
  padding: 32px;
  background-color: rgb(240, 242, 245);
  position: relative;

  .chart-wrapper {
    background: #fff;
    padding: 16px 16px 0;
    margin-bottom: 32px;
  }
}
.el-row {
  margin-bottom: 20px;
  &:last-child {
    margin-bottom: 0;
  }
}
.el-col {
  border-radius: 4px;
}
.grid-content {
  border-radius: 4px;
  min-height: 300px;
}
@media (max-width:1024px) {
  .chart-wrapper {
    padding: 8px;
  }
}
</style>
