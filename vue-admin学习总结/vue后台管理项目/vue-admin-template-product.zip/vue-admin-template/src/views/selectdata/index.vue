<template>
  <div>
    <el-row style="background:#fff;padding:16px 16px 0;margin-bottom:12px;">
      <el-col :span="24">
        <selectdata-form
          :formLabel="operateFormLabel"
          :form="operateForm"
          :inline="true"
          ref="exportForm"
        >
        <el-form-item><el-button type="primary" @click="submitForm()" v-loading.fullscreen.lock="fullscreenLoading">查询</el-button></el-form-item>
        <el-form-item><el-button @click="resetForm()">重置</el-button></el-form-item>
        </selectdata-form>
      </el-col>
    </el-row>
    <el-row>
      <sqleditor :value="this.operateForm.sql_template" :language="x-sql" @change="changesql"></sqleditor>
    </el-row>
    <el-row style="background:#fff;padding:16px 30px 0;margin-bottom:32px;">
      <selectdata-table
      :tableData="tableData"
      :tableLabel="tableLabel"
      :config="config"
      >
      </selectdata-table>
    </el-row>
  </div>
</template>
<script>
  import SelectdataForm from '@/views/form/SelectdataForm'
  import SelectdataTable from '@/views/table/SelectdataTable'
  import sqleditor from '@/views/components-demo/sqleditor'
  import { gettableData,gettxtData,getexeclData } from '@/api/select/selectdata'
  import { Message } from 'element-ui'
  export default {
    components: { SelectdataForm, SelectdataTable, sqleditor },
    data() {
      return {
        inline: false,
        fullscreenLoading: false,
        operateFormLabel:[
          {
            model: 'connection',
            label: '数据库连接',
            type: 'select',
            opts: [
              {
                value: 'sett_db',
                label: 'sett_db'
              }, {
                value: 'tj_db',
                label: 'tj_db'
              }, {
                value: 'sett_db_latin1',
                label: 'sett_db_latin1'
              }, {
                value: 'tj_db_latin1',
                label: 'tj_db_latin1'
              }
            ]
          },
          {
            model: 'export_type',
            label: '显示类型',
            type: 'select',
            opts: [
              {
                value: 'table',
                label: '页面'
              }, {
                value: 'txt',
                label: 'txt'
              }, {
                value: 'execl',
                label: 'execl'
              }
            ]
          }
        ],
        operateForm:{
          connection: '',
          export_type: '',
          sql_template: '',
        },
        tableData : [''],
        tableLabel: [],
        config: {
          page : 1,
          total : 30
        }
      }
    },
    methods: {
      submitForm() {
        if (this.operateForm.sql_template != '' && this.operateForm.connection != '' && this.operateForm.export_type != '') {
          console.log(this.operateForm.connection, this.operateForm.export_type, this.operateForm.sql_template)
          if (this.operateForm.export_type == 'table'){
            this.get_table_data();
          }else if (this.operateForm.export_type == 'txt'){
            this.get_txt_data();
          }else if (this.operateForm.export_type == 'execl'){
            this.get_execl_data();
          }
        } else {
          console.log('error submit!!');
          console.log(this.operateForm.connection, this.operateForm.export_type, this.operateForm.sql_template)
          return false;
        }
      },
      resetForm() {
        this.operateForm.connection='',
        this.operateForm.export_type='',
        this.operateForm.sql_template=''
      },
      changesql(sql) {
        this.operateForm.sql_template = sql
      },
      // 添加要显示的table表格的列名
      addTableList(list) {
         for(var i in list){
           this.tableLabel.push({'label':list[i],'prop':list[i]})
         }
      },
      get_table_data() {
         new Promise((resolve, reject) => {
          this.fullscreenLoading=true
          gettableData(this.operateForm).then(response => {
              const { data } = response
              this.tableLabel = []  //查询结果显示之前先清空
              this.addTableList(data.fieldslist)
              this.tableData = data.select_result
              this.config.total = this.tableData.length  //分页总数
              console.log(data)
              this.fullscreenLoading=false
              resolve()
            }).catch(error => {
              this.fullscreenLoading=false
              reject(error)
            })
         })
      },
      get_txt_data() {
         new Promise((resolve, reject) => {
          let that = this  //this指向会发生变化,这里另外存一个
          that.fullscreenLoading=true
          gettxtData(this.operateForm).then(data => {
              const blob = new Blob([data])
              const r = new FileReader()
              r.readAsText(new Blob([data])) // FileReader的API
              r.onload = function () {
                try {
                    const resData = JSON.parse(this.result)
                    Message({
                      message: resData.data || 'Error',
                      type: 'error',
                      duration: 5 * 1000
                    })
                    that.fullscreenLoading=false  
                    resolve()
                  } catch (err) {
                    console.log(err)
                    let fileName = "non_mobile_sett.txt"
                    // 兼容ie11
                    if (window.navigator.msSaveOrOpenBlob) {
                      try {
                        const blobObject = new Blob([data])
                        window.navigator.msSaveOrOpenBlob(blobObject, fileName)
                      } catch (e) {
                        console.log(e)
                      }
                      that.fullscreenLoading=false  
                      return
                    }
                    let url = window.URL.createObjectURL(new Blob([data]))
                    let link = document.createElement('a')
                    link.style.display = 'none'
                    link.href = url
                    link.setAttribute('download', fileName)
                    document.body.appendChild(link)
                    link.click()
                    that.fullscreenLoading=false  
                    URL.revokeObjectURL(link.href)
                    document.body.removeChild(link)
                    resolve(fileName)
                  }
              }
            }).catch(error => {
              that.fullscreenLoading=false  
              reject(error)
            })
          })
        },
      get_execl_data() {
        // https://segmentfault.com/a/1190000038353617
        // https://blog.csdn.net/qq_37246828/article/details/90080614
        new Promise((resolve, reject) => {
          let that = this  //this指向会发生变化,这里另外存一个
          that.fullscreenLoading=true
          getexeclData(this.operateForm).then(data=> {
                // 有可能下载失败，比如返回{code: 0},但设置了responseType: 'blob'，axios会把data强制转为blob，导致下载undefined.excel（后缀取决于文件类型，这里只是举例）
                // 解决：将已转为blob类型的data转回json格式，判断是否下载成功
                const r = new FileReader()
                r.readAsText(new Blob([data])) // FileReader的API
                r.onload = function () {
                  // 如果JSON.parse(this.result)不报错，说明this.result是json字符串，则可以推测是下载报错情况下返回的对象，类似于{code: 0}
                  // 如果JSON.parse(this.result)报错，说明是下载成功，返回的二进制流，则进入catch进行后续处理
                  try {
                    const resData = JSON.parse(this.result) 
                    // 如果执行到这里，说明下载报错了，进行后续处理
                    Message({
                      message: resData.data || 'Error',
                      type: 'error',
                      duration: 5 * 1000
                    })
                    that.fullscreenLoading=false  
                    resolve()
                  } catch (err) {
                    console.log(err)
                    let fileName = "non_mobile_sett.xlsx"
                    // 兼容ie11
                    if (window.navigator.msSaveOrOpenBlob) {
                      try {
                        const blobObject = new Blob([data])
                        window.navigator.msSaveOrOpenBlob(blobObject, fileName)
                      } catch (e) {
                        console.log(e)
                      }
                      that.fullscreenLoading=false  
                      return
                    }
                    // a标签实现下载
                    let url = window.URL.createObjectURL(new Blob([data]))
                    let link = document.createElement('a')
                    link.style.display = 'none'
                    link.href = url
                    link.setAttribute('download', fileName)
                    document.body.appendChild(link)
                    link.click()
                    that.fullscreenLoading=false  
                    URL.revokeObjectURL(link.href) // 释放URL 对象
                    document.body.removeChild(link)
                    resolve()                 
                  }
                }
            }).catch(data => {
              that.fullscreenLoading=false  
              reject(data)
            })
         })
        } 
      }
    }
</script>