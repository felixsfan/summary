<template>
  <div class="app-container">
    <el-dialog
      :title="operateType === 'add' ? '新增' : '编辑'"
      :visible.sync="isShow">
    <rundata-form
      :formLabel="operateFormLabel"
      :form="operateForm"
      :inline="true"
      ref="form"
    ></rundata-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="isShow = false">取消</el-button>
      <el-button type="primary" @click="confirm">确定</el-button>
    </div>
    </el-dialog>
    <div class="manage-header">
      <el-button type="primary" @click="addTask">+新增</el-button>
      <rundata-form
        :formLabel="formLabel"
        :form="searchForm"
        :inline="true"
        ref="form">
      <el-button type="primary" @click="getList">搜索</el-button>
      </rundata-form>
    </div>
    <rundata-table
      :tableData="tableData"
      :tableLabel="tableLabel"
      :config="config"
      @edit="editTask"
      @del="delTask"
    ></rundata-table>
  </div>
</template>

<script>
import RundataForm from '@/views/form/RundataForm'
import RundataTable from '@/views/table/RundataTable.vue'
import { getAllTask,editTask,addTask,delTask } from '@/api/auto_script/rundata'
import { Message } from 'element-ui'
export default {
  components: { RundataForm, RundataTable },
  data() {
    return {
      // 表单相关
      operateType:'add',
      isShow:false,
      operateFormLabel: [
                    {
                        model: 'taskid',
                        label: '任务ID',
                        type: 'input'
                    },
                    {
                        model: 'describe',
                        label: '描述',
                        type: 'input'
                    },
                    {
                        model: 'path',
                        label: '脚本路径',
                        type: 'input'
                    },
                    {
                        model: 'order',
                        label: '脚本命令',
                        type: 'input'
                    },
                    {
                        model: 'begin',
                        label: '开始日期',
                        type: 'date'
                    },
                    {
                        model: 'end',
                        label: '结束日期',
                        type: 'date'
                    }
                ],
      operateForm: {
        taskid: "",
        describe: "",
        path: "",
        order: "",
        begin: '',
        end: ''
      },
      formLabel:[
        {
          model: "keyword",
          label: '',
          type: 'input'
        }
      ],
      searchForm:{
        keyword:''
      },
      // 列表相关
      tableData : [''],
      tableLabel: [
                {
          label:'任务ID',
          prop:'taskid',
          width:''
        },
               {
          label:'描述',
          prop:'describe',
          width:'200'
        },
        {
          label:'脚本路径',
          prop:'path',
          width:'300'
        },
        {
          label:'脚本命令',
          prop:'order',
          width:'200'
        },
        {
          label:'开始日期',
          prop:'begin',
          width:'200'
        },
        {
          label:'结束日期',
          prop:'end',
          width:'200'
        }
        ],
      config: {
        page : 1,
        total : 30
      }
    }
  },
  created() {
    this.getList()
  },
  methods: {
    confirm() {
       if (this.operateType === 'edit'){
        editTask(this.operateForm).then(response => {
          const { data } = response
          // this.$message  此时this指的不再是Vue，因此不能用this.$message 
          Message({
            message: data,
            type: 'success'
          })
          this.getList()
        }).catch(error => {
          // 失败的提示在返回过滤器request.js里已经做了
          console.log(error)
        });
        this.isShow = false
       }else {
         addTask(this.operateForm).then(response => {
          const { data } = response
          // this.$message  此时this指的不再是Vue，因此不能用this.$message 
          Message({
            message: data,
            type: 'success'
          })
          this.getList()
        }).catch(error => {
          console.log(error)
        });
        this.isShow = false
       }
    },
    addTask() {
      this.isShow = true
      this.operateType = 'add'
      this.operateForm = {
        taskid: "",
        describe: "",
        path: "",
        order: "",
        begin: '',
        end: ''
      }
    },
    editTask(row) {
      this.operateType = 'edit'
      this.isShow = true
      this.operateForm = row
    },
    delTask(row){
       this.$confirm("此操作将永久删除该数据，是否继续？", "提示", {
         confirmButtonTest: "确认",
         cancelButtonTest: "取消",
         type: "warning"
       }).then(() => {
         delTask(row).then(() => {
         this.$message({
           type:'success',
           message: '删除成功'
         })
         this.getList()
         }).catch(error => {
            console.log(error)
          });
       })
    },
    getList() {
      getAllTask().then(response => {
          const { data } = response
          this.tableData = data
          this.config.total = this.tableData.length
          }).catch(error => {
            console.log(error)
          });
    }
  }  
}
</script>
<style lang="sass" scoped>
.manage-header 
	display: flex 
	justify-content: space-between 
	align-items: center
</style>