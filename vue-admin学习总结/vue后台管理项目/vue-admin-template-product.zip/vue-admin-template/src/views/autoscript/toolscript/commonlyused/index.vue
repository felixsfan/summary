<template>
  <div class="app-container">
    <el-table
      v-loading="listLoading"
      :data="list"
      element-loading-text="Loading"
      border
      fit
      highlight-current-row
    >
      <el-table-column align="center" label="脚本ID">
        <template slot-scope="scope">
          {{ scope.row.taskid }}
        </template>
      </el-table-column>
      <el-table-column label="描述">
        <template slot-scope="scope">
          {{ scope.row.describe }}
        </template>
      </el-table-column>
      <el-table-column label="脚本路径" align="center">
        <template slot-scope="scope">
          <span>{{ scope.row.path }}</span>
        </template>
      </el-table-column>
      <el-table-column label="时间范围" align="center">
        <template slot-scope="scope">
          <el-input placeholder="yyyy-mm-dd/yyyy-mm-dd~yyyy-mm-dd" suffix-icon="el-icon-date" v-model="scope.row.time"></el-input>
        </template>
      </el-table-column>
      <el-table-column class-name="status-col" label="Status" align="center">
        <template slot-scope="scope">
          <el-tag :type="scope.row.status | statusFilter" v-if="scope.row.status=='published'">成功</el-tag>
          <el-tag :type="scope.row.status | statusFilter" v-if="scope.row.status=='running'">运行中</el-tag>
          <el-tag :type="scope.row.status | statusFilter" v-if="scope.row.status=='failed'">失败</el-tag>
        </template>
      </el-table-column>
      <el-table-column align="center" label="运行" >
          <el-button class="el-icon-video-play" type="text"></el-button>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button @click="handleClick(scope.row)" type="text" size="small">日志</el-button>
          <el-button type="text" size="small">编辑</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
// import { getList } from '@/api/rundata'

export default {
  filters: {
    statusFilter(status) {
      const statusMap = {
        published: 'success',
        running: 'gray',
        failed: 'danger'
      }
      return statusMap[status]
    }
  },
  data() {
    return {
      list: "",
      listLoading: true
    }
  },
  created() {
    this.fetchData()
  },
  methods: {
    fetchData() {
      this.listLoading = false
      this.list = [{
          taskid: 'sett0005',
          describe: 'mysqldump',
          path: '9.134.236.231:/root/settlement/monthly_defer/src',
          time: '',
          status: 'published'
        }, {
          taskid: 'sett0006',
          describe: '基础支付数据按天统计',
          path: '9.134.236.231:/root/settlement/monthly_defer/src',
          time: '',
          status: 'published'
        }, {
          taskid: 'sett0007',
          describe: '充值消耗报表',
          path: '9.134.236.231:/root/settlement/monthly_defer/src',
          time: '',
          status: 'running'
        }, {
          taskid: 'sett0008',
          describe: '平台币统计',
          path: '9.134.236.231:/root/settlement/monthly_defer/src',
          time: '',
          status: 'failed'
        }]
      run_task().then(response => {})
    }
  }
}
</script>
