import request from '@/utils/request'

export function getList(params) {
  return request({
    url: '/rundata/list',
    method: 'get',
    params
  })
}

export function runTask(params) {
  return request({
    url: '/rundata/list',
    method: 'get',
    params
  })
}
