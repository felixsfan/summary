import request from '@/utils/request'

export function getAllTask() {
  return request({
    url: '/rundata/get_all_task',
    method: 'post',
  })
}

export function editTask(taskinfo) {
  return request({
    url: '/rundata/edit_task',
    method: 'post',
    data:taskinfo
  })
} 

export function addTask(taskinfo) {
  return request({
    url: '/rundata/add_task',
    method: 'post',
    data:taskinfo
  })
} 

export function delTask(taskinfo) {
  return request({
    url: '/rundata/del_task',
    method: 'post',
    data:taskinfo
  })
} 

export function getConditionTask(params) {
  return request({
    url: '/rundata/getlist',
    method: 'post',
    data:params
  })
}

export function runTask(params) {
  return request({
    url: '/rundata/list',
    method: 'post',
    data:params
  })
}    
