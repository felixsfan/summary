import request from '@/utils/request'

export function gettableData(formdata) {
  return request({
    url: '/table/get_sql_data_table',
    method: 'post',
    data: formdata
  })
}
export function gettxtData(formdata) {
  return request({
    url: '/table/get_sql_data_txt',
    method: 'post',
    data: formdata,
    responseType: 'blob'
  })
}

export function getexeclData(formdata) {
  return request({
    url: '/table/get_sql_data_execl',
    method: 'post',
    data: formdata,
    responseType: 'blob'
  })
}