import request from '@/utils/request'

export function getField(tablename) {
  return request({
    url: '/table/getfield',
    method: 'post',
    header:{'Content_Type':'application/json'},
    data:tablename  // dict
  })
}

export function getDayMemberData(filterdata) {
  return request({
    url: '/table/get_day_member_data',
    method: 'post',
    data: filterdata
  })
}