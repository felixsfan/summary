import request from '@/utils/request'

export function export_file(formdata) {
  return request({
    url: '/export/export_file',
    method: 'post',
    data: formdata,
    responseType: 'blob'
  })
}