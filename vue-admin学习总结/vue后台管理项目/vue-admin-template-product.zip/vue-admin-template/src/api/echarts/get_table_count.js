import request from '@/utils/request'

export function getDataCount(data_date) {
  return request({
    url: '/table/get_data_count',
    method: 'post',
    header:{'Content_Type':'application/json'},
    data:data_date  // dict
  })
}