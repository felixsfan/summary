import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

/* Layout */
import Layout from '@/layout'
import chartsRouter from './modules/charts'
/**
 * Note: sub-menu only appear when route children.length >= 1
 * Detail see: https://panjiachen.github.io/vue-element-admin-site/guide/essentials/router-and-nav.html
 *
 * hidden: true                   if set true, item will not show in the sidebar(default is false)
 * alwaysShow: true               if set true, will always show the root menu
 *                                if not set alwaysShow, when item has more than one children route,
 *                                it will becomes nested mode, otherwise not show the root menu
 * redirect: noRedirect           if set noRedirect will no redirect in the breadcrumb
 * name:'router-name'             the name is used by <keep-alive> (must set!!!)
 * meta : {
    roles: ['admin','editor']    control the page roles (you can set multiple roles)
    title: 'title'               the name show in sidebar and breadcrumb (recommend set)
    icon: 'svg-name'/'el-icon-x' the icon show in the sidebar
    breadcrumb: false            if set false, the item will hidden in breadcrumb(default is true)
    activeMenu: '/example/list'  if set path, the sidebar will highlight the path you set
  }
 */

/**
 * constantRoutes
 * a base page that does not have permission requirements
 * all roles can be accessed
 */
export const constantRoutes = [{
        path: '/login',
        component: () =>
            import ('@/views/login/index'),
        hidden: true
    },

    {
        path: '/404',
        component: () =>
            import ('@/views/404'),
        hidden: true
    },

    {
        path: '/',
        component: Layout,
        redirect: '/dashboard',
        children: [{
            path: 'dashboard',
            name: 'Dashboard',
            component: () =>
                import ('@/views/dashboard/index'),
            meta: { title: '首页', icon: 'dashboard' }
        }]
    }
]

/**
 * asyncRoutes
 * the routes that need to be dynamically loaded based on user roles
 */
export const asyncRoutes = [{
        path: '/script_manager',
        component: Layout,
        redirect: '/script_manager/rundata',
        name: 'script_manager',
        meta: { title: '自动化脚本', icon: 'el-icon-s-help', roles: ['admin'] },
        children: [{
                path: 'rundata',
                name: 'Rundata',
                component: () =>
                    import ('@/views/autoscript/rundata/index'),
                meta: { title: '数据重跑', icon: 'el-icon-truck' }
            },
            {
                path: 'toolscript',
                name: 'Toolscript',
                component: () =>
                    import ('@/views/autoscript/toolscript/index'),
                meta: { title: '脚本工具', icon: 'el-icon-smoking' },
                children: [{
                        path: 'mysqldump',
                        component: () =>
                            import ('@/views/autoscript/toolscript/mysqldump'),
                        name: '数据库dump',
                        meta: { title: '数据库dump' }
                    },
                    {
                        path: 'commonlyused',
                        component: () =>
                            import ('@/views/autoscript/toolscript/commonlyused'),
                        name: '常用工具脚本',
                        meta: { title: '常用工具脚本' }
                    },
                    {
                        path: 'other',
                        component: () =>
                            import ('@/views/autoscript/toolscript/other'),
                        name: '其他',
                        meta: { title: '其他' }
                    }
                ]
            }
        ]
    },
    chartsRouter,
    {
        path: '/conf',
        component: Layout,
        meta: { title: '配置管理', icon: 'form', roles: ['admin'] },
        children: [{
                path: 'dynaconf',
                name: 'Dynaconf',
                component: () =>
                    import ('@/views/autoscript/rundata/index'),
                meta: { title: 'dynaconf配置', icon: 'el-icon-tableware', roles: ['admin'] }
            },
            {
                path: 'http://rainbow.oa.com/console/03075f01-718d-46a1-b78e-ffc8c857c533/production/list',
                meta: { title: '七彩石配置', icon: 'el-icon-watermelon', roles: ['admin'] }
            }
        ]
    },
    {
        path: '/selectdata',
        component: Layout,
        children: [{
            path: 'selectdata',
            component: () =>
                import ('@/views/selectdata'),
            name: 'Selectdata',
            meta: {
                title: '数据查询',
                icon: 'eye-open',
                roles: ['admin']
            }
        }]
    },
    {
        path: '/exportdata',
        component: Layout,
        children: [{
            path: 'exportscript',
            component: () =>
                import ('@/views/exportdata/exportscript'),
            name: 'Exportscript',
            meta: {
                title: '数据导出',
                icon: 'el-icon-toilet-paper',
                roles: ['admin']
            }
        }]
    },
    {
        path: 'xiaomabi',
        component: Layout,
        children: [{
            path: 'http://xiaoma.oa.com/#/review/1174',
            meta: { title: '对数差异分析', icon: 'tree', roles: ['admin'] }
        }]
    },
    {
        path: 'airflow',
        component: Layout,
        children: [{
            path: 'http://9.147.253.83:8080/supervisor/',
            meta: { title: '任务调度', icon: 'el-icon-alarm-clock', roles: ['admin'] }
        }]
    },
    // 404 page must be placed at the end !!!
    { path: '*', redirect: '/404', hidden: true }
]

const createRouter = () => new Router({
    mode: 'history', // require service support
    scrollBehavior: () => ({ y: 0 }),
    routes: constantRoutes
})

const router = createRouter()

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
    const newRouter = createRouter()
    router.matcher = newRouter.matcher // reset router
}

export default router