#!/usr/bin/env python3
# encoding: utf-8
# @Time    : 2022/3/21 12:25 上午

import json
import os

from flask import Blueprint, request, make_response, send_file

from service.exportoperate import ExportData
from service.tableoperate import GetTableInfo

export_blue = Blueprint("export_blue", __name__)


@export_blue.route("/dev-api/export_file", methods=['POST', 'GET'])
def getfield():
    data = json.loads(request.data)
    # scriptname: "non_mobile_basic_data",
    # descripe
    # sett_group
    # sett_month
    file_path = ""
    script_name = data['scriptname']
    if "" == script_name:

        data['sett_group']
        data['sett_month']

        result = ExportData().run_script(script_name)
        file_path = ExportData().get_file_path(script_name)
    elif "" == script_name:
        pass
    elif "" == script_name:
        pass
    elif "" == script_name:
        pass
    elif "" == script_name:
        pass

    if os.path.exists(file_path):
        return send_file(file_path, as_attachment=True)
    else:
        return {"code": 404, "data": {'msg': '文件不存在'}}
    if task_type == "qq_defer":
        export_qq_defer_data(sys.argv[2])
    elif task_type == "refund":
        # sett_group start_month end_month
        export_refund_data(sys.argv[2], sys.argv[3], sys.argv[4])
    elif task_type == "tme_defer":
        export_tme_defer_data(sys.argv[2])
    elif task_type == "all_defer":
        export_all_defer_data(sys.argv[2])
    elif task_type == "video_defer":
        export_video_defer_data(sys.argv[2])
    elif task_type == "non_mobile_basic_data":
        export_non_mobile_basic_data(sys.argv[2], sys.argv[3])  # export_non_mobile_basic_data('123943', '2021-12')