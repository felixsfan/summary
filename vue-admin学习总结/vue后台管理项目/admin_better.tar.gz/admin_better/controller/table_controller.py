#!/usr/bin/env python3
# encoding: utf-8
# @Time    : 2022/2/17 2:14 下午
# !/usr/bin/env python3
# encoding: utf-8
# @Time    : 2022/1/21 11:54 上午

import json
from flask import Blueprint, request

from service.tableoperate import GetTableInfo

table_blue = Blueprint("table_blue", __name__)


# @table_blue.route("/dev-api/table/getfield", methods=['POST', 'GET'])
# def getfield():
#     print('调用获取列的接口')
#     data = json.loads(request.data)
#     table_name = data['tablename']
#     get_table_info = GetTableInfo()
#     field_array = get_table_info.get_table_field(table_name)
#
#     if field_array:
#         data = {"code": 20000, "data": field_array}
#     else:
#         data = {"code": -1, "data": "查询列失败"}
#     return data
#
#
# @table_blue.route("/dev-api/table/get_day_member_data", methods=['POST', 'GET'])
# def get_day_member_data():
#     print('调用获取数据的接口')
#     data = json.loads(request.data)
#     fields = data['selectfield']
#     table_name = data['tablename']
#     date = data['date']
#     channel = data['channel']
#     spoaid = data['spoaid']
#     get_table_info = GetTableInfo()
#     tabledata = get_table_info.get_day_member_data(table_name, fields, date, channel, spoaid)
#     data = {
#         "code": 20000,
#         "data": tabledata
#     }
#     return data


@table_blue.route("/dev-api/table/get_data_count", methods=['POST', 'GET'])
def get_table_count():
    data = json.loads(request.data)
    begindate = data['begindate']
    enddate = data['enddate']
    get_table_info = GetTableInfo()
    data = get_table_info.get_many_table_count(begindate, enddate)

    return {"code": 20000, "data": data}
