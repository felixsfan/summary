#!/usr/bin/env python3
# encoding: utf-8
# @Time    : 2022/2/23 12:01 下午
import json

from flask import Blueprint, request

from service.taskoperate import TaskOperate

task_blue = Blueprint("task_blue", __name__)


@task_blue.route("/dev-api/rundata/get_all_task", methods=['POST', 'GET'])
def get_all_task():
    task_operate = TaskOperate()
    all_task = task_operate.get_all_task()
    data = {
        "code": 20000,
        "data": all_task
    }
    return data


@task_blue.route("/dev-api/rundata/edit_task", methods=['POST', 'GET'])
def edit_task():
    data = json.loads(request.data)
    task_operate = TaskOperate()
    result = task_operate.edit_task(data)
    if result:
        return {
            "code": 20000,
            "data": "更新成功"
        }
    else:
        return {
            "code": 400,
            "data": "更新失败"
        }


@task_blue.route("/dev-api/rundata/add_task", methods=['POST', 'GET'])
def add_task():
    data = json.loads(request.data)
    task_operate = TaskOperate()
    result = task_operate.add_task(data)
    if result:
        return {
            "code": 20000,
            "data": "添加成功"
        }
    else:
        return {
            "code": 400,
            "data": "添加失败"
        }


@task_blue.route("/dev-api/rundata/del_task", methods=['POST', 'GET'])
def del_task():
    print(request.data, type(request.data))
    data = json.loads(request.data)
    print(data, type(data))
    task_operate = TaskOperate()
    result = task_operate.del_task(data)
    if result:
        return {
            "code": 20000,
            "data": "添加成功"
        }
    else:
        return {
            "code": 400,
            "data": "添加失败"
        }
