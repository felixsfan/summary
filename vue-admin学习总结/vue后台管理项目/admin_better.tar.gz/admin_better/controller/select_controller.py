#!/usr/bin/env python3
# encoding: utf-8
# @Time    : 2022/3/21 3:46 下午
import json
import os
import pathlib
import traceback

from flask import Blueprint, request, send_file

from app import flask_app

from config import settings
from dao.export_dao import ExportDao
from service.selectoperate import GetSqlData

select_blue = Blueprint("select_blue", __name__)


@select_blue.route("/dev-api/table/get_sql_data_table", methods=['POST', 'GET'])
def get_sql_data():
    try:
        logger = flask_app.logger
        data = json.loads(request.data)
        connection = data['connection']
        export_type = data['export_type']
        sql_template = data['sql_template']
        logger.info(connection, export_type, sql_template)
        exclude = ('delete', 'update', 'insert')
        # 排除危险操作
        for item in exclude:
            if item in sql_template:
                return {"code": 5000, "data": "不允许的sql"}
        if ";" in sql_template:
            sql_template=sql_template.replace(';','')
        if "limit" not in sql_template:
            sql_template = f"{sql_template} limit 1000"
        getsql = GetSqlData()
        data = getsql.get_sql_result(connection, sql_template)
        return {"code": 20000, "data": data}  # 视图函数返回的不仅仅是字符串，而是会对返回值进行一些列的封装，变成一个response响应对象
    except Exception as argument:
        logger.error(traceback.format_exc())
        return {"code": 5000, "data": str(argument)}


@select_blue.route("/dev-api/table/get_sql_data_execl", methods=['POST', 'GET'])
def get_execl_data():
    try:
        logger = flask_app.logger
        data = json.loads(request.data)
        connection = data['connection']
        export_type = data['export_type']
        sql_template = data['sql_template']
        logger.info(connection, export_type, sql_template)
        exclude = ('delete', 'update', 'insert')
        # 排除危险操作
        for item in exclude:
            if item in sql_template:
                return {"code": 5000, "data": "不允许的sql"}
        if settings.admin_better.work_path:
            work_path = pathlib.Path(settings.admin_better.work_path)
            if work_path.exists():
                os.chdir(work_path)
                print("change to work path: {}".format(work_path))
                
        # if "limit" not in sql_template:
        #     sql_template = f"{sql_template} limit 1000"
        exportdao = ExportDao()
        file_path = exportdao.export_execl_data(connection, sql_template)
        if os.path.exists(file_path):
            return send_file(file_path, mimetype="application/octet-stream", attachment_filename="non_mobile_sett.xlsx", as_attachment=True)
        else:
            return {"code": 404, "data": {'msg': '文件不存在'}}
    except Exception as argument:
        logger.error(traceback.format_exc())
        return {"code": 5000, "data": str(argument)}


@select_blue.route("/dev-api/table/get_sql_data_txt", methods=['POST', 'GET'])
def get_text_data():
    try:
        logger = flask_app.logger
        data = json.loads(request.data)
        connection = data['connection']
        export_type = data['export_type']
        sql_template = data['sql_template']
        logger.info(connection, export_type, sql_template)
        exclude = ('delete', 'update', 'insert')
        # 排除危险操作
        for item in exclude:
            if item in sql_template:
                return {"code": 5000, "data": "不允许的sql"}

        if settings.admin_better.work_path:
            work_path = pathlib.Path(settings.admin_better.work_path)
            if work_path.exists():
                os.chdir(work_path)
                print("change to work path: {}".format(work_path))
        # if "limit" not in sql_template:
        #     sql_template = f"{sql_template} limit 1000"
        exportdao = ExportDao()
        file_path = exportdao.export_text_data(connection, sql_template)
        if os.path.exists(file_path):
            return send_file(file_path, mimetype='text/csv', attachment_filename="non_mobile_sett.txt", as_attachment=True)
        else:
            return {"code": 404, "data": {'msg': '文件不存在'}}
    except Exception as argument:
        logger.error(traceback.format_exc())
        return {"code": 5000, "data": str(argument)}