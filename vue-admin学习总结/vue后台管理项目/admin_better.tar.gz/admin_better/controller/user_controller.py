#!/usr/bin/env python3
# encoding: utf-8
# @Time    : 2022/1/21 11:54 上午
import json

from flask import Blueprint, request
from flask import current_app
from service.user_login import UserLogin

user_blue = Blueprint("user_blue", __name__)


@user_blue.route("/dev-api/user/login", methods=['POST'])
def login():
    data = json.loads(request.data)
    username = data["username"]
    password = data["password"]
    print("调用用户登录的接口")
    token = "123456"
    #token = UserLogin().verify_login(username, password)
    if token:
        data = {"code": 20000, "data": token}
    else:
        data = {"code": -1, "data": "密码错误"}
    return json.dumps(data)


@user_blue.route("/dev-api/user/info", methods=['POST', 'GET'])
def get_info():
    token = request.args.get("token")
    current_app.logger.info(token)  # 蓝图中使用全局日志
    print('调用用户信息的接口')
    # 验证token并获取用户权限等信息
    # user = UserLogin().verify_token(token)
    user = True
    if user:
        data = {"code": 20000,
                "data": {"roles": "admin", "name": "felixsfan",
                         "avatar": "https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif?imageView2/1/w/80/h/80"}}
    else:
        data = {"code": -2, "data": "token验证失败"}
    return json.dumps(data)  # 视图函数返回的不仅仅是字符串，而是会对返回值进行一些列的封装，变成一个response响应对象。因此可以不需要自己手动序列化了


@user_blue.route("/dev-api/user/logout", methods=['POST', 'GET'])
def logout():
    return {"code": 20000, "data": "用户退出登陆"}
