#!/usr/bin/env python3
# encoding: utf-8
# @Time    : 2022/1/24 3:41 下午
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer, SignatureExpired, BadSignature

from config import settings

SECRET_KEY = settings.secret_key.login_secret_key


# 生成token, 有效时间为600min
def generate_auth_token(username, expiration=36000):
    # 第一个参数是内部私钥
    # 第二个参数是有效期（秒）
    s = Serializer(SECRET_KEY, expires_in=expiration)
    return s.dumps({'username': username}).decode("utf8")  # 加密，类型是bytes类型


# 解析token
def verify_auth_token(token):
    s = Serializer(SECRET_KEY)
    # token正确
    try:
        data = s.loads(token)
        return data
    # token过期
    except SignatureExpired:
        return False
    # token错误
    except BadSignature:
        return False


if __name__ == '__main__':
    token = generate_auth_token("felixsfan")
    print(token)
    result = verify_auth_token(token)
    print(result)
