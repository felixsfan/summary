#!/usr/bin/env python3
# encoding: utf-8
# @Time    : 2022/2/17 2:46 下午
TABLE_DB_MAP = {'t_prepay_stat_YYYYMM_add': 'tj',
                't_pay_provide_data': 'db_income_day',
                't_chan_pay_data': 'db_income_day',
                't_portal_pay_data': 'db_income_day',
                't_provide_pay_data': 'db_income_day',
                't_product_pay_stat_extend': 'db_bmc_stat',
                't_product_pay_stat': 'db_bmc_stat',
                't_syn_settlement': 'db_st_data',
                't_prepay_stat_all': 'tj',
                't_acct_consume_data': 'db_balance_day',
                't_refund_data_from_water': 'db_income_day',
                't_day_balance_dyb': 'db_balance_data',
                't_tob_sale_pay_data_from_water': 'db_tob_sale'
                }
