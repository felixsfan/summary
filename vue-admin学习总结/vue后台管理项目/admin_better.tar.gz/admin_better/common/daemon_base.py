#!/usr/bin/env python3
# coding=utf-8
import os
import sys
import logging
import logging.handlers
import socket
import atexit
import signal
import pathlib
from ..config import settings
from .common_define import ResultCode, KEY_SEPARATOR


class ExitException(Exception):
    @staticmethod
    def sigterm_handler(signum, frame):
        raise ExitException()


class DaemonBase(object):
    """避免重复码字，基类
    """
    def __init__(self):
        self.app_config = None
        self.logger = None
        self.logger_handler = None
        self.monitor_mail = None
        self.key_sep = KEY_SEPARATOR
        self.is_init = False    # 防止重复初始化
        self.process_name = ""  # 进程名称
        self.native_ip_address = "0.0.0.0"
        self.work_path = None

    def init_logger(self):
        if self.logger:   # 如果构造类的时候传入logger，这里不再初始化
            return ResultCode.CODE_OK
        log_name = ".".join([settings.log_config.log_name, self.app_config.task_name])
        if self.process_name:   # 如果是多进程，这里为每个进程单独输出一个log文件
            log_name = ".".join([log_name, self.process_name])
        # 如果log_name存在，会得到已初始化的logger，再增加handle的话，会出现复写
        # 如果log_name是子类的话，不加handle会复用父类的handle，加handle会复写
        print("log name is: {}".format(log_name))
        log_file = pathlib.Path(settings.log_config.log_path) / f"{log_name}.log"
        print("log file is : {}".format(log_file))

        self.logger = logging.getLogger(log_name)
        for handler in self.logger.handlers:   # 如果有其他handler，则清掉
            self.logger.removeHandler(handler)
        if settings.log_config.log_level == "DEBUG":
            log_level = logging.DEBUG
        elif settings.log_config.log_level == "INFO":
            log_level = logging.INFO
        elif settings.log_config.log_level == "ERROR":
            log_level = logging.ERROR
        else:
            log_level = logging.DEBUG
        self.logger.setLevel(log_level)

        # 对于多进程如果使用cloghandler，对于日志打印频繁的，会影响性能
        # 这里用AA，AA.BB的方式，AA是所有进程完整的，进程间不安全，AA.BB是一个进程独享的
        self.logger_handler = logging.handlers.TimedRotatingFileHandler(str(log_file), "midnight", 1, 45)
        self.logger_handler.setLevel(log_level)
        self.logger_handler.setFormatter(logging.Formatter("[%(asctime)s %(module)s] %(levelname)s %(message)s"))
        self.logger.addHandler(self.logger_handler)

        return ResultCode.CODE_OK

    def initialize(self, app_config):
        if self.is_init:
            return ResultCode.CODE_OK
        self.app_config = app_config
        if settings.work_path:    # 如果设置了环境变量 DYNACONF_WORK_PATH，且目录存在，切换到工作目录
            self.work_path = pathlib.Path(settings.work_path)
            if self.work_path.exists():
                os.chdir(self.work_path)
                print("change to work path: {}".format(self.work_path))
        self.init_logger()
        self.is_init = True
        return ResultCode.CODE_OK

    def finish(self):
        self.is_init = False
        if self.logger and self.logger_handler:
            self.logger_handler.close()
            self.logger.removeHandler(self.logger_handler)
            self.logger_handler = None
            self.logger = None

    def get_native_ip_address(self):
        """查询本机ip地址
        """
        local_socket = None
        try:
            local_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            local_socket.connect(("8.8.8.8", 80))
            self.native_ip_address = local_socket.getsockname()[0]
            self.logger.info("native ip address is: {}".format(self.native_ip_address))
        finally:
            if local_socket:
                local_socket.shutdown(socket.SHUT_RDWR)
                local_socket.close()
        return self.native_ip_address

    def demonize(self):
        """
        1、进程组首进程不能调用setsid，会得到EPERM错误，这就是第一个fork的原因，执行第一个fork并让父进程退出，子进程继续，
        这时候由于子进程会继承其父进程的进程组GID并有自己的进程PID，而这个PID和GID肯定是不一样的。所子进程绝不可能成为进程
        组首进程，满足了调用setsid的条件。
       2、调用setsid后所有到之前控制终端的连接都会断开。
       3、最后，再执行一次fork，让子进程退出，孙进程继续。这样让孙进程pid不等于它所在的会话sid，这样它就不会自己变成会话首
       进程，也就使它不能打开控制终端。这样守护进程就得到了一个干净的环境，它不会被终端产生的信号干扰。

       经过前面2个步骤，基本想要做的都做了。第2次fork不是必须的。也看到很多开源服务没有fork第二次。fork第二次主要目的是。
       防止进程再次打开一个控制终端。因为打开一个控制终端的前台条件是该进程必须是会话组长。再fork一次，子进程ID != sid
       （sid是进程父进程的sid）。所以也无法打开新的控制终端。
        """
        daemon_config = self.app_config.daemon_config
        daemon_pid_file = pathlib.Path(daemon_config.daemon_pid_file)
        if daemon_pid_file.exists():
            raise RuntimeError("{} already running,pid file: {}".format(self.__class__.__name__, daemon_pid_file))

        # First fork (detaches from parent)
        try:
            new_pid = os.fork()
            if new_pid > 0:
                self.logger.info("fork#1 parent process quit, id {}, child pid {}".format(os.getpid(), new_pid))
                raise SystemExit(0)  # Parent exit
        except OSError as error:
            raise RuntimeError("{} demonize fork #1 failed, {}".format(self.__class__.__name__, error))
        self.logger.info("demonize work path: {}".format(os.getcwd()))
        # os.chdir("/")
        os.umask(0)
        # 当进程是会话的领头进程时setsid()调用失败并返回（-1）。
        # setsid()调用成功后，返回新的会话的ID，调用setsid函数的进程成为新的会话的领头进程，并与其父进程的会话组和进程组脱离。
        # 由于会话对控制终端的独占性，进程同时与控制终端脱离。
        os.setsid()

        # Second fork (relinquish session leadership)
        try:
            new_pid = os.fork()
            if new_pid > 0:
                self.logger.info("fork#2 parent process quit, id {}, child pid {}".format(os.getpid(), new_pid))
                raise SystemExit(0)
        except OSError as error:
            raise RuntimeError("{} demonize fork #2 failed, {}".format(self.__class__.__name__, error))

        # Flush I/O buffers
        sys.stdout.flush()
        sys.stderr.flush()
        # Replace file descriptors for stdin, stdout, and stderr
        with open(pathlib.Path(settings.log_config.log_path, daemon_config.daemon_std_in), "rb", 0) as file:
            os.dup2(file.fileno(), sys.stdin.fileno())
        with open(pathlib.Path(settings.log_config.log_path, daemon_config.daemon_std_out), "ab", 0) as file:
            os.dup2(file.fileno(), sys.stdout.fileno())
        with open(pathlib.Path(settings.log_config.log_path, daemon_config.daemon_std_error), "ab", 0) as file:
            os.dup2(file.fileno(), sys.stderr.fileno())

        # Write the PID file
        with open(daemon_config.daemon_pid_file, "w") as file:
            print(os.getpid(), file=file)

        # Arrange to have the PID file removed on exit/signal
        atexit.register(lambda: os.remove(daemon_config.daemon_pid_file))
        signal.signal(signal.SIGTERM, ExitException.sigterm_handler)

        return ResultCode.CODE_OK

    def do_job(self, task_type):
        pass
        return ResultCode.CODE_OK
