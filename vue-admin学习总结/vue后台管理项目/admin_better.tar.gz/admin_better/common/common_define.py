#!/usr/bin/env python3
# coding=utf-8
import enum

KEY_SEPARATOR = "::"


class ResultCode(enum.Enum):
    CODE_DEFAULT = -1
    CODE_OK = 0
    CODE_SKIP = 1
    CODE_MISS_CHAN = 2
    CODE_MISS_PORTAL = 3
    CODE_MISS_PROVIDE = 4
    CODE_MISS_BOSS = 5
    CODE_ERROR = 100  # 错误相关
    CODE_CONF_ERROR = 101
    CODE_QUERY_FAILED = 102
    CODE_METHOD_INVALID = 103
    CODE_PARA_INVALID = 104
    CODE_SERVER_ERROR = 105
    CODE_FILE_EXIST = 200  # hdfs 相关
    CODE_HDFS_EMPTY = 201
    CODE_PULL_FAILED = 202
    CODE_MERGE_FAILED = 203
    CODE_PUSH_FAILED = 204
    CODE_TASK_SUCCESS = 300  # 任务状态相关
    CODE_TASK_RUNNING = 310
    CODE_TASK_FAILED = 320


class ProcessError(UserWarning):
    def __init__(self, message):
        self.error_info = message

    def __str__(self):
        return self.error_info


# 不用这种格式的返回值了
class BasicResult(object):
    def __init__(self, result_code=ResultCode.CODE_OK, result_info='ok'):
        self.result_code = result_code
        self.result_info = result_info

    def __str__(self):
        return "result code : {}, result info : {} ".format(self.result_code, self.result_info)

    def is_failed(self):
        return self.result_code != ResultCode.CODE_OK


class OpType(enum.Enum):
    OP_TYPE_DEFAULT = "0"
    OP_TYPE_PACKET = "11111"  # 打包包月的，历史遗留，不知道为什么这么定义
    OP_TYPE_SHOPPING_CART = "1024"  # 购物车模式，发货流水，自己随便定义的
    OP_TYPE_QB_GIFT = "6"


class TaskType(enum.Enum):
    TASK_TYPE_DEFAULT = "default"
    TASK_TYPE_COUNT = "count"
    TASK_TYPE_CHECK = "check"
    TASK_CACHE_PORTAL = "cache_portal"
    TASK_CACHE_CHAN = "cache_chan"
    TASK_CACHE_PROVIDE = "cache_provide"
    TASK_CLEAR_CACHE = "clear_cache"

    TASK_SYNC_SPOA_INFO = "sync_spoa_info"
    TASK_SYNC_ACCT_CONFIG_INFO = "sync_acct_config_info"

    TASK_NON_MOBILE_COUNT_INCOME = "non_mobile_count_income"
    TASK_NON_MOBILE_DYB_BALANCE = "non_mobile_dyb_balance"
    TASK_NON_MOBILE_DYB_CONSUME = "non_mobile_dyb_consume"
    TASK_NON_MOBILE_CHAN_BANLANCE = "non_mobile_chan_balance"
    TASK_NON_MOBILE_IDATA_DYB_RATE = "non_mobile_idata_dyb_rate"
    TASK_NON_MOBILE_SYNC_TEST_NUM = "non_mobile_sync_test_num"
    TASK_NON_MOBILE_SYNC_VIDEO_DATA = "non_mobile_sync_video_data"
    TASK_NON_MOBILE_MONTHLY_CARD_DEFER = "non_mobile_monthly_card_defer"
    TASK_NON_MOBILE_CALC_PLATFORM_PRICE = "non_mobile_calc_platform_price"
    TASK_NON_MOBILE_ADJUST_PLATFORM_PRICE = "non_mobile_adjust_platform_price"
    TASK_NON_MOBILE_CALC_DYB_PRICE = "non_mobile_calc_dyb_price"
    TASK_NON_MOBILE_ADJUST_DYB_PRICE = "non_mobile_adjust_dyb_price"
    TASK_NON_MOBILE_CHECK_DYB_PRICE = "non_mobile_check_dyb_price"
    TASK_NON_MOBILE_SUM_DEFER = "non_mobile_sum_defer"
    TASK_NON_MOBILE_MERCHANT_RECEIVABLE = "non_mobile_merchant_receivable"
    TASK_QB_INNER_TRANSFER = "qb_inner_transfer"
    TASK_PUSH_QB_IMS_JM = "push_qb_ims_jm"

    TASK_MOBILE_CALC_PLATFORM_PRICE = "mobile_calc_platform_price"
    TASK_MOBILE_ADJUST_PLATFORM_PRICE = "mobile_adjust_platform_price"
    TASK_MOBILE_CALC_DYB_PRICE = "mobile_calc_dyb_price"
    TASK_MOBILE_ADJUST_DYB_PRICE = "mobile_adjust_dyb_price"
    TASK_MOBILE_CHECK_DYB_PRICE = "mobile_check_dyb_price"

    TASK_TOB_SALE_SYNC_CONF = "tob_sale_sync_conf"
    TASK_TOB_SALE_PAY_COUNT = "tob_sale_pay_count"
    TASK_TOB_SALE_DEFER_COUNT = "tob_sale_defer_count"
    TASK_TOB_SALE_ACCT_BALANCE = "tob_sale_acct_balance"
    TASK_TOB_SALE_REDEEM_BALANCE = "tob_sale_redeem_balance"
    TASK_TOB_SALE_ACCT_CHARGE = "tob_sale_acct_charge"
    TASK_TOB_SALE_ACCT_CONSERVE = "tob_sale_acct_conserve"
    TASK_TOB_SALE_CALC_PRICE = "tob_sale_calc_price"
    TASK_TOB_SALE_CHARGE_TO_IMS = "tob_sale_charge_to_ims"
    TASK_TOB_SALE_CONSUME_INCOME = "tob_sale_consume_income"
    TASK_TOB_SALE_IEG_RECEIVABLE = "tob_sale_ieg_receivable"
    TASK_TOB_SALE_IEG_INCOME = "tob_sale_ieg_income"


class TaskStatus(enum.Enum):
    STATUS_OK = "ok"
    STATUS_SUCCESS = "success"
    STATUS_RUNNING = "running"
    STATUS_FAILED = "failed"
