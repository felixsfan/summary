#!/usr/bin/env python3
# coding=utf-8
import datetime
import calendar


def get_last_month(date_string):
    # date or month string: 2015-03-28 or 2015-03
    year = int(date_string[0:4])
    month = int(date_string[5:7])

    first_day = datetime.date(year, month, 1)
    last_month_day = first_day - datetime.timedelta(days=1)
    return last_month_day.strftime("%Y-%m")


def get_next_month(date_string):
    # date or month string: 2015-03-28 or 2015-03
    year = int(date_string[0:4])
    month = int(date_string[5:7])
    if month == 12:
        month = 1
        year += 1
    else:
        month += 1
    return "{:4d}-{:02d}".format(year, month)


def get_last_month_last_day(date_string):
    if len(date_string) == 7:
        date_string += "01"
    else:
        date_string = date_string[0:7] + "01"
    first_date = datetime.datetime.strptime(date_string, "%Y-%m-%d")
    last_month_date = first_date - datetime.timedelta(1)
    return last_month_date.strftime("%Y-%m")


def get_month_last_day(month_string):
    month_list = month_string.split('-')
    year = int(month_list[0])
    month = int(month_list[1])
    days = calendar.monthrange(year, month)[1]

    if len(month_string) == 7:
        last_day = "{}-{:02d}".format(month_string, days)
    else:
        last_day = "{}{:02d}".format(month_string, days)

    return last_day


# month string : 2015-03
def get_month_days(month_string):
    month_list = month_string.split('-')
    year = int(month_list[0])
    month = int(month_list[1])

    return calendar.monthrange(year, month)[1]


def get_months_ago(now_month, month_num):
    now_year = int(now_month[0:4])
    now_month = int(now_month[5:7])
    delta_year = int(month_num / 12)
    delta_month = month_num % 12
    if now_month <= delta_month:
        delta_year += 1
        delta_month -= now_month
        now_month = 12
    last_year = now_year - delta_year
    last_month = now_month - delta_month
    return "{}-{:02d}".format(last_year, last_month)


def get_days_ago(now_date, days):
    if len(now_date) == 10:
        this_day = datetime.datetime.strptime(now_date, "%Y-%m-%d")
        old_day = this_day - datetime.timedelta(days)
        return old_day.strftime("%Y-%m-%d")
    elif len(now_date) == 8:
        this_day = datetime.datetime.strptime(now_date, "%Y%m%d")
        old_day = this_day - datetime.timedelta(days)
        return old_day.strftime("%Y%m%d")
    else:
        return None


def getDayAll(starDay, endDay):
    date_start = datetime.datetime.strptime(starDay, '%Y-%m-%d')
    date_end = datetime.datetime.strptime(endDay, '%Y-%m-%d')
    dates = [date_start.strftime('%Y-%m-%d')]
    while date_start < date_end:
        date_start += datetime.timedelta(days=1)
        dates.append(date_start.strftime('%Y-%m-%d'))
    return dates
