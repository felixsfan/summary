#!/usr/bin/env python3
# -*- coding=utf-8 -*-
import cx_Oracle
from .common_define import ResultCode, ProcessError


class OracleClient(object):
    def __init__(self):
        self.connection = None
        self.cursor = None
        self.column_list = []
        self.procedure_cursor = None
        self.logger = None

    def init_connect(self, db_config, logger):
        self.logger = logger
        db_host = db_config.host
        db_user = db_config.user
        db_pass_word = db_config.password
        try:
            self.connection = cx_Oracle.connect(db_user, db_pass_word, db_host)
            self.cursor = self.connection.cursor()
            self.logger.debug("init connect oracle {}".format(db_host))
        except cx_Oracle.DatabaseError as error:
            self.logger.error("init oracle connection failed {}".format(error))
            raise ProcessError("init oracle connection failed {}".format(error))
        return ResultCode.CODE_OK

    def close(self):
        if self.cursor:
            self.cursor.close()
            self.cursor = None
        if self.connection:
            self.connection.close()
            self.connection = None

    @staticmethod
    def make_dict(cursor):
        cols = [d[0] for d in cursor.description]

        def create_row(*args):
            return dict(zip(cols, args))
        return create_row

    def query(self, sql):
        try:
            self.cursor.execute(sql)
            self.cursor.rowfactory = OracleClient.make_dict(self.cursor)
            return self.cursor.fetchall()
        except cx_Oracle.Error as error:
            self.logger.error("sql {} error {}".format(sql, error))
            raise ProcessError("sql {} error {}".format(sql, error))

    def procedure_query(self, procedure_name):
        try:
            oracle_cursor = self.cursor.var(cx_Oracle.CURSOR)
            cursor_list = self.cursor.callproc(procedure_name, [oracle_cursor])
            # cursor_list[0].rowfactory = self.make_dict(cursor_list[0])
            return cursor_list[0].fetchall()
        except cx_Oracle.Error as error:
            self.logger.error("sql {} error {}".format(procedure_name, error))
            raise ProcessError("sql {} error {}".format(procedure_name, error))

    def call_procedure(self, procedure_name):
        try:
            oracle_cursor = self.cursor.var(cx_Oracle.CURSOR)
            cursor_list = self.cursor.callproc(procedure_name, [oracle_cursor])
            self.procedure_cursor = cursor_list[0]
            self.column_list = [description[0] for description in self.procedure_cursor.description]
            self.procedure_cursor.rowfactory = self.make_dict(self.procedure_cursor)
        except cx_Oracle.Error as error:
            self.logger.error("sql {} error {}".format(procedure_name, error))
            raise ProcessError("sql {} error {}".format(procedure_name, error))
        return ResultCode.CODE_OK

    def procedure_fetch_many(self, row_no):
        try:
            return self.procedure_cursor.fetchmany(row_no)
        except cx_Oracle.Error as error:
            self.logger.error("fetch many error {}".format(error))
            raise ProcessError("fetch many error {}".format(error))

    def update(self, sql):
        try:
            self.cursor.execute(sql)
            self.connection.commit()
        except cx_Oracle.Error as error:
            self.logger.error("sql {} error {}".format(sql, error))
            raise ProcessError("sql {} error {}".format(sql, error))
        return ResultCode.CODE_OK
