#!/usr/bin/env python3
# coding=utf-8
import os
import re
import datetime
import logging
import logging.handlers
import pathlib
import redis
import rediscluster

from common import KEY_SEPARATOR, TaskType, ResultCode, ProcessError, date_tool
from config import settings


class MonitorMail(object):
    def __init__(self):
        self.mail_to = "xiangtaoli"
        self.mail_title = ""
        self.mail_file = None
        self.message_to = "weixin#xiangtaoli"
        self.mail_handle = None
        self.need_send_mail = False
        self.is_html_format = False

    def write_html_head(self):
        html_start = """<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
</head>
<body>"""
        self.mail_handle.write(html_start)

    def write_line(self, line):
        self.mail_handle.write(line + os.linesep)

    def write_ul_list(self, item_set):
        self.mail_handle.write("<ul>" + os.linesep)
        for item in item_set:
            self.mail_handle.write("<li>{}</li>".format(item))
        self.mail_handle.write("</ul>" + os.linesep)

    def write_html_end(self):
        if self.is_html_format and self.mail_handle:
            html_end = "</body>" + os.linesep + "</html>"
            self.mail_handle.write(html_end)

    def send_mail(self, attach_file=None):
        self.write_html_end()
        if self.mail_handle:
            self.mail_handle.close()
            self.mail_handle = None
        if not self.need_send_mail or not self.mail_file.exists():
            print("info: do not need send mail: {}".format(self.mail_file))
            return None
        if not os.path.exists("/bin/sendmail2"):
            return None
        if os.path.getsize(str(self.mail_file)) <= 0:
            print("error: mail file is zero")
            return None
        if self.is_html_format:
            if attach_file:
                send_mail_cmd = "/bin/sendmail2 'oss-admin' '{}' '' '{}' '{}' '{}' --html". \
                    format(self.mail_to, self.mail_title, str(self.mail_file), attach_file)
            else:
                send_mail_cmd = "/bin/sendmail2 'oss-admin' '{}' '' '{}' '{}' --html". \
                    format(self.mail_to, self.mail_title, str(self.mail_file))
        else:
            if attach_file:
                send_mail_cmd = "/bin/sendmail2 'oss-admin' '{}' '' '{}' '{}' '{}'".\
                    format(self.mail_to, self.mail_title, str(self.mail_file), attach_file)
            else:
                send_mail_cmd = "/bin/sendmail2 'oss-admin' '{}' '' '{}' '{}' ".\
                    format(self.mail_to, self.mail_title, str(self.mail_file))
        shell_cmd = send_mail_cmd.encode("gbk", "ignore")
        os.system(shell_cmd)

    def send_alarm_message(self, alarm_message):
        send_alarmmsg_cmd = "/bin/sendAlarmMsg '{}' '{}'".format(self.message_to, alarm_message)
        os.system(send_alarmmsg_cmd)

    def close(self):
        if self.mail_handle:
            self.mail_handle.close()
            self.mail_handle = None


class ProcessMail(MonitorMail):
    """多进程安全的邮件
    """
    MAIL_DICT = {}

    def __init__(self, process_lock):
        super().__init__()
        self.lock = process_lock

    def write_html_head(self):
        self.lock.acquire()
        try:
            self.mail_handle = self.mail_file.open(mode="a+")
            self.mail_handle.seek(0, 0)
            line = self.mail_handle.readline()
            if line or (not line.startswith("<!DOCTYPE HTML>")):
                super().write_html_head()
        finally:
            self.lock.release()

    def write_line(self, line):
        self.lock.acquire()
        try:
            self.mail_handle = self.mail_file.open(mode="a+")
            super().write_line(line)
            self.mail_handle.close()
            self.mail_handle = None
        finally:
            self.lock.release()

    def write_ul_list(self, item_set):
        self.lock.acquire()
        try:
            self.mail_handle = self.mail_file.open(mode="a+")
            super().write_ul_list(item_set)
            self.mail_handle.close()
            self.mail_handle = None
        finally:
            self.lock.release()

    def write_html_end(self):
        if self.is_html_format:
            self.lock.acquire()
            try:
                self.mail_handle = open(self.mail_file, 'a+')
                html_end = "</body>" + os.linesep + "</html>"
                self.mail_handle.write(html_end)
                self.mail_handle.close()
                self.mail_handle = None
            finally:
                self.lock.release()


class SettleBase(object):
    """避免重复码字，基类
    """

    def __init__(self, logger=None, monitor_mail=None, task_type=TaskType.TASK_TYPE_DEFAULT):
        self.data_date = ""
        self.app_config = None
        self.logger = logger
        self.logger_handler = None  # 只有自己初始化的才会有
        self.monitor_mail = monitor_mail
        self.key_sep = KEY_SEPARATOR
        self.file_sep = "|"
        self.html_line_sep = "<br />"
        self.is_init = False  # 防止重复初始化
        self.task_type = task_type  # 统计类型任务不可重跑历史已结算数据
        self.process_name = ""  # 一般多进程才设置，设置后log会加后缀
        self.process_lock = None  # 多进程设置，用于写邮件
        self.process_manager = None
        # self.multi_process_mode = False
        self.redis = None
        self.redis_cluster = None
        self.work_path = None

    def set_task_type(self, task_type):
        self.task_type = task_type

    def set_multi_process_mode(self, module_name="", process_lock=None):
        # self.multi_process_mode = multi_process
        self.process_name = module_name
        self.process_lock = process_lock

    def init_logger(self):
        if self.logger:  # 如果构造类的时候传入logger，这里不再初始化
            return ResultCode.CODE_OK
        log_name = ".".join([settings.log_config.log_name, self.app_config.task_name])
        if self.process_name:  # 如果是多进程，这里为每个进程单独输出一个log文件
            log_name = ".".join([log_name, self.process_name])
        # 如果log_name存在，会得到已初始化的logger，再增加handle的话，会出现复写
        # 如果log_name是子类的话，不加handle会复用父类的handle，加handle会复写
        print("log name is: {}".format(log_name))
        log_file = pathlib.Path(settings.log_config.log_path) / f"{log_name}_{self.data_date}.log"
        print("log file is : {}".format(log_file))

        self.logger = logging.getLogger(log_name)
        for handler in self.logger.handlers:  # 如果有其他handler，则清掉
            self.logger.removeHandler(handler)
        if settings.log_config.log_level == "DEBUG":
            log_level = logging.DEBUG
        elif settings.log_config.log_level == "INFO":
            log_level = logging.INFO
        elif settings.log_config.log_level == "ERROR":
            log_level = logging.ERROR
        else:
            log_level = logging.DEBUG
        self.logger.setLevel(log_level)

        # 这里用AA，AA.BB的方式，AA是所有进程完整的，进程间不安全，AA.BB是一个进程独享的
        self.logger_handler = logging.handlers.RotatingFileHandler(str(log_file), "a", 1073741824, 5)
        self.logger_handler.setLevel(log_level)
        self.logger_handler.setFormatter(logging.Formatter("[%(asctime)s %(module)s] %(levelname)s %(message)s"))
        self.logger.addHandler(self.logger_handler)

        # delete old file log
        if len(self.data_date) == 10:  # 日期是天
            date_time_now = datetime.datetime.strptime(self.data_date, "%Y-%m-%d")
            date_time_old = date_time_now.date() - datetime.timedelta(settings.log_config.log_storage_days)
            old_file_name = "{}_{}.log".format(log_name, date_time_old.strftime("%Y-%m-%d"))
        elif len(self.data_date) == 7:  # 日期是月
            date_time_now = datetime.datetime.strptime("{}-01".format(self.data_date), "%Y-%m-%d")
            date_time_old = date_time_now.date() - datetime.timedelta(settings.log_config.log_storage_days)
            old_file_name = "{}_{}.log".format(log_name, date_time_old.strftime("%Y-%m"))
        else:
            return ResultCode.CODE_OK
        old_file = pathlib.Path(settings.log_config.log_path) / old_file_name
        if old_file.exists():
            old_file.unlink()
        return ResultCode.CODE_OK

    def init_mail(self):
        if self.monitor_mail:
            return ResultCode.CODE_OK
        mail_file_name = "{}_{}".format(self.app_config.mail_file_name, self.data_date)
        if self.process_lock:
            if mail_file_name in ProcessMail.MAIL_DICT:  # 文件名字相同则复用
                self.monitor_mail = ProcessMail.MAIL_DICT[mail_file_name]
                print("use share process mail")
                return ResultCode.CODE_OK
            self.monitor_mail = ProcessMail(self.process_lock)
            ProcessMail.MAIL_DICT[mail_file_name] = self.monitor_mail  # 缓存用于复用
            print("start process mail")
        else:
            self.monitor_mail = MonitorMail()
            print("start monitor mail")
        self.monitor_mail.mail_file = pathlib.Path(settings.mail_config.mail_file_path) / mail_file_name
        self.monitor_mail.mail_to = getattr(settings.role_config, self.app_config.task_name)
        self.monitor_mail.mail_title = "{}_{}".format(self.app_config.mail_title, self.data_date)
        try:
            # 打开一个文件只用于写入。如果该文件已存在则打开文件，并从开头开始编辑，即原有内容会被删除。如果该文件不存在，创建新文件。
            self.monitor_mail.mail_handle = self.monitor_mail.mail_file.open(mode="w")
            if self.process_lock:  # 第一次初始化，共享邮件需要关闭
                self.monitor_mail.mail_handle.close()
            if settings.mail_config.mail_format == "html":
                self.monitor_mail.is_html_format = True
                self.monitor_mail.write_html_head()
        except IOError as error:
            self.monitor_mail.mail_handle = None
            raise ProcessError("open mail file failed: {}".format(error))
        print("mail file: {}".format(self.monitor_mail.mail_file))

        storage_day = settings.mail_config.mail_storage_days
        if len(self.data_date) == 10:  # 日期是天
            date_time_now = datetime.datetime.strptime(self.data_date, "%Y-%m-%d")
            date_time_old = date_time_now.date() - datetime.timedelta(storage_day)
            old_file_name = "{}_{}".format(mail_file_name, date_time_old.strftime("%Y-%m-%d"))
        elif len(self.data_date) == 7:  # 日期是月
            date_time_now = datetime.datetime.strptime("{}-01".format(self.data_date), "%Y-%m-%d")
            date_time_old = date_time_now.date() - datetime.timedelta(storage_day)
            old_file_name = "{}_{}".format(mail_file_name, date_time_old.strftime("%Y-%m"))
        else:
            return ResultCode.CODE_OK
        old_file = pathlib.Path(settings.mail_config.mail_file_path) / old_file_name
        if old_file.exists():
            old_file.unlink()
        return ResultCode.CODE_OK

    def set_send_mail(self, need_send_mail):
        self.monitor_mail.need_send_mail = need_send_mail

    def send_mail(self, attach_file=None):
        """ 调用过set_send_mail，且邮件文件不为空才发送"""
        if self.monitor_mail and self.monitor_mail.need_send_mail:
            self.monitor_mail.send_mail(attach_file)

    def initialize(self, app_config, data_date):  # non_mobile_count YYYY-MM-DD
        if self.is_init:
            return ResultCode.CODE_OK
        if not app_config:
            raise ProcessError("config object is null")
        if settings.work_path:  # 如果设置了环境变量 DYNACONF_WORK_PATH，且目录存在，切换到工作目录
            self.work_path = pathlib.Path(settings.work_path)
            if self.work_path.exists():
                os.chdir(self.work_path)
                print("change to work path: {}".format(self.work_path))
        match_day = re.match(r"^\d{4}-\d{2}-\d{2}$", data_date)
        match_month = re.match(r"^\d{4}-\d{2}$", data_date)
        if not match_day and not match_month:
            raise ProcessError("date format should like YYYY-MM-DD")
        self.data_date = data_date
        self.app_config = app_config
        if settings.log_config and not self.logger:
            self.init_logger()
        if settings.mail_config and not self.monitor_mail:
            self.init_mail()
        if self.task_type != TaskType.TASK_TYPE_CHECK:
            today = datetime.datetime.today()
            next_month = date_tool.get_next_month(data_date)
            sett_end_date = datetime.datetime.strptime("{}-06".format(next_month), "%Y-%m-%d")
            if today > sett_end_date:  # 有少部分任务可能在6号跑
                error_message = "can not rerun history data : {}".format(data_date)
                self.logger.error(error_message)
                raise ProcessError(error_message)
        self.is_init = True
        return ResultCode.CODE_OK

    def init_redis_cluster(self, cluster_redis_config):
        nodes_list = []
        for node in cluster_redis_config.node_list:
            node_dict = {"host": node.split(":")[0], "port": node.split(":")[1]}
            nodes_list.append(node_dict)
        self.redis_cluster = rediscluster.RedisCluster(startup_nodes=nodes_list,
                                                       password=cluster_redis_config.password, decode_responses=True)
        return ResultCode.CODE_OK

    def init_redis_connect(self, redis_config):
        self.redis = redis.Redis(host=redis_config.host, port=redis_config.port, password=redis_config.password,
                                 decode_responses=True)
        return ResultCode.CODE_OK

    def finish(self):
        self.is_init = False
        if self.monitor_mail and not isinstance(self.monitor_mail, ProcessMail):
            self.monitor_mail.close()
            self.monitor_mail = None
        if self.logger and self.logger_handler:
            self.logger_handler.close()
            self.logger.removeHandler(self.logger_handler)
            self.logger_handler = None
            self.logger = None
        if self.redis:
            self.redis = None

    def do_job(self, data_date):
        pass
        return ResultCode.CODE_OK
