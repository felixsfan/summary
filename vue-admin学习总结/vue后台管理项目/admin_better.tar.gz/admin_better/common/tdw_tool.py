#!/usr/bin/env python
# -*- coding:utf-8 -*-
import sys
import re
import time
import json
import datetime
import logging
import requests
from ..config import settings
from .common_define import ResultCode
from .tdw_authentication import TdwAuthentication


class TdwTaskStatus(object):
    SUCCESS_STATUS_ID = "2"
    FAILED_STATUS_IDS = ("8", "3", "4", "6")
    PROCESSING_STATUS_IDS = ("0", "9", "1", "7", "6")
    DEFAULT_STATUS_ID = "4"
    SLEEP_SECONDS = 600

    def __init__(self):
        self.state = ""
        self.desc = ""
        self.post_url = "http://tdwopen.oa.com/Uscheduler/QueryTaskRun"
        self.tdw_auth = None

    def query_task_state(self, task_id, data_date, timeout=0, logger=None):
        if logger is None:
            logger = logging.getLogger()
        if len(data_date) == 7:
            match_result = re.match(r"^\d{4}-\d{2}$", data_date)  # match month
        else:
            match_result = re.match(r"^\d{4}-\d{2}-\d{2}$", data_date)  # match day
        if match_result is None:  # result.group()
            logger.error("date format should like YYYY-MM-DD")
            return ResultCode.CODE_PARA_INVALID

        tdw_date = data_date + " 00:00:00"
        body_data = {"startTime": tdw_date, "endTime": tdw_date, "pageSize": 1, "task_id": task_id}
        if not self.tdw_auth:
            self.tdw_auth = TdwAuthentication(settings.tdw_config.tdw_user, settings.tdw_config.tdw_cmk,
                                              "Common-Scheduler")
        authentication = self.tdw_auth.get_authentication()

        last_time = time.time()
        while True:
            try:
                # response = requests.post(self.post_url, body_data)
                response = requests.post(url=self.post_url, headers=authentication, data=body_data)
                http_result = response.json()
                # print(http_result)
                status_id = self.DEFAULT_STATUS_ID
                if http_result and "state" in http_result[0] and "success" == http_result[0]["state"]:
                    if "desc" in http_result[0]["desc"]:
                        task_info_list = json.loads(http_result[0]["desc"])
                        status_id = task_info_list[0]["state"]
            except ConnectionError as error:
                logger.error("http error: {}".format(error))
                status_id = self.DEFAULT_STATUS_ID

            if self.SUCCESS_STATUS_ID == status_id:
                logger.debug("{} {} success".format(task_id, data_date))
                task_stat = ResultCode.CODE_TASK_SUCCESS
                break
            elif status_id in self.FAILED_STATUS_IDS:
                logger.debug("{} {} failed".format(task_id, data_date))
                task_stat = ResultCode.CODE_TASK_FAILED
            else:
                logger.debug("{} {} running".format(task_id, data_date))
                task_stat = ResultCode.CODE_TASK_RUNNING
            now_time = time.time()
            if now_time - last_time > timeout:
                break
            else:
                logger.error("check failed, sleep {} seconds and check again".format(self.SLEEP_SECONDS))
                time.sleep(self.SLEEP_SECONDS)
        # end while
        return task_stat

    def query_task_until(self, task_id, data_date, until_time, logger=None):
        while True:
            task_stat = self.query_task_state(task_id, data_date, 0, logger)
            if task_stat == ResultCode.CODE_TASK_SUCCESS:
                break
            now_time = datetime.datetime.now()
            if now_time >= until_time:
                break
            logger.debug("need try again, sleep 600")
            time.sleep(600)
        # end while
        return task_stat

    def query_task_time_out(self, task_id, data_date, time_out, logger=None):
        until_time = datetime.datetime.now() + time_out
        return self.query_task_until(task_id, data_date, until_time, logger)


if "__main__" == __name__:
    tdw_checker = TdwTaskStatus()
    # tdw_checker.query_task_until(sys.argv[1], sys.argv[2], sys.argv[3])
    task_status = tdw_checker.query_task_state(sys.argv[1], sys.argv[2])
    print("task {}, status {}".format(sys.argv[1], task_status))
