#!/bin/sh

if [ $# -ne 2 ]
then
	echo "$0: locale_file hdfs_path"
	exit 0
fi
locale_file="$1"
hdfs_path="$2"

if [ -s "${locale_file}" ];then
    index=0
    suc_flag=0
    while [ ${index} -lt 3 ] && [ $suc_flag -eq 0 ]
    do
        if [ ${index} -ne 0 ];then
            sleep 20
        fi
        file_name="${locale_file##*/}"    # 删除*/的最长匹配
        if ! ${hadoop} -ls "${hdfs_path}"
        then 
            ${hadoop} -mkdir "${hdfs_path}"
        fi
        if ${hadoop} -put "${locale_file}" "${hdfs_path}"/"${file_name}"
        then
            local_file_size=$(ls --full-time "${locale_file}" | awk '{print $5}')
            hdfs_file_size=$($hadoop -du "${hdfs_path}"/"${file_name}" | grep "${file_name}" | awk -F' ' '{print $1}')
            if [ "${local_file_size}" -ne "${hdfs_file_size}" ]
            then
                suc_flag=0
                $hadoop -rm "${hdfs_path}"/"${file_name}"
            else
                suc_flag=1
            fi
            echo "local_file_size:$local_file_size  hdfs_file_size:$hdfs_file_size"
        else
            suc_flag=0
            $hadoop -rm "${hdfs_path}"/"${file_name}"
        fi
        index=$((index + 1))
    done
else
    echo "error, ${locale_file} 文件不存在或大小为0"
fi

$hadoop -ls "${hdfs_path}"/"${file_name}"
