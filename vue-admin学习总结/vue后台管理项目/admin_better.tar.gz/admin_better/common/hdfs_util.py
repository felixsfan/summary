#!/usr/bin/env python
# -*- coding=utf-8 -*-
import re
import sys
import time
import shutil
import pathlib
import datetime
import invoke
from revenue.config import settings
from . import settle_base
from .common_define import ResultCode, ProcessError


class HdfsPuller(settle_base.SettleBase):
    def __init__(self, logger=None, monitor_mail=None):
        super(HdfsPuller, self).__init__(logger=logger, monitor_mail=monitor_mail)
        self.data_date8 = ""
        self.hadoop_client_cmd = ""
        self.tag_name = ""
        self.save_file_path = None
        self.save_file_name = ""
        self.hdfs_file_path = ""
        self.hdfs_check_file = ""
        self.flag_file_name = ""
        self.max_save_days = 35
        self.send_alarm_time = None
        self.wait_until_time = None
        self.backup_file_cmd = ""

    def initialize(self, app_config, data_date):
        if self.is_init:
            return ResultCode.CODE_OK
        super(HdfsPuller, self).initialize(app_config, data_date)
        self.data_date8 = self.data_date.replace("-", "")

        return ResultCode.CODE_OK

    def finish(self):
        super(HdfsPuller, self).finish()

    def parse_hdfs_conf(self, hdfs_file_config):
        """解析配置，判断是否已拉取过"""
        self.hadoop_client_cmd = settings.HADOOP_CLIENT
        self.tag_name = hdfs_file_config.tag_name
        self.save_file_path = pathlib.Path(settings.water_file_config.water_file_path)
        self.save_file_name = hdfs_file_config.water_file_name.replace("YYYYMMDD", self.data_date8)
        self.hdfs_file_path = hdfs_file_config.hdfs_file_path.replace("YYYYMMDD", self.data_date8)
        self.hdfs_check_file = hdfs_file_config.hdfs_check_file.replace("YYYYMMDD", self.data_date8)
        # self.backup_file_cmd = hdfs_file_config.backup_file_cmd
        self.max_save_days = settings.water_file_config.max_save_days
        send_alarm_time = settings.water_file_config.send_alarm_time
        wait_until_time = settings.water_file_config.wait_until_time
        time_delta = datetime.time(hour=int(send_alarm_time[0:2]), minute=int(send_alarm_time[3:5]),
                                   second=int(send_alarm_time[6:8]))
        self.send_alarm_time = datetime.datetime.combine(datetime.date.today(), time_delta)
        time_delta = datetime.time(hour=int(wait_until_time[0:2]), minute=int(wait_until_time[3:5]),
                                   second=int(wait_until_time[6:8]))
        self.wait_until_time = datetime.datetime.combine(datetime.date.today(), time_delta)
        if not self.save_file_path or not self.save_file_name:   # 配置为空则失败
            raise ProcessError("save path or save file is empty")
        # 保持文件路径，不存在则创建
        if not self.save_file_path.exists():
            self.save_file_path.mkdir(parents=True)
        # 如果已拉取过，则直接退出
        self.flag_file_name = str(pathlib.Path(self.save_file_name).with_suffix(".check"))
        flag_file_path = self.save_file_path / self.flag_file_name
        self.logger.debug("flag file is {}".format(flag_file_path))
        if flag_file_path.exists():
            self.logger.debug("{} exist".format(flag_file_path))
            return ResultCode.CODE_FILE_EXIST
        return ResultCode.CODE_OK

    def check_hdfs_file(self):
        """检查hdfs文件是否准备好"""
        if not self.hdfs_check_file:
            return ResultCode.CODE_OK
        ls_hdfs_cmd = "{} -ls {}".format(self.hadoop_client_cmd, self.hdfs_check_file)
        self.logger.debug(ls_hdfs_cmd)
        result_code = ResultCode.CODE_OK
        is_alarm_send = False
        while True:
            invoke_result = invoke.run(ls_hdfs_cmd, hide=True, warn=True)
            now_time = datetime.datetime.now()
            self.logger.debug("hdfs ls result is {}".format(invoke_result.stdout))
            if invoke_result.ok and self.hdfs_check_file in invoke_result.stdout:
                self.logger.info("{} ready {}".format(self.save_file_name, now_time.strftime("%Y-%m-%d %H:%M:%S")))
                break
            else:
                if now_time > self.wait_until_time:
                    result_code = ResultCode.CODE_HDFS_EMPTY
                    self.logger.error("error {} not ready until {}, quit".
                                      format(self.save_file_name, now_time.strftime("%Y-%m-%d %H:%M:%S")))
                    break
                elif now_time > self.send_alarm_time and not is_alarm_send:
                    alarm_message = "note : {} not ready until {}".\
                        format(self.save_file_name, now_time.strftime("%Y-%m-%d %H:%M:%S"))
                    self.logger.info(alarm_message)
                    if self.monitor_mail:
                        self.monitor_mail.send_alarm_message(alarm_message)
                    is_alarm_send = True
                time.sleep(30)
        # end while
        if result_code != ResultCode.CODE_OK:
            raise ProcessError("hdfs file {} not ready ".format(self.save_file_name))
        return result_code

    def pull_hdfs_file(self):
        """拉取hdfs数据，并合作文件"""
        # 创建临时文件目录
        temp_hdfs_path = self.save_file_path / "temp_{}".format(self.tag_name)
        self.logger.debug("temp hdfs path is {}".format(temp_hdfs_path))
        if temp_hdfs_path.exists() and temp_hdfs_path.is_dir():
            self.logger.debug("rmdir {}".format(temp_hdfs_path))
            shutil.rmtree(str(temp_hdfs_path))
        temp_hdfs_path.mkdir(parents=True)
        # 拉取数据
        get_hdfs_cmd = "{} -get {}/* {}".format(self.hadoop_client_cmd, self.hdfs_file_path, temp_hdfs_path)
        self.logger.debug(get_hdfs_cmd)
        invoke_result = invoke.run(get_hdfs_cmd, hide=True, warn=True)
        if not invoke_result.ok:
            error_message = "error pull {} hdfs file failed：{}".format(self.save_file_name, invoke_result.stderr)
            self.logger.error(error_message)
            if self.monitor_mail:
                self.monitor_mail.send_alarm_message(error_message)
            return ResultCode.CODE_PULL_FAILED
        # 合并压缩数据
        self.logger.debug("hadoop {} finish, start merge file to {}".format(self.tag_name, self.save_file_name))
        if self.save_file_name.endswith(".tar.gz") or self.save_file_name.endswith(".tgz"):
            merge_cmd = "tar -czvf {}/{} {}/attempt_*". \
                format(self.save_file_path, self.save_file_name, temp_hdfs_path)
        elif self.save_file_name.endswith(".gz"):
            merge_cmd = "gzip -c {}/attempt_* > {}/{}". \
                format(temp_hdfs_path, self.save_file_path, self.save_file_name)
        else:
            merge_cmd = "cat {}/attempt_* > {}/{}". \
                format(temp_hdfs_path, self.save_file_path, self.save_file_name)
        self.logger.debug(merge_cmd)
        invoke_result = invoke.run(merge_cmd, hide=True, warn=True)
        if not invoke_result.ok:
            self.logger.error("error merge {} failed：{}".format(self.save_file_name, invoke_result.stderr))
            return ResultCode.CODE_MERGE_FAILED
        # 写完成flag文件
        flag_cmd = "du -sb {}/{} > {}/{}".format(self.save_file_path, self.save_file_name,
                                                 self.save_file_path, self.flag_file_name)
        self.logger.debug(flag_cmd)
        invoke_result = invoke.run(flag_cmd, hide=True, warn=True)
        if not invoke_result.ok:
            self.logger.error("error write flag {} failed：{}".format(self.save_file_name, invoke_result.stderr))
        # 删除临时文件目录
        if temp_hdfs_path.exists() and temp_hdfs_path.is_dir():
            self.logger.debug("rmdir {}".format(temp_hdfs_path))
            shutil.rmtree(str(temp_hdfs_path))

        return ResultCode.CODE_OK

    def back_delete_history_file(self):
        # if not self.backup_file_cmd:
        #     return ResultCode.CODE_OK
        data_day = datetime.datetime.strptime(self.data_date, "%Y-%m-%d")
        back_day = data_day - datetime.timedelta(days=self.max_save_days)
        back_date = back_day.strftime("%Y%m%d")
        history_file = self.save_file_path / self.save_file_name.replace(self.data_date8, back_date)
        self.logger.debug("will delete file: {}".format(history_file))
        # 备份历史文件
        # if history_file.exists() and self.backup_file_cmd:
        #     backup_file_cmd = self.backup_file_cmd.replace("xxx_backup_file_xxx", str(history_file))
        #     self.logger.debug("back file before delete use cmd: {}".format(backup_file_cmd))
        #     invoke_result = invoke.run(backup_file_cmd, hide=True, warn=True)
        #     if not invoke_result.ok:
        #         error_message = "error back file {} failed：{}".format(history_file, invoke_result.stderr)
        #         self.logger.error(error_message)
        #         if self.monitor_mail:
        #             self.monitor_mail.send_alarm_message(error_message)
        # 删除历史文件
        if history_file.exists():
            history_file.unlink()
        flag_file_path = self.save_file_path / self.flag_file_name.replace(self.data_date8, back_date)
        if flag_file_path.exists():
            flag_file_path.unlink()
        return ResultCode.CODE_OK

    def pull_water_file(self, data_date, water_file_config):
        try:
            self.logger.info("")
            self.logger.info("===== start {} =====".format(self.__class__.__name__))
            self.data_date = data_date
            self.data_date8 = data_date.replace("-", "")
            result = self.parse_hdfs_conf(water_file_config)
            if result == ResultCode.CODE_FILE_EXIST:
                return result
            self.check_hdfs_file()
            result = self.pull_hdfs_file()
            if result == ResultCode.CODE_PULL_FAILED or result == ResultCode.CODE_MERGE_FAILED:
                result = self.pull_hdfs_file()   # 如果失败再试一次
            if result != ResultCode.CODE_OK:
                raise ProcessError("pull file {} failed:{}".format(self.save_file_name, result))
            self.back_delete_history_file()
        finally:
            if not self.process_lock and self.monitor_mail:
                self.monitor_mail.send_mail()
            if self.logger:
                self.logger.info("")
                self.logger.info("===== end {} =====".format(self.__class__.__name__))
            self.finish()
        return ResultCode.CODE_OK


if "__main__" == __name__:
    if len(sys.argv) < 2:
        print("usage {} YYYYY-MM-DD".format(sys.argv[0]))
        sys.exit()
    process_date = sys.argv[1]
    match_result = re.match(r'^\d{4}-\d{2}-\d{2}$', process_date)
    if match_result is None:
        print("error usage: {} YYYY-MM-DD".format(sys.argv[0]))
        sys.exit()
    file_puller = HdfsPuller()
    file_puller.initialize(settings.tob_sale_count, process_date)
