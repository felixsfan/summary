import base64
import json
import socket
import uuid
import random
import datetime
import requests
import pyDes


class TdwAuthentication:
    def __init__(self, user_name, cmk, target, proxy_user=None):
        super().__init__()
        self.user_name = user_name
        self.cmk = cmk
        self.expire = True
        self.expire_time_stamp = int(datetime.datetime.timestamp(datetime.datetime.now()))*1000
        self.proxy_user = proxy_user
        self.ip = self.get_host_ip()
        self.sequence = random.randint(0, 999)
        self.identifier = {
            "user": self.user_name,
            "host": self.ip,
            "target": target,
            "lifetime": 7200000
        }

        self.client_authenticator = {
            "principle": self.user_name,
            "host": self.ip
        }
        self.session_ticket = ""
        self.service_ticket = ""
        self.session_key = ""

    @staticmethod
    def get_host_ip():
        temp_socket = None
        try:
            temp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            temp_socket.connect(('8.8.8.8', 80))
            ip = temp_socket.getsockname()[0]
        finally:
            if temp_socket:
                temp_socket.close()
        return ip

    def get_session_ticket(self):
        request_url = "http://auth.tdw.oa.com/api/auth/st2"

        self.identifier["timestamp"] = int(datetime.datetime.timestamp(datetime.datetime.now()))
        identifier_body = base64.b64encode(bytes(json.dumps(self.identifier), 'utf8'))
        response = requests.get(request_url, params={"ident": identifier_body})
        self.session_ticket = response.text

    def decrypt_client_ticket(self):
        session_ticket = json.loads(self.session_ticket)
        self.service_ticket = session_ticket["st"]
        client_ticket = session_ticket["ct"]
        client_ticket = base64.b64decode(client_ticket)
        cmk = bytes.fromhex(base64.b64decode(self.cmk).decode('utf8'))
        des_ede = pyDes.triple_des(cmk, pyDes.ECB, padmode=pyDes.PAD_PKCS5)
        client_ticket = json.loads(str(des_ede.decrypt(client_ticket), 'utf8'))
        self.expire_time_stamp = client_ticket["timestamp"] + client_ticket["lifetime"]
        self.session_key = base64.b64decode(client_ticket['sessionKey'])

    def construct_authentication(self):
        self.client_authenticator["timestamp"] = int(datetime.datetime.timestamp(datetime.datetime.now()))*1000
        self.client_authenticator["nonce"] = uuid.uuid1().hex
        self.client_authenticator["sequence"] = self.sequence
        self.sequence += 1
        if self.proxy_user:
            self.client_authenticator["proxyUser"] = self.proxy_user
        client_authenticator = bytes(json.dumps(self.client_authenticator), 'utf8')

        des_ede = pyDes.triple_des(self.session_key, pyDes.ECB, padmode=pyDes.PAD_PKCS5)
        client_authenticator = des_ede.encrypt(client_authenticator)
        authentication = "tauth." + self.service_ticket + "." + str(base64.b64encode(client_authenticator), 'utf8')
        return {"secure-authentication": authentication}

    def is_expire(self):
        return self.expire_time_stamp <= int(datetime.datetime.timestamp(datetime.datetime.now()))*1000

    def get_authentication(self):
        if self.is_expire():
            self.get_session_ticket()
            self.decrypt_client_ticket()
        return self.construct_authentication()
