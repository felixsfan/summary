#!/usr/bin/env python3
# coding=utf-8
import sys
import time
import logging
import logging.handlers
import mysql.connector
import mysql.connector.errorcode
from .common_define import ProcessError, ResultCode


class MysqlClient(object):
    DB_CLIENT_DICT = {}
    CHARACTER_SET_SET = {"latin1", "utf8", "gbk", "gb2312"}

    def __init__(self):
        self.host = ""
        self.port = 3306
        self.user = ""
        self.pass_word = ""
        self.connect_timeout = 5
        self.connect_character = ""
        self.connection = None
        self.cursor = None
        self.db_type = "mysql"
        self.charset = "utf8"
        self.is_init = False
        self.character_set_client = "latin1"
        self.character_set_connection = "latin1"
        self.character_set_results = "latin1"
        self.is_character_changed = False
        self.ref_count = 1
        self.logger = None
        self.retry_error_code = (mysql.connector.errorcode.CR_SERVER_GONE_ERROR,
                                 mysql.connector.errorcode.CR_SERVER_LOST,
                                 mysql.connector.errorcode.CR_SERVER_LOST_EXTENDED)
        self.retry_count = 10
        self.connection_id = -1

    def init_connect(self, db_config, charset='utf8', is_unicode=True, logger=None, use_pure=None):
        if logger is None:
            logger = logging.getLogger()
            stdout_handler = logging.StreamHandler(sys.stdout)
            logger.addHandler(stdout_handler)
        self.logger = logger
        self.host = db_config.host
        self.port = db_config.port
        self.user = db_config.user
        self.pass_word = db_config.password
        self.connect_timeout = db_config.timeout
        self.connect_character = charset
        try:
            if use_pure:
                self.connection = mysql.connector.connect(
                    host=self.host, port=self.port, user=self.user, passwd=self.pass_word,
                    connection_timeout=self.connect_timeout, charset=self.charset, use_unicode=is_unicode,
                    use_pure=use_pure)
            else:
                self.connection = mysql.connector.connect(
                    host=self.host, port=self.port, user=self.user, passwd=self.pass_word,
                    connection_timeout=self.connect_timeout, charset=self.charset, use_unicode=is_unicode)
            self.logger.debug("init connect mysql {}:{}".format(self.host, self.port))
            self.cursor = self.connection.cursor(dictionary=True)
            self.is_init = True
            if self.connect_character:
                self.cursor.execute("set names {}".format(self.connect_character))
        except mysql.connector.Error as error:
            self.is_init = False
            self.logger.error("init connect mysql {}:{} error: {}".format(self.host, self.port, error))
            raise ProcessError("connect {}:{} error {}".format(self.host, self.port, error.args[1]))
        self.connection_id = self.connection.connection_id
        return ResultCode.CODE_OK

    def reconnect(self):
        if self.connection:
            self.connection.reconnect()
            self.connection_id = self.connection.connection_id

    def get_share_client(self):
        self.ref_count += 1
        return self

    def execute(self, sql, need_fetch=False, auto_commit=False):
        """
        由于MySQL Connector / Python是Python DB API兼容的，因此默认情况下将禁用自动提交，并且第一个SQL语句将隐式开始事务。 您必须调用connection.commit提交事务。
        select语句需要在fetch数据后commit，否则会导致无法读取到其他事务写入的数据。
        仅当autocommit=True时才需要start_transaction()方法开启事务。
        """
        index = 0
        need_reconnect = False
        db_return = None
        error_info = ""
        while index < self.retry_count:
            try:
                if need_reconnect:   # 重新连接DB
                    self.connection.reconnect()
                    self.connection_id = self.connection.connection_id
                    need_reconnect = False
                self.cursor.execute(sql)
                if need_fetch:
                    db_return = self.cursor.fetchall()
                if auto_commit:
                    self.connection.commit()
                error_info = ""
                break    # 一切正常，则退出
            except mysql.connector.Error as error:
                error_info = "sql {} error {}".format(sql, error)
                time.sleep(30)
                if error.errno in self.retry_error_code:
                    need_reconnect = True
                    self.logger.error(f"mysql error {error}, try again {index}")
                else:
                    self.logger.error("mysql error {}".format(error))
                    break
            finally:
                index += 1
        # end while
        if error_info:
            raise ProcessError(error_info)
        return db_return

    def query(self, sql):
        return self.execute(sql, True, True)

    def update(self, sql, auto_commit=True):
        self.execute(sql, False, auto_commit)
        return ResultCode.CODE_OK

    def commit(self):
        try:
            self.connection.commit()
        except mysql.connector.Error as error:
            self.logger.error("mysql error {}".format(error))
            raise ProcessError("commit error {}".format(error))
        return ResultCode.CODE_OK

    # 暂时没有使用
    def execute_many(self, sql, value_list):
        index = 0
        result = ResultCode.CODE_OK
        while index < self.retry_count:
            try:
                self.cursor.executemany(sql, value_list)
                self.connection.commit()
                result = ResultCode.CODE_OK
            except mysql.connector.Error as error:
                result = ResultCode.CODE_ERROR
                if error.errno == mysql.connector.errorcode.CR_SERVER_GONE_ERROR:
                    self.logger.error("mysql error {}, try again".format(error))
                    self.connection.reconnect()
                else:
                    self.logger.error("mysql error {}, quit".format(error))
                    break
            finally:
                index += 1
        # end while
        return result

    def close(self):
        self.ref_count -= 1
        if self.is_init and self.ref_count == 0:
            self.cursor.close()
            self.connection.close()
            self.is_init = False

    def get_character_set(self):
        sql = "show variables like 'character_set%%'"
        result = self.query(sql)
        for item in result:
            name = item["Variable_name"]
            value = item["Value"]
            if "character_set_client" == name:
                self.character_set_client = value
            elif "character_set_connection" == name:
                self.character_set_connection = value
            elif "character_set_results" == name:
                self.character_set_results = value
        # end for
        return ResultCode.CODE_OK

    def set_character_set(self, character_set):
        if character_set not in self.CHARACTER_SET_SET:
            self.logger.error("mysql error: not support character set {}".format(character_set))
            raise ProcessError("mysql error: not support character set {}".format(character_set))
        self.get_character_set()
        if character_set != self.character_set_client \
                or character_set != self.character_set_connection or character_set != self.character_set_results:
            sql = "set names {}".format(character_set)
            self.update(sql)
            self.is_character_changed = True
        # end if
        return ResultCode.CODE_OK

    def restore_character_set(self):
        if not self.is_character_changed:
            return ResultCode.CODE_OK
        sql_list = []
        sql = "set character_set_client={};" .format(self.character_set_client)
        sql_list.append(sql)
        sql = "set character_set_connection={};".format(self.character_set_connection)
        sql_list.append(sql)
        sql = "set character_set_results={};".format(self.character_set_results)
        sql_list.append(sql)
        for sql in sql_list:
            self.update(sql)
        # end for
        self.is_character_changed = False
        return ResultCode.CODE_OK

    @staticmethod
    def convert_latin1_chinese(latin1_string):
        return latin1_string.encode("latin1", "ignore").decode("gbk", "ignore")
