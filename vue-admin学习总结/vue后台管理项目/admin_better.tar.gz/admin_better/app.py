#!/usr/bin/env python3
# encoding: utf-8
# @Time    : 2022/1/23 3:00 下午
import logging
import os

from flask import Flask
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy

from config import db_configs

'''
统一一下状态码
请求正确 20000
密码错误 -1
token验证失败 -2
'''

# 初始化组件对象, 延后关联Flask应用
db = SQLAlchemy()

# 创建应用
flask_app = Flask(__name__)
CORS(flask_app, supports_credentials=True)


def init_app():
    """工厂函数"""

    # 加载配置
    flask_app.config.from_object(db_configs)

    # 数据库连接关联flask应用
    db.init_app(flask_app)

    # 初始化蓝图
    init_blue(flask_app)

    # 初始化日志
    init_log(flask_app)

    return flask_app


def init_blue(flask_app):
    # 避免循环引用
    from controller.user_controller import user_blue
    from controller.table_controller import table_blue
    from controller.task_controller import task_blue
    from controller.export_controller import export_blue
    from controller.select_controller import select_blue
    flask_app.register_blueprint(user_blue)
    flask_app.register_blueprint(table_blue)
    flask_app.register_blueprint(task_blue)
    flask_app.register_blueprint(export_blue)
    flask_app.register_blueprint(select_blue)


def init_log(flask_app):
    handler = logging.FileHandler('flask.log', encoding='UTF-8')  # 设置日志字符集和存储路径名字
    logging_format = logging.Formatter(  # 设置日志格式
        '%(asctime)s - %(levelname)s - %(filename)s - %(funcName)s - %(lineno)s - %(message)s')
    handler.setFormatter(logging_format)
    flask_app.logger.addHandler(handler)


if __name__ == '__main__':
    app = init_app()
    os.environ['ENV_FOR_DYNACONF'] = 'production'
    # os.environ['ENV_FOR_DYNACONF'] = 'development'  # 初始化环境
    # app.run(host='0.0.0.0', port=8080, debug=True)
    app.run(port=8082, debug=True)
