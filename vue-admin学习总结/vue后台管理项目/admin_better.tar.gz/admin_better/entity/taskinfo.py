#!/usr/bin/env python3
# encoding: utf-8
# @Time    : 2022/2/23 12:47 下午
# !/usr/bin/env python3
# encoding: utf-8
# @Time    : 2022/1/24 2:47 下午
from app import db


class TaskInfo(db.Model):
    # 表的名字
    __tablename__ = 'taskinfo'

    taskid = db.Column(db.String(30), primary_key=True)
    task_describe = db.Column(db.String(100))  # 加task_的原因是describe等是数据库关键字
    task_path = db.Column(db.String(100))
    task_order = db.Column(db.String(100))
    task_begin = db.Column(db.String(20))
    task_end = db.Column(db.String(20))
    task_status = db.Column(db.String(10))

    def __init__(self, taskid, task_describe, task_path, task_order, task_begin, task_end, task_status):
        self.taskid = taskid
        self.task_describe = task_describe
        self.task_path = task_path
        self.task_order = task_order
        self.task_begin = task_begin
        self.task_end = task_end
        self.task_status = task_status
