#!/usr/bin/env python3
# encoding: utf-8
# @Time    : 2022/1/24 2:47 下午
from app import db


class User(db.Model):
    # 表的名字
    __tablename__ = 'user'

    username = db.Column(db.String(100), primary_key=True)
    password = db.Column(db.String(100))
    roles = db.Column(db.String(200))
    avatar = db.Column(db.String(500))
    token = db.Column(db.String(500))

    def __init__(self, username, password, roles, avatar, token):
        self.username = username
        self.password = password
        self.roles = roles
        self.avatar = avatar
        self.token = token

    def get_name(self):
        return self.username

    def set_name(self, username):
        self.username = username

    def get_password(self):
        return self.password

    def set_password(self, password):
        self.password = password

    def get_roles(self):
        return self.roles

    def set_roles(self, roles):
        self.roles = roles

    def get_avatar(self):
        return self.avatar

    def set_avatar(self, avatar):
        self.avatar = avatar

    def get_token(self):
        return self.token

    def set_token(self, token):
        self.token = token
