#!/usr/bin/env python3
# encoding: utf-8
# @Time    : 2022/2/20 5:52 下午

from config import settings

day_db_config = settings.day_db_config
month_db_config = settings.month_db_config

DB_URI = "mysql+pymysql://{username}:{password}@{host}:{port}".format(username=day_db_config.user,
                                                                      password=day_db_config.password,
                                                                      host=day_db_config.host,
                                                                      port=day_db_config.port)
SQLALCHEMY_BINDS = {
    'month_db': "mysql+pymysql://{username}:{password}@{host}:{port}".format(
        username=month_db_config.user,
        password=month_db_config.password,
        host=month_db_config.host,
        port=month_db_config.port),
    'month_db_latin1': "mysql+pymysql://{username}:{password}@{host}:{port}".format(
        username=month_db_config.user,
        password=month_db_config.password,
        host=month_db_config.host,
        port=month_db_config.port),
    'day_db_latin1': "mysql+pymysql://{username}:{password}@{host}:{port}".format(
        username=month_db_config.user,
        password=month_db_config.password,
        host=month_db_config.host,
        port=month_db_config.port),
    'day_db_admin_better': "mysql+pymysql://{username}:{password}@{host}:{port}/admin_better".format(
        username="root",
        password="root",
        host="localhost",
        port=3306)
}

SQLALCHEMY_DATABASE_URI = DB_URI
SQLALCHEMY_TRACK_MODIFICATIONS = False
SQLALCHEMY_ECHO = True
