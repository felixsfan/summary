#!/usr/bin/env python3
# coding=utf-8
from dynaconf import Dynaconf
from dynaconf.constants import DEFAULT_SETTINGS_FILES

# connection
# REDIS_FOR_DYNACONF = {
#     "host": "ip_address",
#     "port": 6383,
#     "password": "xxxxxx",
#     "db": 0,
#     "decode_responses": True
# }

# and loader
LOADERS_FOR_DYNACONF = [
    "dynaconf.loaders.env_loader",
    "dynaconf.loaders.redis_loader"
]

settings = Dynaconf(
    settings_files=["settings.toml", ".secrets.toml", "hdfs_file_settings.toml"],
    warn_dynaconf_global_settings=True,
    environments=True,
    lowercase_read=True,
    load_dotenv=True,
    default_settings_paths=DEFAULT_SETTINGS_FILES,
    # loaders=LOADERS_FOR_DYNACONF,
    # redis=REDIS_FOR_DYNACONF
)
