#!/usr/bin/env python3
# coding=utf-8
from revenue.common import KEY_SEPARATOR
from .sett_define import SpoaInfo, OfferInfo, PartnerInfo, ChannelInfo

key_sep = "::"


def get_spoa_info(sett_db, logger):
    """获取业务代码的相关信息
    :param sett_db: 结算DB的client
    :param logger:  logger
    :return:  业务代码信息的dict
    """
    sett_group_name_dict = {}
    busi_group_name_dict = {}
    dept_name_dict = {}
    fee_type_name_dict = {}
    sql = "select Fvalue,Fname from db_spoa.t_code where Fcode_type='SETT_GROUP'"
    logger.debug(sql)
    result = sett_db.query(sql)
    for item in result:
        sett_group_name_dict[item["Fvalue"]] = sett_db.convert_latin1_chinese(item["Fname"])

    sql = "select Fvalue,Fname from db_spoa.t_code where Fcode_type='BUSI_GROUP'"
    logger.debug(sql)
    result = sett_db.query(sql)
    for item in result:
        busi_group_name_dict[item["Fvalue"]] = sett_db.convert_latin1_chinese(item["Fname"])

    sql = "select Fvalue,Fname from db_spoa.t_code where Fcode_type='DEPT_NO'"
    logger.debug(sql)
    result = sett_db.query(sql)
    for item in result:
        dept_name_dict[item["Fvalue"]] = sett_db.convert_latin1_chinese(item["Fname"])

    sql = "select Fvalue,Fname from db_spoa.t_code where Fcode_type='FEE_TYPE'"
    logger.debug(sql)
    result = sett_db.query(sql)
    for item in result:
        fee_type_name_dict[item["Fvalue"]] = sett_db.convert_latin1_chinese(item["Fname"])

    sql = "select Foss_sid,Fservice_name,Fsett_group,Fbusi_group,Fdept,Ffee_type,Ffee_value from db_spoa.t_oss_sid"
    logger.debug(sql)
    result = sett_db.query(sql)
    spoa_info_dict = {}
    for item in result:
        spoa_id = item["Foss_sid"]
        spoa_info = SpoaInfo(spoa_id)
        spoa_info.spoa_name = sett_db.convert_latin1_chinese(item["Fservice_name"])
        spoa_info.sett_group = item["Fsett_group"]
        spoa_info.busi_group = item["Fbusi_group"]
        spoa_info.dept = str(item["Fdept"])
        spoa_info.fee_type = str(item["Ffee_type"])
        spoa_info.fee_value = int(item["Ffee_value"])
        if spoa_info.sett_group in sett_group_name_dict:
            spoa_info.sett_group_name = sett_group_name_dict[spoa_info.sett_group]
        if spoa_info.busi_group in busi_group_name_dict:
            spoa_info.busi_group_name = busi_group_name_dict[spoa_info.busi_group]
        if spoa_info.dept in dept_name_dict:
            spoa_info.dept_name = dept_name_dict[spoa_info.dept]
        if spoa_info.fee_type in fee_type_name_dict:
            spoa_info.fee_type_name = fee_type_name_dict[spoa_info.fee_type]
        spoa_info_dict[spoa_id] = spoa_info
    # end for
    return spoa_info_dict


def get_spoa_info_latin1(sett_db, logger):
    """获取业务代码的相关信息
    :param sett_db: 结算DB的client
    :param logger:  logger
    :return:  业务代码信息的dict
    """
    sett_group_name_dict = {}
    busi_group_name_dict = {}
    dept_name_dict = {}
    fee_type_name_dict = {}
    sql = "select Fvalue,Fname from db_spoa.t_code where Fcode_type='SETT_GROUP'"
    logger.debug(sql)
    result = sett_db.query(sql)
    for item in result:
        sett_group_name = item[b"Fname"].decode("gbk", "ignore")
        sett_group_name_dict[item[b"Fvalue"].decode("latin1", "ignore")] = sett_group_name

    sql = "select Fvalue,Fname from db_spoa.t_code where Fcode_type='BUSI_GROUP'"
    logger.debug(sql)
    result = sett_db.query(sql)
    for item in result:
        busi_group_name = item[b"Fname"].decode("gbk", "ignore")
        busi_group_name_dict[item[b"Fvalue"].decode("latin1", "ignore")] = busi_group_name

    sql = "select Fvalue,Fname from db_spoa.t_code where Fcode_type='DEPT_NO'"
    logger.debug(sql)
    result = sett_db.query(sql)
    for item in result:
        dept_name = item[b"Fname"].decode("gbk", "ignore")
        dept_name_dict[item[b"Fvalue"].decode("latin1", "ignore")] = dept_name

    sql = "select Fvalue,Fname from db_spoa.t_code where Fcode_type='FEE_TYPE'"
    logger.debug(sql)
    result = sett_db.query(sql)
    for item in result:
        fee_type_name = item[b"Fname"].decode("gbk", "ignore")
        fee_type_name_dict[item[b"Fvalue"].decode("latin1", "ignore")] = fee_type_name

    sql = "select Foss_sid,Fservice_name,Fsett_group,Fbusi_group,Fdept,Ffee_type,Ffee_value from db_spoa.t_oss_sid"
    logger.debug(sql)
    result = sett_db.query(sql)
    spoa_info_dict = {}
    for item in result:
        spoa_id = item[b"Foss_sid"].decode("latin1", "ignore")
        spoa_info = SpoaInfo(spoa_id)
        spoa_info.spoa_name = item[b"Fservice_name"].decode("gbk", "ignore")
        spoa_info.sett_group = item[b"Fsett_group"].decode("latin1", "ignore")
        spoa_info.busi_group = item[b"Fbusi_group"].decode("latin1", "ignore")
        spoa_info.dept = str(item[b"Fdept"])
        spoa_info.fee_type = str(item[b"Ffee_type"])
        spoa_info.fee_value = int(item[b"Ffee_value"])
        if spoa_info.sett_group in sett_group_name_dict:
            spoa_info.sett_group_name = sett_group_name_dict[spoa_info.sett_group]
        if spoa_info.busi_group in busi_group_name_dict:
            spoa_info.busi_group_name = busi_group_name_dict[spoa_info.busi_group]
        if spoa_info.dept in dept_name_dict:
            spoa_info.dept_name = dept_name_dict[spoa_info.dept]
        if spoa_info.fee_type in fee_type_name_dict:
            spoa_info.fee_type_name = fee_type_name_dict[spoa_info.fee_type]
        spoa_info_dict[spoa_id] = spoa_info
    # end for
    return spoa_info_dict


def get_offer_info(offer_db, logger):
    offer_info_dict = {}
    sql = "select FOfferID,FOfferName,FCurrencyServiceCode,FGoodsServiceCode from " \
          "cpay_data.t_offer_book where FCurrencyServiceCode<>'' or FGoodsServiceCode<>''"
    logger.debug(sql)
    result = offer_db.query(sql)
    for item in result:
        offer_info = OfferInfo(item["FOfferID"])
        offer_info.offer_name = item["FOfferName"]
        offer_info.currency_spoa = item["FCurrencyServiceCode"]
        offer_info.goods_spoa = item["FGoodsServiceCode"]
        offer_info_dict[offer_info.offer_id] = offer_info
    # end for
    sql = "select FOfferId,FMerchantID from cpay_data.t_offer"
    logger.debug(sql)
    result = offer_db.query(sql)
    for item in result:
        if item["FOfferId"] in offer_info_dict:
            offer_info_dict[item["FOfferId"]].merchant_id = item["FMerchantID"]
    return offer_info_dict


def get_acct_info(acct_db, logger):
    # 获取业务代码与账户acct_id映射关系
    spoa_to_acct = {}
    sql = "select Fservice_code,Facct_id from db_caccts.t_caccts_svccode_map where Fservice_code<>'' " \
          "and Facct_id<>''"
    logger.debug(sql)
    result = acct_db.query(sql)
    for item in result:
        spoa_to_acct[item["Fservice_code"]] = item["Facct_id"]
    # end for
    return spoa_to_acct


def get_test_qq(tj_db, logger):
    test_num_set = set()
    sql = "select fuin from db_balance_data.autotest_fuin"
    logger.debug(sql)
    result = tj_db.query(sql)
    for item in result:
        test_num_set.add(item["fuin"])
    return test_num_set


def get_source_conf(tj_db, logger):
    source_to_sett = {}
    sql = "select Fsource_id,Fsource_name,Fchina_name,fsett_sourceid from db_bmc_stat.t_platform_dict " \
          "where Ftype='QBQD' and fstatus='Y'"
    logger.debug(sql)
    result = tj_db.query(sql)
    for item in result:
        source_to_sett[item["Fsource_id"]] = item["fsett_sourceid"]

    return source_to_sett


def get_haina_spoa(tj_db, logger):
    haina_spoa_set = set()
    sql = "select dyb_spoa_id as spoa_id from db_code.t_haina_game a left join  db_cacct_conf.t_cacct_conf b " \
          "on a.offer_id=b.offer_id where dyb_spoa_id<>'' union all " \
          "select dj_spoa_id as spoa_id from db_code.t_haina_game a left join  db_cacct_conf.t_cacct_conf b " \
          "on a.offer_id=b.offer_id  where dj_spoa_id<>'';"
    logger.debug(sql)
    result = tj_db.query(sql)
    for item in result:
        haina_spoa_set.add(item["spoa_id"])

    return haina_spoa_set


def get_monthly_packet_spoa(tj_db, logger):
    packet_spoa_set = set()
    sql = "select distinct spoa_id from db_tdw_data.t_boss_packet_info"
    logger.debug(sql)
    result = tj_db.query(sql)
    for item in result:
        packet_spoa_set.add(item["spoa_id"])
    return packet_spoa_set


def get_partner_info(sett_db, sett_month, logger):
    sett_month6 = sett_month.replace("-", "")
    sql = "select Fchannel_id,Fchannel_name,Fcopartner_id,Fcopartner_name,Fparty_no,Fparty_name,Fou_id,Fou_name," \
          "Fcustomer_type,Fcustomer_type_name from db_rule20.t_info_copartner where Fstart_date<='{}01' and " \
          "Fend_date>='{}01'".format(sett_month6, sett_month6)
    logger.debug(sql)
    result = sett_db.query(sql)
    partner_info_dict = {}
    for item in result:
        data_key = KEY_SEPARATOR.join([item["Fchannel_id"], item["Fcopartner_id"]])
        info_data = PartnerInfo(item["Fchannel_id"], item["Fcopartner_id"])
        partner_info_dict[data_key] = info_data
        info_data.channel = sett_db.convert_latin1_chinese(item["Fchannel_name"])
        info_data.sub_channel_name = sett_db.convert_latin1_chinese(item["Fcopartner_name"])
        info_data.mdm_id = item["Fparty_no"]
        info_data.mdm_name = sett_db.convert_latin1_chinese(item["Fparty_name"])
        info_data.ou_id = item["Fou_id"]
        info_data.ou_name = sett_db.convert_latin1_chinese(item["Fou_name"])
        info_data.customer_type = item["Fcustomer_type"]
        info_data.customer_type_name = sett_db.convert_latin1_chinese(item["Fcustomer_type_name"])
    # end for
    return partner_info_dict


def get_channel_info(sett_db, logger=None):
    sql = "select Fid,Fname,Ftype,Ftype_name,Fboss_channel_id from db_code.t_code_channel"
    if logger:
        logger.debug(sql)
    result = sett_db.query(sql)
    channel_info_dict = {}
    for item in result:
        channel_name = sett_db.convert_latin1_chinese(item["Fname"])
        type_name = sett_db.convert_latin1_chinese(item["Ftype_name"])
        channel_info = ChannelInfo(str(item["Fid"]), channel_name)
        channel_info.type = int(item["Ftype"])
        channel_info.type_name = type_name
        channel_info.boss_channel_id = item["Fboss_channel_id"]
        channel_info_dict[channel_info.channel_id] = channel_info
        # end for
    return channel_info_dict


# 渠道单价
def get_channel_price(sett_db, logger, data_month):
    channel_price_dict = {}
    sql = "select Fmonth,Fxh_channel_id,Fxh_currency,Fchannel_kh_price from db_qb_value.t_qbvalue_data " \
          "where Fmonth='{}' and Fcaltype_id='FN_TYPE' and (Fchan_type='PAR' or Fparent_chan_id=1013) " \
          "and Fxh_channel_id<>'' and (Fchannel_id not like 'DYB_%' or Fchannel_id='DYB_-LZQY')". \
        format(data_month)
    logger.debug(sql)
    result = sett_db.query(sql)
    for item in result:
        item["Fxh_currency"] = sett_db.convert_latin1_chinese(item["Fxh_currency"])
        price_key = item["Fxh_channel_id"] + key_sep + item["Fxh_currency"]
        channel_price_dict[price_key] = float(item["Fchannel_kh_price"])

    return channel_price_dict


def get_sub_channel_info(sett_db, logger):
    sub_channel_name_dict = {}
    sql = "select Fchannel_id,Fmerchant_id,Fmerchant_name from db_code.t_code_merchant2"
    logger.debug(sql)
    result = sett_db.query(sql)
    for item in result:
        name_key = item["Fchannel_id"] + key_sep + item["Fmerchant_id"]
        sub_channel_name_dict[name_key] = sett_db.convert_latin1_chinese(item["Fmerchant_name"])
    return sub_channel_name_dict


class SettGroupOuInfo(object):
    def __init__(self, sett_group) -> None:
        super().__init__()
        self.sett_group = sett_group
        self.sett_group_name = ""
        self.revenue_ou_id = ""
        self.revenue_ou_name = ""
        self.publish_ou_id = ""
        self.publish_ou_name = ""


def get_sett_group_ou_info(sett_db, logger):
    sett_group_ou_info_dict = {}
    sql = "select sett_group,sett_group_name,revenue_ou_id,revenue_ou_name,publish_ou_id,publish_ou_name from " \
          "db_st_data.t_sett_group_ou_info"
    logger.debug(sql)
    result = sett_db.query(sql)
    for item in result:
        sett_group_ou_info = SettGroupOuInfo(item["sett_group"])
        sett_group_ou_info.sett_group_name = item["sett_group_name"]
        sett_group_ou_info.revenue_ou_id = item["revenue_ou_id"]
        sett_group_ou_info.revenue_ou_name = item["revenue_ou_name"]
        sett_group_ou_info.publish_ou_id = item["publish_ou_id"]
        sett_group_ou_info.publish_ou_name = item["publish_ou_name"]
        sett_group_ou_info_dict[sett_group_ou_info.sett_group] = sett_group_ou_info
    return sett_group_ou_info_dict


# ==============================================移动支付========================================
class OuInfo(object):
    def __init__(self, spoa_id):
        self.spoa_id = spoa_id
        self.ou_id = ""
        self.ou_name = ""
        self.developer_account_id = ""
        self.developer_account_name = ""


def get_mobile_ou_info(sett_db, logger, data_month):
    map_spoaid_bundleid = {}
    map_bundleid_ou = {}
    map_bundleid_ouname = {}
    ou_info_dict = {}
    # 优先自动系统获取spoaid->bundleid->ou
    sql = "select distinct Fspoa_id,Fbundleid from db_mobile.t_product_pay_stat_midas_day where" \
          " Fstat_date like '{}%'".format(data_month)
    logger.debug(sql)
    result = sett_db.query(sql)
    for line in result:
        if line["Fspoa_id"] not in map_spoaid_bundleid:
            map_spoaid_bundleid[line["Fspoa_id"]] = line["Fbundleid"]

    sql = "select distinct lower(Fbundle_id) as Fbundle_id ,Fou_id,Fou_short_name from db_code.t_code_product_ou;"
    logger.debug(sql)
    result = sett_db.query(sql)
    for line in result:
        if line["Fbundle_id"] not in map_bundleid_ou:
            map_bundleid_ou[line["Fbundle_id"]] = line["Fou_id"]
        if line["Fbundle_id"] not in map_bundleid_ouname:
            map_bundleid_ouname[line["Fbundle_id"]] = sett_db.convert_latin1_chinese(line["Fou_short_name"])
    for spoaid in map_spoaid_bundleid.keys():
        ou_info = OuInfo(spoaid)
        if map_spoaid_bundleid[spoaid] in map_bundleid_ou:
            ou_info.developer_account_id = map_bundleid_ou[map_spoaid_bundleid[spoaid]]
        if map_spoaid_bundleid[spoaid] in map_bundleid_ouname:
            ou_info.developer_account_name = map_bundleid_ouname[map_spoaid_bundleid[spoaid]]
            ou_info_dict[spoaid] = ou_info
    # 之前从系统自动拉取不到，从财务获知从spoaid->ou，然后手工配置的
    sql = "select distinct Fspoa_id,Fouid,Founame from db_sett_midas.t_ou_spoa"
    logger.debug(sql)
    result = sett_db.query(sql)
    for line in result:
        if line["Fspoa_id"] not in ou_info_dict:
            ou_info = OuInfo(line["Fspoa_id"])
            ou_info.developer_account_id = line["Fouid"]
            ou_info.developer_account_name = sett_db.convert_latin1_chinese(line["Founame"])
            ou_info_dict[line["Fspoa_id"]] = ou_info
    # end if
    for spoa_id in ou_info_dict:
        ou_info = ou_info_dict[spoa_id]
        ou_info.ou_id = ou_info.developer_account_id
        ou_info.ou_name = ou_info.developer_account_name
        # 境内业务 Fou_id 统一为 102 计算机深圳 Fdeveloper_account_id为真实的ou
        # 境外业务 Fdeveloper_account_id、Fou_id都填真实的ou
        if ou_info.developer_account_id not in ["958", "1216", "756", "4113", "5968", "5354", "9496"]:
            ou_info.ou_id = "102"
            ou_info.ou_name = "计算机深圳"
        # end if
    # end for

    # 谷歌用结算组关联ou信息
    ou_to_name = {}
    sql = "select distinct Fou_id,Fou_short_name from db_sett_midas.t_code_iapaccount_ou;"
    logger.debug(sql)
    result = sett_db.query(sql)
    for line in result:
        ou_to_name[line["Fou_id"]] = sett_db.convert_latin1_chinese(line["Fou_short_name"])
    sql = "select distinct Fsett_group,Fou_id from db_sett_midas.t_midas_gw_ou;"
    logger.debug(sql)
    result = sett_db.query(sql)
    for line in result:
        ou_info = OuInfo(line["Fsett_group"])
        ou_info.ou_id = line["Fou_id"]
        ou_info.ou_name = ou_to_name[line["Fou_id"]]
        ou_info.developer_account_id = ou_info.ou_id
        ou_info.developer_account_name = ou_info.ou_name
        ou_info_dict[line["Fsett_group"]] = ou_info

    return ou_info_dict
