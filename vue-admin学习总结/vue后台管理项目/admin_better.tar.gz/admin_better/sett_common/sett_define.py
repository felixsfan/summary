#!/usr/bin/env python3
# -*- coding=utf-8 -*-
import enum


class CurrencyDefine(object):
    CURRENCY_RMB = "RMB"
    CURRENCY_CNY = "CNY"
    CURRENCY_OPEN = "第三方游戏币"
    CURRENCY_QB = "QB"
    CURRENCY_QD = "10Q点"
    CURRENCY_CNY = "CNY"
    CURRENCY_COUPON = "COUPON"


class ChannelDefine(object):
    CHANNEL_QB = "3"
    CHANNEL_QD = "126"
    CHANNEL_ESALES = "10"
    CHANNEL_QQCARD = "13"
    CHANNEL_BANK = "31"
    CHANNEL_WECHAT = "1520"
    CHANNEL_OFFLINE_REFUND = "32000"
    CHANNEL_MPAY = "144"
    CHANNEL_PHONE = "9"
    CHANNEL_APPLE = "1519"
    CHANNEL_GOOGLE = "1537"
    CHANNEL_TOB_SALE = "804"
    CHANNEL_ECNY = "5120"
    CHANNEL_NAME_TO_ID = {"wechat": CHANNEL_WECHAT, "wechatapp": CHANNEL_WECHAT,
                          "qqwallet": CHANNEL_BANK, "bank": CHANNEL_BANK, "tenpay": CHANNEL_BANK,
                          "qdqb": CHANNEL_QB, "qbqd": CHANNEL_QB, "qqacct": CHANNEL_QB, "qqpoint": CHANNEL_QD,
                          "qqcard": CHANNEL_QQCARD, "esales": CHANNEL_ESALES, "phone": CHANNEL_PHONE,
                          "iap": CHANNEL_APPLE, "gwallet": CHANNEL_GOOGLE,
                          "cft_ecny": CHANNEL_ECNY, "wechat_quickpass": CHANNEL_WECHAT}
    CHANNEL_TO_SUB_CHANNEL = {"wechat": "1", "wechatapp": "wechatapp", "wechat_quickpass": "wechat_quickpass"}
    CHANNEL_TO_CURRENCY = {CHANNEL_QB: CurrencyDefine.CURRENCY_QB, CHANNEL_PHONE: CurrencyDefine.CURRENCY_QB,
                           CHANNEL_ESALES: CurrencyDefine.CURRENCY_QB, CHANNEL_QQCARD: CurrencyDefine.CURRENCY_QB,
                           "360": CurrencyDefine.CURRENCY_QB, "373": CurrencyDefine.CURRENCY_QB,
                           CHANNEL_QD: CurrencyDefine.CURRENCY_QD, CHANNEL_BANK: CurrencyDefine.CURRENCY_RMB,
                           CHANNEL_MPAY: CurrencyDefine.CURRENCY_RMB, "917": CurrencyDefine.CURRENCY_RMB,
                           CHANNEL_APPLE: CurrencyDefine.CURRENCY_RMB, CHANNEL_WECHAT: CurrencyDefine.CURRENCY_RMB,
                           CHANNEL_OFFLINE_REFUND: CurrencyDefine.CURRENCY_RMB,
                           "wholesale": CurrencyDefine.CURRENCY_CNY, "redeem": CurrencyDefine.CURRENCY_CNY,
                           "uniacct": CurrencyDefine.CURRENCY_COUPON, CHANNEL_ECNY: CurrencyDefine.CURRENCY_CNY}

    def __init__(self):
        self.channel_id_to_name = {}

    def get_channel_name_conf(self, sett_db, logger):
        sql = "select channel_id,channel_name,channel_desc from db_code.t_channel_name_conf"
        logger.debug(sql)
        result = sett_db.query(sql)
        for item in result:
            self.channel_id_to_name[item["channel_id"]] = item["channel_desc"]
        return self.channel_id_to_name


class SpoaInfo(object):
    """业务代码相关信息
    包括业务代码、结算组、应用组、部门 ID和名称
    """
    FEE_TYPE_MONTH = "3"

    def __init__(self, spoa_id):
        self.spoa_id = spoa_id
        self.spoa_name = ""
        self.sett_group = ""
        self.sett_group_name = ""
        self.busi_group = ""
        self.busi_group_name = ""
        self.dept = ""
        self.dept_name = ""
        self.fee_type = ""
        self.fee_type_name = ""
        self.fee_value = 0


class ChannelInfo(object):
    def __init__(self, channel_id, channel_name):
        self.channel_id = channel_id
        self.channel_name = channel_name
        self.type = ""
        self.type_name = ""
        self.boss_channel_id = ""


class OfferInfo(object):
    def __init__(self, offer_id):
        self.offer_id = offer_id
        self.offer_name = ""
        self.merchant_id = ""
        self.currency_spoa = ""
        self.goods_spoa = ""
        self.subscribe_spoa = ""


class SettGroupOuInfo(object):
    def __init__(self, sett_group):
        self.sett_group = sett_group
        self.sett_group_name = ""
        self.revenue_ou_id = ""
        self.revenue_ou_name = ""
        self.publish_ou_id = ""
        self.publish_ou_name = ""


class PlatformType(enum.Enum):
    TYPE_DEFAULT = "default"
    TYPE_ANDROID = "android"
    TYPE_IOS = "iap"
    TYPE_INTERFLOW = "interflow"


class SelectOption(object):
    def __init__(self):
        self.spoa_id_set = set()  # 按照业务代码或者结算组
        self.sett_group_set = set()


class AccountType(enum.Enum):
    ACCOUNT_TYPE_QB = "1"
    ACCOUNT_TYPE_QD = "3"


class PartnerInfo(object):
    def __init__(self, channel, sub_channel):
        self.channel = channel
        self.channel_name = ""
        self.sub_channel = sub_channel
        self.sub_channel_name = ""
        self.mdm_id = ""
        self.mdm_name = ""
        self.ou_id = ""
        self.ou_name = ""
        self.customer_type = ""
        self.customer_type_name = ""
