#!/usr/bin/env python3
# encoding: utf-8
# @Time    : 2022/1/4 5:29 下午
# @Author  : felixsfan

import asyncio
import json
import sys

import requests

from polaris.api.consumer import ConsumerAPI
from polaris.api.consumer import create_consumer_by_config
from polaris.api.log import LogLevel
from polaris.pkg.config.api import Configuration
from polaris.pkg.config.join_point import JOIN_POINT_MAINLAND
from polaris.pkg.model.error import SDKError
from polaris.pkg.model.service import GetOneInstanceRequest, ServiceCallResult
from polaris.pkg.model.service import RetStatus

from revenue.common import ProcessError

CONSUMER_INSTANCE = None


class PolarisPersist(object):
    def __init__(self, logger):
        self.logger = logger
        self.trpc_service_name = "/trpc/item/manager/service/queryUniAcctRate"
        self.namespace = "Production"  # 北极星命名空间(环境)

    def get_api(self):
        global CONSUMER_INSTANCE
        if not CONSUMER_INSTANCE:
            config = Configuration()
            config.set_default()

            # 修改sdk的设置，一般情况下无需修改
            # 设置接入点, 默认default，支持USA， singapore
            config.global_config.server_connector.set_join_point(JOIN_POINT_MAINLAND)
            # 设置日志的级别, 默认是info
            config.get_global().get_system().log_level = LogLevel.Warn
            # 设置sdk请求后端的超时时间(单位ms), 默认是一秒
            config.get_global().get_server_connector().connect_timeout = 2 * 1000
            config.verify()

            # 无需特别设置，默认为wr算法
            # config.consumer_config.get_load_balancer().type = "wr"
            CONSUMER_INSTANCE = create_consumer_by_config(config)
        return CONSUMER_INSTANCE

    async def get_one_instance(self, consumer_client: ConsumerAPI, namespace: str, server_name: str):
        request = GetOneInstanceRequest(namespace=namespace, service=server_name, use_discover_cache=True)
        # 获取一个实例
        try:
            ret = await consumer_client.async_get_one_instance(request)
        except SDKError as e:
            raise Exception("Polaris SDK error" % repr(e))

        if not ret:
            raise Exception("no available node")

        # 上报熔断数据, 包括调用后端时候成功，这段上报逻辑需要放在实际调用下游之后
        report_req = ServiceCallResult(
            called_instance=ret, ret_status=RetStatus.RetSuccess, ret_code=0, delay=1,
        )
        report_ret = await consumer_client.update_service_call_result(report_req)
        print("update_service_call_result result:", report_ret)

        return ret.get_host(), ret.get_port()

    def get_uniacct_rate(self, service, spoa_id):
        # IMPORTANT: consumer对象维护了数据缓存，需要全局复用
        consumer = self.get_api()
        loop = asyncio.get_event_loop()
        # SDK目前提供了基于asyncio的异步函数（async）,如果需要使用同步调用，可以用run_until_complete来转换为同步
        host, port = loop.run_until_complete(self.get_one_instance(consumer, self.namespace, service))
        self.logger.info("get polaris rpc service host:{} port:{}".format(host, port))

        url = "http://{}:{}{}".format(host, port, self.trpc_service_name)
        headers = {'Content-type': 'application/json'}
        data_json = {'ServiceCode': spoa_id}

        try:
            res = requests.post(url=url, data=json.dumps(data_json), headers=headers, verify=False)
        except requests.RequestException as err:
            self.logger.error(err)
            raise ProcessError("request of get uniacct rate error : {}".format(err))
        else:
            # 反序列化成dict
            res_dict = json.loads(res.text)
            if 0 == res_dict['Code']:
                result = res_dict
            elif 1405 == res_dict['Code']:  # 代币业务代码不存在
                self.logger.error("{} miss rate ".format(spoa_id))
                result = None
            else:
                raise ProcessError("get uniacct rate failed, response: {}".format(res.text))
        return result


if __name__ == '__main__':
    if len(sys.argv) != 4:
        print("python3 main.py servicename spoa_id")
        sys.exit(1)
    service = sys.argv[1]
    spoa_id = sys.argv[2]
    p = PolarisPersist(logger=None)
    p.get_uniacct_rate(service, spoa_id)
    #  python polaris_util.py 192000065:70501 -APP108332
