#!/usr/bin/env python
# -*- coding:utf-8 -*-
import re
import enum
import json
from revenue.common import ResultCode, KEY_SEPARATOR


"""流水相关数据结构定义
water_frame = pandas.read_csv(water_file_name, compression="gzip", sep="|", index_col=False, names=filed_list)
for index, row in water_frame.iterrows():
"""


class WaterDefine(object):
    chan_filed_list = [
        "orderid", "channel", "subchannel", "externalorderid", "appid", "servicecode", "portalserialno", "qquin",
        "payuin", "provideuin", "currencytype", "currencyunit", "orderamt", "originalamt", "payamt", "payitem",
        "servicetype", "userip", "source", "channelid", "payinfo", "payremark", "watertype", "ordertime",
        "providetime", "errorcode", "errorinfo", "extendfield"
    ]
    portal_filed_list = [
        "sequence_no", "tran_time", "tran_type", "pay_type", "pay_chan", "pay_sub_chan", "spoa_id", "spoa_chan",
        "order_no", "status", "result_info", "error_code", "qq_num", "pay_num", "user_num", "tran_amt", "tran_info",
        "tran_detail", "tran_bak", "online_time", "user_ip", "service_ip1", "service_ip2", "service_type", "use_time",
        "ext_str1", "ext_str2", "source", "tran_real_amt", "order_no_uniacct", "tran_uniacct_amt", "order_no_dkq",
        "tran_dkq_amt", "order_no_gold", "order_no_silver", "tran_gold_amt", "tran_silver_amt", "order_no_comm",
        "fservice_type", "cft_id", "ext_str3", "ext_str4", "ext_str5", "ext_str6", "ext_str7"
    ]
    provide_filed_list = [
        "imp_date", "app_id", "provide_type", "scence_id", "service_type", "portal_serial", "cmd_type", "product_type",
        "uin", "paychannel", "sub_channel", "req_service_code", "provide_service_code", "source", "channel_id",
        "orig_payamt", "real_payamt", "product_num", "provide_product_id", "portal_extend", "service_type2",
        "result_code", "result_info", "trans_time", "is_month_package", "month_detail", "amsserial", "pay_remark",
        "pay_item", "pay_msg_return", "pay_item_detail", "provide_order_id", "outer_order"
    ]
    monthly_filed_list = [
        "portal_serial", "user_num", "service_type", "cmd_type", "vendor_type", "fee", "count", "oper_way",
        "create_time", "prepay_begin_time", "prepay_end_time", "trade_extend", "settlement", "pay_items", "remark"
    ]
    monthly_card_filed_list = [
        "statis_date", "rowid", "cmd_type", "userid_type", "userid", "offer_id", "service_type", "productid",
        "inner_productid", "paychannel", "sub_channel", "payid_type", "payid", "payitem", "req_from", "source",
        "channel_id", "currency_amt", "currency_type", "currency_unit", "days", "begin_time", "end_time",
        "portal_serial", "serial_no", "pay_info", "pay_remark", "mp_ruleid", "iap_env", "client_ver",
        "user_last_state", "app_ip", "user_ip", "create_time", "zoneid", "clientver"
    ]
    pay_union_filed_list = [
        "statis_date", "portal_order", "chan_order", "pay_chan", "sub_channel", "tran_type", "pay_spoa", "login_num",
        "pay_num", "user_num", "portal_price", "portal_amt", "currency", "currency_unit", "chan_price", "chan_amt",
        "status", "source", "pf_channel", "merchant_id", "offer_id", "out_order", "order_time", "service_type",
        "provide_type", "chan_remark", "chan_extend", "ext_str1", "ext_str2", "provide_spoa", "provide_price",
        "provide_amt", "is_provide_package", "month_detail", "provide_remark", "provide_extend", "pay_item"
    ]
    member_union_filed_list = [
        "statis_date", "portal_order", "chan_order", "pay_chan", "sub_channel", "tran_type", "pay_spoa", "login_num",
        "pay_num", "user_num", "portal_price", "portal_amt", "currency", "currency_unit", "chan_price", "chan_amt",
        "status", "source", "pf_channel", "merchant_id", "offer_id", "out_order", "order_time", "service_type",
        "provide_type", "chan_remark", "chan_extend", "ext_str1", "ext_str2", "provide_spoa", "cmd_type",
        "provide_amt", "oper_way", "vendor_type", "count", "provide_time", "prepay_begin_time", "prepay_end_time",
        "provide_remark", "provide_extend", "provide_settlement", "pay_item"
    ]
    separator_vertical_line = "|"
    separator_tab_key = "\t"
    portal_refund_tran_type = "refund"
    portal_count_tran_types = {"pay", "payconfirm", "realpay", "autopay", "tuanpay", "ocpay", "provide",
                               "pay_gamecoupon"}
    # tongcai_provide是通彩的数据，只有portal流水没有渠道流水，这里不统计这部分数据
    portal_skip_tran_types = {portal_refund_tran_type, "withdraw", "paycancel", "exchange", "prepay",
                              "tongcai_provide"}
    portal_all_tran_types = portal_count_tran_types.union(portal_skip_tran_types)
    provide_tran_types = {"provide", "ams_reissue", "reissue", "month_reissue"}
    monthly_type_hangup = "1016"
    monthly_type_open = "1002"
    monthly_type_renew = "11002"
    monthly_cancel_hangup = "35"
    portal_offer_pattern = re.compile("uni_appid=([0-9]+)")
    portal_pf_pattern = re.compile("channel_id=([a-zA-Z0-9-_]+)")
    # portal打包业务的拆分
    # "PLIST_SETT=LTMCLUB*1*31*1000*;CJCLUB*1*31*1000*;2000"
    #             spoa * count * date * fee
    portal_packet_detail_pattern = re.compile("(([-A-Za-z0-9]+\\*[0-9]+\\*[0-9]+\\*[0-9.]*\\*?;)+)[0-9.]+")
    portal_packet_sub_info_pattern = re.compile("([-A-Za-z0-9]+)\\*([0-9]+)\\*([0-9]+)\\*([0-9]+)")
    provide_pay_item_pattern = re.compile("pay_item=([^&]+)")
    provide_item_detail_pattern = re.compile("pay_item_detail=([^&]+)")
    provide_promotion_detail_pattern = re.compile("promotion_detail=([a-zA-Z0-9+/=]+)")
    portal_order_date_pattern = re.compile("[-A-Z0-9]+-([0-9]+)-[A-Za-z0-9]+")
    monthly_channel_pattern = re.compile("channel=([A-Za-z0-9_-]+)")
    monthly_sub_channel_pattern = re.compile("subchannel=([A-Za-z0-9_-]+)")
    monthly_packet_spoa_pattern = re.compile("packet=([A-Z0-9-]+)")

    wegame_offer_ids = {"1450022012", "1450022016", "1450022340"}  # 放在这里为了共享, 1450022340是eshop的
    #                   '-APPDJ92942','-APPDJ91754','-APPDJ93321'
    # 1450022344 是eshop td1测试数据，保持不拆分处理
    channel_redeem = "redeem"
    channel_wholesale = "wholesale"
    tob_sale_channel_set = {channel_wholesale, channel_redeem}


class WaterType(enum.Enum):
    TYPE_DEFAULT = "0"
    TYPE_PORTAL = "portal"
    TYPE_CHANNEL = "channel"
    TYPE_PROVIDE = "provide"
    TYPE_MONTHLY = "monthly"
    TYPE_REFUND = "refund"


class JoinFlag(enum.IntEnum):
    FLAG_DEFAULT = 0
    FLAG_PORTAL = 1
    FLAG_CHAN = 2
    FLAG_PROVIDE = 4
    FLAG_MONTHLY = 8
    FLAG_PAY_CONFIRM = 7


class RedisKey(object):
    @staticmethod
    def get_chan_water_key(channel, order_no):
        return "chan_{}::{}".format(channel, order_no)

    @staticmethod
    def get_chan_zero_point_key(channel):
        return "zero_chan::{}".format(channel)

    @staticmethod
    def get_portal_water_key(channel, order_no):
        return "portal_{}::{}".format(channel, order_no)

    @staticmethod
    def get_portal_zero_point_key(channel):
        return "zero_portal::{}".format(channel)

    @staticmethod
    def get_back_portal_zero_point_key(data_date, channel):
        return "{}_zero_portal::{}".format(data_date, channel)

    @staticmethod
    def get_provide_water_key(channel, order_no):    # hash结构，可能存在多条发货流水
        return "provide_{}::{}".format(channel, order_no)

    @staticmethod
    def get_provide_zero_point_key(channel):
        return "zero_provide::{}".format(channel)

    @staticmethod
    def get_monthly_zero_point_key(channel):
        return "zero_monthly::{}".format(channel)

    @staticmethod
    def get_back_monthly_zero_point_key(data_date, channel):
        return "{}_zero_monthly::{}".format(data_date, channel)

    @staticmethod
    def get_monthly_hang_up_key(channel, water_type):
        if water_type == WaterType.TYPE_PORTAL:
            redis_key = "hangup_portal::{}".format(channel)
        elif water_type == WaterType.TYPE_CHANNEL:
            redis_key = "hangup_chan::{}".format(channel)
        else:
            redis_key = ""
        return redis_key


class ProvideType(enum.IntEnum):
    TYPE_DEFAULT = 0
    TYPE_MONTHLY = 1          # 包月
    TYPE_MONTHLY_PACKET = 2   # 打包包月
    TYPE_SHOPPING_CART = 4    # 购物车
    TYPE_REDEEM_COUPON = 8
    TYPE_REDEEM_CDKEY = 16
    TYPE_DIVIDE_FLAG = 1024    # 以下是正常的类型，以上是用于过滤数据目的的， 1024暂时预留
    TYPE_TEST_ACCOUNT = 2048   # 测试账号
    TYPE_MIGRATE_DATA = 4096   # ToB售卖迁移商户的余额订单金额
    TYPE_EXCHANGE_DATA = 8192   # ToB售卖资源互换类的采购
    TYPE_PROVIDE_FAILED = 16384  # 发货失败的流水
    TYPE_FILTER_LOW = 0xFFC00  # 过滤低于1024的数据用


DEFAULT_EXPIRE_TIME = 5400      # 单位秒


class PayWater(object):
    def __init__(self):
        self.data_date = ""
        self.portal_order = ""
        self.chan_order = ""
        self.channel = ""
        self.sub_channel = ""
        self.spoa_id = ""
        self.currency = ""
        self.price_amt = 0
        self.pay_amt = 0
        self.source = ""
        self.pf_channel = ""
        self.offer_id = ""
        self.merchant_id = ""
        self.order_time = ""
        self.pay_remark = ""
        self.provide_type = ProvideType.TYPE_DEFAULT.value
        self.join_flag = 0

    def reset(self):
        self.data_date = ""
        self.portal_order = ""
        self.chan_order = ""
        self.channel = ""
        self.sub_channel = ""
        self.spoa_id = ""
        self.currency = ""
        self.price_amt = 0
        self.pay_amt = 0
        self.source = ""
        self.pf_channel = ""
        self.offer_id = ""
        self.merchant_id = ""
        self.order_time = ""
        self.pay_remark = ""
        self.provide_type = ProvideType.TYPE_DEFAULT.value
        self.join_flag = 0

    @staticmethod
    def json_to_object(object_dict, pay_water=None):
        pay_water.data_date = object_dict["data_date"]
        pay_water.portal_order = object_dict["portal_order"]
        pay_water.chan_order = object_dict["chan_order"]
        pay_water.channel = object_dict["channel"]
        pay_water.sub_channel = object_dict["sub_channel"]
        pay_water.spoa_id = object_dict["spoa_id"]
        pay_water.currency = object_dict["currency"]
        pay_water.price_amt = object_dict["price_amt"]
        pay_water.pay_amt = object_dict["pay_amt"]
        pay_water.source = object_dict["source"]
        pay_water.pf_channel = object_dict["pf_channel"]
        pay_water.offer_id = object_dict["offer_id"]
        pay_water.merchant_id = object_dict["merchant_id"]
        pay_water.order_time = object_dict["order_time"]
        pay_water.pay_remark = object_dict["pay_remark"]
        pay_water.provide_type = object_dict["provide_type"]
        pay_water.join_flag = object_dict["join_flag"]
        return pay_water

    def send_to_redis(self, cluster_redis):
        pass
        return ResultCode.CODE_OK

    def send_zero_point_water_to_redis(self, single_redis):
        pass
        return ResultCode.CODE_OK

    @staticmethod
    def count_joined_info(channel, cluster_redis, join_info):
        pass
        return ResultCode.CODE_OK

    @staticmethod
    def clear_joined_water(channel, cluster_redis):
        pass
        return ResultCode.CODE_OK

    @staticmethod
    def clear_all_water(channel, cluster_redis):
        pass
        return ResultCode.CODE_OK


class ChanWater(PayWater):
    def __init__(self):
        super(ChanWater, self).__init__()
        self.chan_extend = ""

    def reset(self):
        super().reset()
        self.chan_extend = ""

    @staticmethod
    def json_to_object(object_dict, pay_water=None):
        if not pay_water:
            pay_water = ChanWater()
        PayWater.json_to_object(object_dict, pay_water)
        pay_water.chan_extend = object_dict["chan_extend"]
        return pay_water

    def send_to_redis(self, cluster_redis, expire_time=DEFAULT_EXPIRE_TIME):
        data_json = json.dumps(self, default=lambda obj: obj.__dict__)
        data_key = RedisKey.get_chan_water_key(self.channel, self.portal_order)
        cluster_redis.set(data_key, data_json, ex=expire_time)
        return ResultCode.CODE_OK

    def send_zero_point_water_to_redis(self, single_redis):
        data_json = json.dumps(self, default=lambda obj: obj.__dict__)
        hash_key = RedisKey.get_chan_zero_point_key(self.channel)
        single_redis.hset(hash_key, self.portal_order, data_json)
        return ResultCode.CODE_OK

    @staticmethod
    def count_joined_info(channel, cluster_redis, join_info):
        key_pattern = RedisKey.get_chan_water_key(channel, "")
        for data_key in cluster_redis.scan_iter(match=key_pattern):
            redis_data = cluster_redis.get(data_key)
            if not redis_data:
                continue
            join_info.chan_water_num += 1
            chan_water = json.loads(redis_data, object_hook=ChanWater.json_to_object)
            if chan_water.join_flag != JoinFlag.FLAG_PAY_CONFIRM.value:
                join_info.chan_vs_portal_failed += 1
        return ResultCode.CODE_OK

    def send_monthly_hangup_water_to_redis(self, single_redis):
        data_json = json.dumps(self, default=lambda obj: obj.__dict__)
        hash_key = RedisKey.get_monthly_hang_up_key(self.channel, WaterType.TYPE_CHANNEL)
        single_redis.hset(hash_key, self.portal_order, data_json)
        return ResultCode.CODE_OK

    @staticmethod
    def clear_history_hangup_water(channel, single_redis, history_date):
        hash_key = RedisKey.get_monthly_hang_up_key(channel, WaterType.TYPE_CHANNEL)
        history_date_num = int(history_date.replace("-", ""))
        for data_key, redis_data in single_redis.hscan_iter(hash_key):
            search_result = re.search(WaterDefine.portal_order_date_pattern, data_key)
            if not search_result:
                continue
            data_date_num = int(search_result.group(1))
            chan_water = json.loads(redis_data, object_hook=ChanWater.json_to_object)
            if data_date_num <= history_date_num and \
                    chan_water.join_flag & JoinFlag.FLAG_MONTHLY.value == JoinFlag.FLAG_MONTHLY.value:
                single_redis.hdel(hash_key, data_key)
        return ResultCode.CODE_OK

    @staticmethod
    def clear_history_water(channel, cluster_redis, history_date):
        history_date_num = int(history_date.replace("-", ""))
        key_pattern = RedisKey.get_chan_water_key(channel, "*")
        for data_key in cluster_redis.scan_iter(match=key_pattern):
            search_result = re.search(WaterDefine.portal_order_date_pattern, data_key)
            if not search_result:
                continue
            data_date_num = int(search_result.group(1))
            if data_date_num <= history_date_num:
                cluster_redis.delete(data_key)
        return ResultCode.CODE_OK

    @staticmethod
    def clear_all_water(channel, cluster_redis):
        key_pattern = RedisKey.get_chan_water_key(channel, "*")
        for data_key in cluster_redis.scan_iter(match=key_pattern):
            cluster_redis.delete(data_key)
        return ResultCode.CODE_OK


class PortalWater(PayWater):
    def __init__(self):
        super(PortalWater, self).__init__()
        self.portal_extend = ""
        self.month_detail = ""
        self.redeem_acct = ""    # 用户redeem兑换时记录兑换券/cdkey的账户ID

    def reset(self):
        super().reset()
        self.portal_extend = ""
        self.month_detail = ""
        self.redeem_acct = ""

    @staticmethod
    def json_to_object(object_dict, pay_water=None):
        if not pay_water:
            pay_water = PortalWater()
        PayWater.json_to_object(object_dict, pay_water)
        pay_water.portal_extend = object_dict["portal_extend"]
        pay_water.month_detail = object_dict["month_detail"]
        if "redeem_acct" in object_dict:
            pay_water.redeem_acct = object_dict["redeem_acct"]
        return pay_water

    def send_to_redis(self, cluster_redis, expire_time=DEFAULT_EXPIRE_TIME):
        data_json = json.dumps(self, default=lambda obj: obj.__dict__)
        data_key = RedisKey.get_portal_water_key(self.channel, self.portal_order)
        cluster_redis.set(data_key, data_json, ex=expire_time)
        return ResultCode.CODE_OK

    def delete_from_zero_point_redis(self, single_cluster):
        hash_key = RedisKey.get_portal_zero_point_key(self.channel)
        single_cluster.hdel(hash_key, self.portal_order)
        return ResultCode.CODE_OK

    def send_zero_point_water_to_redis(self, single_redis):
        data_json = json.dumps(self, default=lambda obj: obj.__dict__)
        hash_key = RedisKey.get_portal_zero_point_key(self.channel)
        single_redis.hset(hash_key, self.portal_order, data_json)
        return ResultCode.CODE_OK

    def send_monthly_hangup_water_to_redis(self, single_redis):
        data_json = json.dumps(self, default=lambda obj: obj.__dict__)
        hash_key = RedisKey.get_monthly_hang_up_key(self.channel, WaterType.TYPE_PORTAL)
        single_redis.hset(hash_key, self.portal_order, data_json)
        return ResultCode.CODE_OK

    @staticmethod
    def clear_history_hangup_water(channel, single_redis, history_date):
        hash_key = RedisKey.get_monthly_hang_up_key(channel, WaterType.TYPE_PORTAL)
        history_date_num = int(history_date.replace("-", ""))
        for data_key, redis_data in single_redis.hscan_iter(hash_key):
            search_result = re.search(WaterDefine.portal_order_date_pattern, data_key)
            if not search_result:
                continue
            data_date_num = int(search_result.group(1))
            portal_water = json.loads(redis_data, object_hook=PortalWater.json_to_object)
            if data_date_num <= history_date_num \
                    and portal_water.join_flag & JoinFlag.FLAG_MONTHLY.value == JoinFlag.FLAG_MONTHLY.value:
                single_redis.hdel(hash_key, data_key)
        return ResultCode.CODE_OK

    @staticmethod
    def count_zero_point_info(channel, single_redis, join_info, logger, save_call_back):
        hash_key = RedisKey.get_portal_zero_point_key(channel)
        miss_chan_flag = JoinFlag.FLAG_PORTAL.value
        miss_provide_flag = JoinFlag.FLAG_PORTAL.value + JoinFlag.FLAG_CHAN.value
        miss_chan_dict, miss_provide_dict = {}, {}
        for _, redis_data in single_redis.hscan_iter(hash_key):
            portal_water = json.loads(redis_data, object_hook=PortalWater.json_to_object)
            if portal_water.join_flag == miss_chan_flag:
                join_info.portal_vs_chan_failed_count += 1
                join_info.portal_vs_chan_failed_amt += portal_water.pay_amt
                miss_chan_dict[portal_water.portal_order] = portal_water
            elif portal_water.join_flag == miss_provide_flag:
                join_info.portal_vs_provide_failed_count += 1
                join_info.portal_vs_provide_failed_amt += portal_water.pay_amt
                miss_provide_dict[portal_water.portal_order] = portal_water
            if save_call_back:
                save_call_back(portal_water.portal_order, portal_water.join_flag)
        if logger:
            PortalWater.logger_miss_water(logger, miss_chan_dict, "chan")
            PortalWater.logger_miss_water(logger, miss_provide_dict, "provide")
        return ResultCode.CODE_OK

    @staticmethod
    def logger_miss_water(logger, miss_chan_dict, miss_type):
        if not miss_chan_dict:
            return ResultCode.CODE_OK
        channel, total_miss_amt = "", 0
        for portal_order in miss_chan_dict:
            portal_water = miss_chan_dict[portal_order]
            logger.debug("{} <===> {}, {}".format(portal_water.portal_order,
                                                  portal_water.order_time, portal_water.pay_amt))
            total_miss_amt += portal_water.pay_amt
            channel = portal_water.channel
        logger.debug("{} miss {} {} water,total amt {}".
                     format(channel, len(miss_chan_dict), miss_type, total_miss_amt))
        return ResultCode.CODE_OK

    def join_chan_water(self, cluster_redis, single_redis, cache_miss=True):
        # portal关联渠道流水
        data_key = RedisKey.get_chan_water_key(self.channel, self.portal_order)
        json_str = cluster_redis.get(data_key)
        if not json_str:
            if cache_miss:
                self.send_zero_point_water_to_redis(single_redis)
            return None
        chan_water = json.loads(json_str, object_hook=ChanWater.json_to_object)
        # 更新渠道流水的关联标识，关联发货后再统一更新
        # chan_water.join_flag |= JoinFlag.FLAG_PORTAL.value
        # chan_water.send_to_redis(cluster_redis)
        return chan_water

    def join_provide_water(self, cluster_redis, single_redis, cache_miss=True):
        # portal关联渠道流水
        hash_key = RedisKey.get_provide_water_key(self.channel, self.portal_order)
        data_dict = cluster_redis.hgetall(hash_key)
        if not data_dict:
            if cache_miss:
                self.send_zero_point_water_to_redis(single_redis)
            return None
        provide_water_dict = {}
        for provide_spoa in data_dict:
            json_str = data_dict[provide_spoa]
            provide_water = json.loads(json_str, object_hook=ProvideWater.json_to_object)
            provide_water_dict[provide_spoa] = provide_water
            # 更新渠道流水的关联标识
            # provide_water.join_flag = JoinFlag.FLAG_PAY_CONFIRM
            # provide_water.send_to_redis(cluster_redis)
        return provide_water_dict

    @staticmethod
    def clear_history_water(channel, cluster_redis, history_date):
        history_date_num = int(history_date.replace("-", ""))
        key_pattern = RedisKey.get_portal_water_key(channel, "*")
        for data_key in cluster_redis.scan_iter(match=key_pattern):
            search_result = re.search(WaterDefine.portal_order_date_pattern, data_key)
            if not search_result:
                continue
            data_date_num = int(search_result.group(1))
            if data_date_num <= history_date_num:
                cluster_redis.delete(data_key)
        return ResultCode.CODE_OK


class ProvideWater(PayWater):
    def __init__(self):
        super(ProvideWater, self).__init__()
        self.provide_spoa = ""
        self.provide_extend = ""
        self.month_detail = ""
        self.provide_order = ""   # 同一个物品发货多次使用发货ID区分
        self.platform_type = ""
        self.acct_spoa = ""

    def reset(self):
        super().reset()
        self.provide_spoa = ""
        self.provide_extend = ""
        self.month_detail = ""
        self.provide_order = ""
        self.platform_type = ""
        self.acct_spoa = ""

    @staticmethod
    def json_to_object(object_dict, pay_water=None):
        if not pay_water:
            pay_water = ProvideWater()
        PayWater.json_to_object(object_dict, pay_water)
        pay_water.provide_spoa = object_dict["provide_spoa"]
        pay_water.provide_extend = object_dict["provide_extend"]
        pay_water.month_detail = object_dict["month_detail"]
        return pay_water

    def send_to_redis(self, cluster_redis, expire_time=DEFAULT_EXPIRE_TIME):
        data_json = json.dumps(self, default=lambda obj: obj.__dict__)
        hash_key = RedisKey.get_provide_water_key(self.channel, self.portal_order)
        cluster_redis.hset(hash_key, KEY_SEPARATOR.join([self.provide_spoa, self.provide_order]), data_json)
        cluster_redis.expire(hash_key, expire_time)
        return ResultCode.CODE_OK

    @staticmethod
    def count_joined_info(channel, cluster_redis, join_info):
        key_pattern = RedisKey.get_provide_water_key(channel, "")
        for hash_key in cluster_redis.scan_iter(match=key_pattern):
            data_dict = cluster_redis.hgetall(hash_key)
            for provide_spoa in data_dict:
                join_info.provide_water_num += 1
                json_str = data_dict[provide_spoa]
                provide_water = json.loads(json_str, object_hook=ProvideWater.json_to_object)
                if provide_water.join_flag != JoinFlag.FLAG_PAY_CONFIRM.value:
                    join_info.provide_vs_portal_failed += 1
            # end for
        # end for
        return ResultCode.CODE_OK

    @staticmethod
    def clear_history_water(channel, cluster_redis, history_date):
        history_date_num = int(history_date.replace("-", ""))
        key_pattern = RedisKey.get_provide_water_key(channel, "*")
        for hash_key in cluster_redis.scan_iter(match=key_pattern):
            search_result = re.search(WaterDefine.portal_order_date_pattern, hash_key)
            if not search_result:
                continue
            data_date_num = int(search_result.group(1))
            if data_date_num <= history_date_num:
                cluster_redis.delete(hash_key)
            # end for
        # end for
        return ResultCode.CODE_OK

    @staticmethod
    def clear_all_water(channel, cluster_redis):
        key_pattern = RedisKey.get_provide_water_key(channel, "")
        for data_key in cluster_redis.scan_iter(match=key_pattern):
            cluster_redis.delete(data_key)
        return ResultCode.CODE_OK


class MonthlyWater(object):
    def __init__(self):
        self.data_date = ""
        self.portal_order = ""
        self.channel = ""
        self.sub_channel = ""
        self.spoa_id = ""
        self.currency = ""
        self.pay_amt = 0
        self.day_num = 0
        self.begin_time = ""
        self.end_time = ""
        self.cmd_type = ""
        self.oper_way = ""
        self.packet_spoa = ""  # 打包业务代码，默认空
        self.merchant_id = ""
        self.offer_id = ""    # 需要关联
        self.pay_remark = ""
        self.order_time = ""
        self.provide_type = ProvideType.TYPE_DEFAULT.value
        self.join_flag = JoinFlag.FLAG_DEFAULT.value

    def reset(self):
        self.data_date = ""
        self.portal_order = ""
        self.channel = ""
        self.sub_channel = ""
        self.spoa_id = ""
        self.currency = ""
        self.pay_amt = 0
        self.day_num = 0
        self.begin_time = ""
        self.end_time = ""
        self.cmd_type = ""
        self.oper_way = ""
        self.packet_spoa = ""  # 打包业务代码，默认空
        self.merchant_id = ""
        self.offer_id = ""  # 需要关联
        self.pay_remark = ""
        self.order_time = ""
        self.provide_type = ProvideType.TYPE_DEFAULT.value
        self.join_flag = JoinFlag.FLAG_DEFAULT.value

    @staticmethod
    def json_to_object(object_dict, monthly_water=None):
        if not monthly_water:
            monthly_water = MonthlyWater()
        monthly_water.data_date = object_dict["data_date"]
        monthly_water.portal_order = object_dict["portal_order"]
        monthly_water.channel = object_dict["channel"]
        monthly_water.sub_channel = object_dict["sub_channel"]
        monthly_water.spoa_id = object_dict["spoa_id"]
        monthly_water.currency = object_dict["currency"]
        monthly_water.pay_amt = object_dict["pay_amt"]
        monthly_water.day_num = object_dict["day_num"]
        monthly_water.begin_time = object_dict["begin_time"]
        monthly_water.end_time = object_dict["end_time"]
        monthly_water.cmd_type = object_dict["cmd_type"]
        monthly_water.oper_way = object_dict["oper_way"]
        monthly_water.packet_spoa = object_dict["packet_spoa"]
        monthly_water.merchant_id = object_dict["merchant_id"]
        monthly_water.offer_id = object_dict["offer_id"]
        monthly_water.pay_remark = object_dict["pay_remark"]
        monthly_water.order_time = object_dict["order_time"]
        monthly_water.provide_type = object_dict["provide_type"]
        monthly_water.join_flag = object_dict["join_flag"]
        return monthly_water

    def send_zero_point_water_to_redis(self, single_redis):
        data_json = json.dumps(self, default=lambda obj: obj.__dict__)
        hash_key = RedisKey.get_monthly_zero_point_key(self.channel)
        single_redis.hset(hash_key, self.portal_order, data_json)
        return ResultCode.CODE_OK

    def delete_from_zero_point_redis(self, single_cluster):
        hash_key = RedisKey.get_monthly_zero_point_key(self.channel)
        single_cluster.hdel(hash_key, self.portal_order)
        return ResultCode.CODE_OK

    def join_portal_water(self, cluster_redis, single_redis, cache_miss=True):
        # 解挂关联挂起流水
        if self.cmd_type in [WaterDefine.monthly_type_open, WaterDefine.monthly_type_renew] \
                and self.oper_way == WaterDefine.monthly_cancel_hangup:
            hash_key = RedisKey.get_monthly_hang_up_key(self.channel, WaterType.TYPE_PORTAL)
            json_str = single_redis.hget(hash_key, self.portal_order)
        else:
            data_key = RedisKey.get_portal_water_key(self.channel, self.portal_order)
            json_str = cluster_redis.get(data_key)
        if not json_str:
            if cache_miss:
                self.send_zero_point_water_to_redis(single_redis)
            return None
        portal_water = json.loads(json_str, object_hook=PortalWater.json_to_object)
        if self.oper_way == WaterDefine.monthly_cancel_hangup:
            portal_water.data_date = self.data_date        # 改为关联日期，添加关联标识，用于清理历史数据
            portal_water.join_flag |= JoinFlag.FLAG_MONTHLY
            portal_water.send_monthly_hangup_water_to_redis(single_redis)
        return portal_water

    def join_chan_water(self, cluster_redis, single_redis, cache_miss=True):
        # 解卦关联挂起流水
        if self.cmd_type in [WaterDefine.monthly_type_open, WaterDefine.monthly_type_renew] \
                and self.oper_way == WaterDefine.monthly_cancel_hangup:
            hash_key = RedisKey.get_monthly_hang_up_key(self.channel, WaterType.TYPE_CHANNEL)
            json_str = single_redis.hget(hash_key, self.portal_order)
        else:
            data_key = RedisKey.get_chan_water_key(self.channel, self.portal_order)
            json_str = cluster_redis.get(data_key)
        if not json_str:
            if cache_miss:
                self.send_zero_point_water_to_redis(single_redis)
            return None
        chan_water = json.loads(json_str, object_hook=ChanWater.json_to_object)
        if self.oper_way == WaterDefine.monthly_cancel_hangup:
            chan_water.data_date = self.data_date      # 改为关联日期，添加关联标识，用于清理历史数据
            chan_water.join_flag |= JoinFlag.FLAG_MONTHLY
            chan_water.send_monthly_hangup_water_to_redis(single_redis)
        return chan_water

    def join_redis_hangup_portal_water(self, cluster_redis, single_redis, cache_miss=True):
        # 获取portal流水
        data_key = RedisKey.get_portal_water_key(self.channel, self.portal_order)
        json_str = cluster_redis.get(data_key)
        if not json_str:
            if cache_miss:
                self.send_zero_point_water_to_redis(single_redis)
            return ResultCode.CODE_SKIP
        portal_water = json.loads(json_str, object_hook=PortalWater.json_to_object)
        # 挂起渠道流水到redis
        portal_water.send_monthly_hangup_water_to_redis(single_redis)

        return ResultCode.CODE_OK

    def join_redis_hangup_chan_water(self, cluster_redis, single_redis, cache_miss=True):
        # 获取portal流水
        data_key = RedisKey.get_chan_water_key(self.channel, self.portal_order)
        json_str = cluster_redis.get(data_key)
        if not json_str:
            if cache_miss:
                self.send_zero_point_water_to_redis(single_redis)
            return ResultCode.CODE_SKIP
        chan_water = json.loads(json_str, object_hook=ChanWater.json_to_object)
        # 挂起渠道流水到redis
        chan_water.send_monthly_hangup_water_to_redis(single_redis)

        return ResultCode.CODE_OK

    @staticmethod
    def count_zero_point_info(channel, single_redis, join_info, logger, save_call_back):
        hash_key = RedisKey.get_monthly_zero_point_key(channel)
        miss_portal_flag = JoinFlag.FLAG_MONTHLY.value
        # miss_chan_flag = JoinFlag.FLAG_PORTAL.value + JoinFlag.FLAG_MONTHLY.value
        miss_portal_dict, miss_chan_dict = {}, {}
        for _, redis_data in single_redis.hscan_iter(hash_key):
            monthly_water = json.loads(redis_data, object_hook=MonthlyWater.json_to_object)
            if monthly_water.join_flag == miss_portal_flag:
                join_info.provide_vs_portal_failed_count += 1
                join_info.provide_vs_portal_failed_amt += monthly_water.pay_amt
                miss_portal_dict[monthly_water.portal_order] = monthly_water
            else:   # portal_water.join_flag == miss_provide_flag:
                join_info.provide_vs_chan_failed_count += 1
                join_info.provide_vs_chan_failed_amt += monthly_water.pay_amt
                miss_chan_dict[monthly_water.portal_order] = monthly_water
            if save_call_back:
                save_call_back(monthly_water.portal_order, monthly_water.join_flag)
        if logger:
            MonthlyWater.logger_miss_water(logger, miss_portal_dict, "portal")
            MonthlyWater.logger_miss_water(logger, miss_chan_dict, "chan")
        return ResultCode.CODE_OK

    @staticmethod
    def logger_miss_water(logger, miss_chan_dict, miss_type):
        if not miss_chan_dict:
            return ResultCode.CODE_OK
        channel, total_miss_amt = "", 0
        for portal_order in miss_chan_dict:
            portal_water = miss_chan_dict[portal_order]
            logger.debug("{} <===> {}, {}".format(portal_water.portal_order,
                                                  portal_water.order_time, portal_water.pay_amt))
            total_miss_amt += portal_water.pay_amt
            channel = portal_water.channel
        logger.debug("{} miss {} {} water,total amt {}".
                     format(channel, len(miss_chan_dict), miss_type, total_miss_amt))
        return ResultCode.CODE_OK


class WaterJoinInfo(object):
    def __init__(self, channel):
        self.channel = channel
        self.portal_water_num = 0
        self.chan_water_num = 0
        self.provide_water_num = 0
        self.portal_vs_chan_failed_count = 0
        self.portal_vs_provide_failed_count = 0
        self.chan_vs_portal_failed_count = 0
        self.provide_vs_portal_failed_count = 0
        self.provide_vs_chan_failed_count = 0
        self.portal_vs_chan_failed_amt = 0
        self.portal_vs_provide_failed_amt = 0
        self.chan_vs_portal_failed_amt = 0
        self.provide_vs_portal_failed_amt = 0
        self.provide_vs_chan_failed_amt = 0


class MonthlyCardWater(object):
    def __init__(self):
        self.data_date = ""
        self.portal_order = ""
        self.channel = ""
        self.sub_channel = ""
        self.spoa_id = ""
        self.currency = ""
        self.price_amt = 0
        self.pay_amt = 0
        self.rmb_price_amt = 0
        self.rmb_pay_amt = 0
        self.service_days = 0
        self.begin_time = ""
        self.end_time = ""
        self.cmd_type = ""
        self.merchant_id = ""
        self.offer_id = ""
        self.order_time = ""
        self.provide_type = ProvideType.TYPE_DEFAULT.value

    def reset(self):
        self.data_date = ""
        self.portal_order = ""
        self.channel = ""
        self.sub_channel = ""
        self.spoa_id = ""
        self.currency = ""
        self.price_amt = 0
        self.pay_amt = 0
        self.service_days = 0
        self.begin_time = ""
        self.end_time = ""
        self.cmd_type = ""
        self.merchant_id = ""
        self.offer_id = ""
        self.order_time = ""
        self.provide_type = ProvideType.TYPE_DEFAULT.value
