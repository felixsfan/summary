#!/usr/bin/env python3
# coding=utf-8
from .water_define import ProvideType, WaterDefine


class ChanPayData(object):
    def __init__(self, channel="", sub_channel="", currency="", pay_spoa="", provide_spoa="", merchant_id="",
                 source="0", offer_id=""):
        self.data_date = ""
        self.channel = channel          # 结算归属渠道
        self.pay_channel = channel      # 实际支付渠道
        self.sub_channel = sub_channel
        self.currency = currency
        self.merchant_id = merchant_id
        self.source = source
        self.pay_spoa = pay_spoa
        self.provide_spoa = provide_spoa
        self.packet_spoa = ""
        self.price_amt = 0       # 定价
        self.order_amt = 0       # 订单金额，只有微信免充值券的时候和pay_amt不相等
        self.pay_amt = 0         # 用户支付金额
        self.coupon_amt = 0      # 用券的金额
        self.pay_count = 0
        self.offer_id = offer_id
        self.acct_app_id = "0"
        self.acct_key = ""       # tob售卖专用
        self.sub_acct = ""       # tob售卖专用
        self.data_type = ProvideType.TYPE_DEFAULT.value  # 个账渠道目前只有6和0，用于区分是否赠送，很久都没看到6的数据了
        self.spoa_name = ""         # 发货业务代码
        self.sett_group = ""        # 发货业务结算组
        self.sett_group_name = ""
        self.redeem_acct = ""       # redeem兑换用于记录兑换券/cdkey账户ID
        self.sett_amt = 0  # 记录ios互通的apple的结算金额

    def set_data(self, pay_water):
        self.data_date = pay_water.data_date
        self.channel = pay_water.channel
        self.pay_channel = ""
        self.sub_channel = pay_water.sub_channel
        self.currency = pay_water.currency
        self.pay_spoa = pay_water.spoa_id
        self.provide_spoa = pay_water.spoa_id
        self.packet_spoa = ""
        self.merchant_id = pay_water.merchant_id
        self.source = pay_water.source
        self.price_amt = pay_water.price_amt
        self.pay_amt = pay_water.pay_amt
        self.pay_count = 0
        self.offer_id = pay_water.offer_id
        self.acct_app_id = ""
        self.acct_key = self.sub_acct = ""
        # 默认最终结果里只保留是否测试标识
        self.data_type = pay_water.provide_type & ProvideType.TYPE_FILTER_LOW.value
        # self.data_type = ProvideType.TYPE_DEFAULT.value  # 个账渠道目前只有6和0，用于区分是否赠送，很久都没看到6的数据了
        self.spoa_name = self.sett_group = self.sett_group_name = ""
        self.redeem_acct = ""


class RevenueDoDDate(object):
    def __init__(self, channel="", sub_channel="", pay_spoa="", provide_spoa=""):
        self.channel = channel
        self.sub_channel = sub_channel
        self.pay_spoa = pay_spoa
        self.provide_spoa = provide_spoa
        self.this_price_amt = 0
        self.this_pay_amt = 0
        self.last_price_amt = 0
        self.last_pay_amt = 0
        self.amt_dod_rate = 0


class MonthlyDeferData(object):
    def __init__(self, defer_month="", channel="", sub_channel="", pay_spoa="", provide_spoa=""):
        self.data_date = ""
        self.data_month = ""
        self.defer_month = defer_month
        self.channel = channel
        self.sub_channel = sub_channel
        self.pay_spoa = pay_spoa             # 支付业务代码
        self.packet_spoa = ""
        self.provide_spoa = provide_spoa     # 发货业务代码
        self.currency = ""
        self.merchant_id = ""      # 微信支付/网银渠道是商户号
        self.begin_time = ""
        self.end_time = ""
        self.defer_price = 0
        self.defer_amt = 0
        self.server_days = 0
        self.source = ""
        self.offer_id = ""
        self.acct_key = ""  # tob售卖专用
        self.sub_acct = ""  # tob售卖专用
        self.data_type = ProvideType.TYPE_DEFAULT.value
        self.mdm_id = ""
        self.spoa_name = ""
        self.sett_group = ""
        self.sett_group_name = ""
        self.redeem_acct = ""       # redeem兑换用于记录兑换券/cdkey账户ID

    def set_data(self, monthly_water):
        self.data_date = monthly_water.data_date
        self.data_month = ""
        self.defer_month = ""
        self.channel = monthly_water.channel
        self.sub_channel = monthly_water.sub_channel
        self.pay_spoa = ""
        self.provide_spoa = monthly_water.spoa_id
        self.packet_spoa = monthly_water.packet_spoa
        self.currency = monthly_water.currency
        self.merchant_id = monthly_water.merchant_id
        self.begin_time = monthly_water.begin_time
        self.end_time = monthly_water.end_time
        self.defer_price = 0
        self.defer_amt = monthly_water.pay_amt
        self.server_days = monthly_water.day_num
        self.source = ""
        self.offer_id = monthly_water.offer_id
        self.acct_key = self.sub_acct = ""
        # 默认最终结果里只保留是否测试标识
        self.data_type = monthly_water.provide_type & ProvideType.TYPE_FILTER_LOW.value
        self.mdm_id = monthly_water.merchant_id \
            if monthly_water.channel in (WaterDefine.channel_wholesale, WaterDefine.channel_redeem) else ""
        self.spoa_name = self.sett_group = self.sett_group_name = ""
        self.redeem_acct = ""


class DeferSplitRate(object):
    def __init__(self, spoa_id, spoa_name=""):
        self.spoa_id = spoa_id
        self.spoa_name = spoa_name
        self.all_amt = 0
        self.this_month_amt = 0
        self.split_rate = 0
