#!/bin/sh

# 结算任务部署的目录，包括python、redis、hadoop_client等的
USER_HOME_PATH=${HOME}
# 结算任务代码的目录
# CODE_HOME_PATH="${USER_HOME_PATH}/workspace/settlement"
CODE_HOME_PATH="${USER_HOME_PATH}/admin_better"
# python配置信息
init_python() {
    export PATH="${USER_HOME_PATH}/local/anaconda3/bin:${PATH}"
    # 配置环境的选择：生产、开发、现网测试等
    export DYNACONF_NAMESPACE=PRODUCTION
    # export DYNACONF_NAMESPACE="DEVELOPMENT"
    # export ENV_FOR_DYNACONF="DEVELOPMENT"
    # python代码的搜索目录
    export PYTHONPATH="${CODE_HOME_PATH}"
    # 结算任务的初始工作目录
    export DYNACONF_WORK_PATH="${CODE_HOME_PATH}/admin_better"

    echo "initialize python env done"
}

init_hadoop() {
    # 用于shell
    export hadoop="${USER_HOME_PATH}/local/tdwdfsclient/bin/hadoop fs -Dfs.defaultFS=hdfs://ss-teg-3-v2 -Dhadoop.job.ugi=tdw_xiangtaoli:sett_1024,g_teg_bmc_bmc "
    # 用于python
    export DYNACONF_HADOOP_CLIENT="${hadoop}"
    echo "initialize hadoop env done"
}

# 同步erp信息
init_oracle() {
    #export ORACLE_BASE=/usr/lib/oracle/11.1.0.1/client64
    #export ORACLE_HOME=/usr/lib/oracle/11.1.0.1/client64
    #export NLS_LANG="SIMPLIFIED CHINESE_CHINA.ZHS16GBK"
    export NLS_LANG="SIMPLIFIED CHINESE_CHINA.AL32UTF8"
    export LD_LIBRARY_PATH="${LD_LIBRARY_PATH}:${USER_HOME_PATH}/local/instantclient"
    export PATH="$PATH:${USER_HOME_PATH}/local/instantclient"
    echo "initialize oracle env done"
}

init_type=$1
if [ "${init_type}" = "python" ]
then
    init_python
elif [ "${init_type}" = "oracle" ]
then
    init_oracle
elif [ "${init_type}" = "hadoop" ]
then
    init_hadoop
else
    init_python
    init_hadoop
    echo "no input type, init python & hadoop"
fi
