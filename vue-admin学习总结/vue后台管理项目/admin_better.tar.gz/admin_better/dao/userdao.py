#!/usr/bin/env python3
# encoding: utf-8
# @Time    : 2022/1/24 4:06 下午
from sqlalchemy.orm import sessionmaker

from app import db
from common.common_define import ResultCode
from config import settings
from entity.user import User


class UserDao(object):
    def __init__(self):
        # 在方法里建立数据库连接是不对的，这样每来一个请求，就新增一个数据库连接。
        # 请求结束后由于数据库连接的存在，flask请求实例并不会销毁。
        # 要在flask全局里建立数据库连接，这样多少请求也只初始化一次
        # self.tj = MysqlClient()
        # self.tj.init_connect(settings.day_db_config)
        self.db = db
        self.tj_engine = self.db.get_engine(app=self.db.get_app(), bind="day_db_admin_better")

        self.session_factory = sessionmaker(bind=self.tj_engine)
        self.tj_session = self.session_factory()

        self.user_table = "{}.{}".format(settings.databases.user_db, settings.tables.user_table)

    def get_user_info(self, username):
        print(settings.day_db_config)
        user = self.tj_session.query(User).filter_by(username=username).one()
        return user

    def update_user_token(self, username, token):
        # sql = "update {} set token='{}' where username='{}'".format(self.user_table, token, username)
        # cursor = self.tj_session.execute(sql)
        user = self.get_user_info(username)
        user.set_token(token)
        self.tj_session.commit()
        return ResultCode.CODE_OK
