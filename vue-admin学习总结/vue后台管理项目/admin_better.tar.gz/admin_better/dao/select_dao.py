#!/usr/bin/env python3
# encoding: utf-8
# @Time    : 2022/3/21 3:58 下午
from app import flask_app
from common.mysql_client import MysqlClient
from config import settings


class SelectDao(object):
    def __init__(self):
        self.logger = flask_app.logger
        self.day_db = None
        self.day_db_latin1 = None
        self.month_db = None
        self.month_db_latin1 = None
        self.connect_dict = {}

    def db_init(self):
        self.day_db = MysqlClient()
        self.day_db.init_connect(settings.day_db_config, logger=self.logger)

        self.day_db_latin1 = MysqlClient()
        self.day_db_latin1.init_connect(settings.day_db_config, charset="latin1", is_unicode=False, logger=self.logger)

        self.month_db = MysqlClient()
        self.month_db.init_connect(settings.month_db_config, logger=self.logger)

        self.month_db_latin1 = MysqlClient()
        # buffered=True 不然报错mysql.connector.errors.InternalError: Unread result found,还不知道原因
        self.month_db_latin1.init_connect(settings.month_db_config, charset="latin1", is_unicode=False, logger=self.logger)

        self.connect_dict = {'sett_db': self.month_db, 'tj_db': self.day_db,
                             'sett_db_latin1': self.month_db_latin1,
                             'tj_db_latin1': self.day_db_latin1}

    def get_select_data(self, connection, sql):
        try:
            self.db_init()
            db_connect = self.connect_dict[connection]
            data = []
            fields = []
            result = db_connect.query(sql)
            tag = 0
            for dict_item in result:
                if tag == 0:
                    if "latin1" not in connection:
                        # 添加字段名
                        fields = list(dict_item.keys())
                    else:
                        field_temp = list(dict_item.keys())
                        for i in range(len(field_temp)):
                            fields.append(field_temp[i].decode("gbk", "ignore"))
                    tag += 1
                # 添加数据
                if "latin1" in connection:
                    temp_list = list(dict_item.values())
                    # print(dict_item.values())
                    # dict_values([b'202110', 3, b'\xb8\xf6\xc8\xcb\xd5\xca\xbb\xa7'])
                    temp_dict = {}
                    for it in range(0, len(temp_list)):
                        if isinstance(temp_list[it], bytes):  # 字符串才存在编码转换
                            temp_dict[fields[it]] = temp_list[it].decode("gbk", "ignore")
                        else:
                            temp_dict[fields[it]] = temp_list[it]
                    data.append(temp_dict)
                else:
                    data.append(dict_item)
            return {'fieldslist': fields, 'select_result': data}
        except Exception as error:
            self.logger.error(error)
            raise Exception(error)
        finally:
            # 原生的mysql连接，用完需要关闭连接
            self.finish()

    def finish(self):
        if self.day_db:
            self.day_db.close()
            self.day_db = None
        if self.day_db_latin1:
            self.day_db_latin1.close()
            self.day_db_latin1 = None
        if self.month_db:
            self.month_db.close()
            self.month_db = None
        if self.month_db_latin1:
            self.month_db_latin1.close()
            self.month_db_latin1 = None
