#!/usr/bin/env python3
# encoding: utf-8
# @Time    : 2022/2/17 2:19 下午
from sqlalchemy.orm import sessionmaker

from app import db
from util.table_db_map import TABLE_DB_MAP


class TableDao(object):
    def __init__(self):
        self.db = db
        self.sett_engine = self.db.get_engine(app=self.db.get_app(), bind="month_db")

        self.sett_session_factory = sessionmaker(bind=self.sett_engine)
        self.sett_session = self.sett_session_factory()

        self.field_array = []

    def get_table_field(self, dbname, tablename):
        sql = "SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = '{}' AND TABLE_NAME = '{}'".format(
            dbname, tablename)
        cursor = self.sett_session.execute(sql)
        result = cursor.fetchall()
        for item in result:
            self.field_array.append(item['COLUMN_NAME'])
        return self.field_array

    def get_day_member_data(self, selectlist, db_table, opts):
        data = []
        fields = selectlist.split(',')
        group_opts = fields[0]
        for i in range(1, len(fields)):
            if "sum" not in fields[i]:
                group_opts += ","+fields[i]
        sql = "select {} from {} where {} group by {} limit 100".format(selectlist, db_table, opts, group_opts)
        cursor = self.sett_session.execute(sql)
        result = cursor.fetchall()
        for item in result:
            datadict = {}
            for f in fields:
                datadict[f] = str(item[f]).encode('latin1').decode('gbk')
            data.append(datadict)
        return {'fieldslist': fields, 'day_member_data': data}

    def get_data_count(self, begindate, enddate, table):
        data_dict = {}
        for item in table:
            if "t_pay_provide_data" == item:
                db_table = "{}.{}".format(TABLE_DB_MAP[item], item)
                sql = "select stat_date,count(*) as count from {} where stat_date between '{}' and '{}' group by stat_date".format(
                    db_table, begindate, enddate)
                date_count = {}

                cursor = self.db.session.execute(sql)
                result = cursor.fetchall()
                for it in result:
                    date_count[it["stat_date"]] = it["count"]
                data_dict[item] = date_count
            elif "t_chan_pay_data" == item:
                db_table = "{}.{}".format(TABLE_DB_MAP[item], item)
                sql = "select stat_date,count(*) as count from {} where stat_date between '{}' and '{}' group by stat_date".format(
                    db_table, begindate, enddate)
                date_count = {}

                cursor = self.db.session.execute(sql)
                result = cursor.fetchall()
                for it in result:
                    date_count[it["stat_date"]] = it["count"]
                data_dict[item] = date_count
            elif "t_portal_pay_data" == item:
                db_table = "{}.{}".format(TABLE_DB_MAP[item], item)
                sql = "select stat_date,count(*) as count from {} where stat_date between '{}' and '{}' group by stat_date".format(
                    db_table, begindate, enddate)
                date_count = {}

                cursor = self.db.session.execute(sql)
                result = cursor.fetchall()
                for it in result:
                    date_count[it["stat_date"]] = it["count"]
                data_dict[item] = date_count
            elif "t_provide_pay_data" == item:
                db_table = "{}.{}".format(TABLE_DB_MAP[item], item)
                sql = "select stat_date,count(*) as count from {} where stat_date between '{}' and '{}' group by stat_date".format(
                    db_table, begindate, enddate)
                date_count = {}

                cursor = self.db.session.execute(sql)
                result = cursor.fetchall()
                for it in result:
                    date_count[it["stat_date"]] = it["count"]
                data_dict[item] = date_count
            elif "t_prepay_stat_all" == item:
                db_table = "{}.{}".format(TABLE_DB_MAP[item], item)
                sql = "select Fstat_date,count(*) as count from {} where Fstat_date between '{}' and '{}' group by Fstat_date".format(
                    db_table, begindate.replace("-", ""), enddate.replace("-", ""))
                date_count = {}

                cursor = self.sett_session.execute(sql)
                result = cursor.fetchall()
                for it in result:
                    Fstat_date = it["Fstat_date"][:4] + '-' + it["Fstat_date"][4:6] + "-" + it["Fstat_date"][6:]
                    date_count[Fstat_date] = it["count"]
                data_dict[item] = date_count
            elif "t_acct_consume_data" == item:
                db_table = "{}.{}".format(TABLE_DB_MAP[item], item)
                sql = "select data_date,count(*) as count from {} where data_date between '{}' and '{}' group by data_date".format(
                    db_table, begindate, enddate)
                date_count = {}

                cursor = self.db.session.execute(sql)
                result = cursor.fetchall()
                for it in result:
                    date_count[str(it["data_date"])] = it["count"]
                data_dict[item] = date_count
            elif "t_refund_data_from_water" == item:
                db_table = "{}.{}".format(TABLE_DB_MAP[item], item)
                sql = "select stat_date,count(*) as count from {} where stat_date between '{}' and '{}' group by stat_date".format(
                    db_table, begindate, enddate)
                date_count = {}

                cursor = self.db.session.execute(sql)
                result = cursor.fetchall()
                for it in result:
                    date_count[it["stat_date"]] = it["count"]
                data_dict[item] = date_count
            elif "t_day_balance_dyb" == item:
                db_table = "{}.{}".format(TABLE_DB_MAP[item], item)
                sql = "select stat_date,count(*) as count from {} where stat_date between '{}' and '{}' group by stat_date".format(
                    db_table, begindate, enddate)
                date_count = {}

                cursor = self.sett_session.execute(sql)
                result = cursor.fetchall()
                for it in result:
                    date_count[it["stat_date"]] = it["count"]
                data_dict[item] = date_count
            elif "t_tob_sale_pay_data_from_water" == item:
                db_table = "{}.{}".format(TABLE_DB_MAP[item], item)
                sql = "select stat_date,count(*) as count from {} where stat_date between '{}' and '{}' group by stat_date".format(
                    db_table, begindate, enddate)
                date_count = {}

                cursor = self.db.session.execute(sql)
                result = cursor.fetchall()
                for it in result:
                    date_count[it["stat_date"]] = it["count"]
                data_dict[item] = date_count
        return data_dict

