#!/usr/bin/env python3
# encoding: utf-8
# @Time    : 2022/2/23 12:28 下午
from sqlalchemy.orm import sessionmaker

from app import db
from entity.taskinfo import TaskInfo


class TaskDao(object):
    def __init__(self):
        self.db = db
        self.tj_engine = self.db.get_engine(app=self.db.get_app(), bind="day_db_admin_better")

        self.session_factory = sessionmaker(bind=self.tj_engine)
        self.tj_session = self.session_factory()

    def get_all_task(self):
        print("查询任务")
        task = self.tj_session.query(TaskInfo).all()
        print("查询任务完成")
        return task

    def edit_task(self, task_info):
        task = self.tj_session.query(TaskInfo).filter_by(taskid=task_info["taskid"]).first()
        print('编辑任务')
        task.task_describe = task_info["describe"]
        task.task_path = task_info["path"]
        task.task_order = task_info["order"]
        task.task_begin = task_info["begin"]
        task.task_end = task_info["end"]
        task.task_status = task_info["status"]
        self.tj_session.commit()
        print('编辑任务完成')
        return True

    def add_task(self, task_info):
        print('添加任务')
        task = TaskInfo(task_info["taskid"], task_info["describe"], task_info["path"], task_info["order"], task_info["begin"], task_info["end"], "published")
        self.tj_session.add(task)
        self.tj_session.commit()
        print('添加任务完成')
        return True

    def del_task(self, task_info):
        self.tj_session.query(TaskInfo).filter_by(taskid=task_info["taskid"]).delete()
        self.tj_session.commit()
        return True



