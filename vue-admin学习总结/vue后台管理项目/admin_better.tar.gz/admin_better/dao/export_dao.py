#!/usr/bin/env python3
# coding=utf-8
import sys
import pandas
import sqlalchemy

from app import db
from config import settings

DATA_PATH = "./file_data"


class ExportDao(object):
    def __init__(self):
        self.db = db
        self.tj_engine = sqlalchemy.create_engine(
            "mysql+mysqlconnector://{}:{}@{}:{}".format(
                settings.day_db_config.user, settings.day_db_config.password,
                settings.day_db_config.host, settings.day_db_config.port), encoding='utf8')

        self.sett_engine = sqlalchemy.create_engine(
            "mysql+mysqlconnector://{}:{}@{}:{}".format(
                settings.month_db_config.user, settings.month_db_config.password,
                settings.month_db_config.host, settings.month_db_config.port), encoding='utf8')

        self.tj_engine_latin1 = sqlalchemy.create_engine(
            "mysql+mysqlconnector://{}:{}@{}:{}".format(
                settings.day_db_config.user, settings.day_db_config.password,
                settings.day_db_config.host, settings.day_db_config.port), encoding='latin1')

        self.sett_engine_latin1 = sqlalchemy.create_engine(
            "mysql+mysqlconnector://{}:{}@{}:{}".format(
                settings.month_db_config.user, settings.month_db_config.password,
                settings.month_db_config.host, settings.month_db_config.port), encoding='latin1')

        self.connect_dict = {'sett_db': self.sett_engine, 'tj_db': self.tj_engine,
                             'sett_db_latin1': self.sett_engine,
                             'tj_db_latin1': self.tj_engine}

    def export_execl_data(self, connection, sql):
        db_engine = self.connect_dict[connection]
        out_file_name = "{}/non_mobile_sett.xlsx".format(DATA_PATH)
        writer = pandas.ExcelWriter(out_file_name, mode='w')

        if "latin1" in connection:
            df = pandas.read_sql_query(sql, con=db_engine)
            for index, row in df.iteritems():
                df[index] = df[index].astype(str).str.encode("latin1", "ignore").str.decode("gb18030", "ignore")
            df.to_excel(writer, index=False)
        else:
            df = pandas.read_sql_query(sql, con=db_engine)
            df.to_excel(writer, index=False)

        writer.close()
        return out_file_name

    def export_text_data(self, connection, sql):
        db_engine = self.connect_dict[connection]
        out_file_name = "{}/non_mobile_sett.txt".format(DATA_PATH)
        if "latin1" in connection:
            df = pandas.read_sql_query(sql, con=db_engine)
            for index, row in df.iteritems():
                df[index] = df[index].astype(str).str.encode("latin1", "ignore").str.decode("gb18030", "ignore")
            df.to_csv(out_file_name, index=False)
        else:
            df = pandas.read_sql_query(sql, con=db_engine)
            df.to_csv(out_file_name, index=False)
        return out_file_name


if "__main__" == __name__:

    if len(sys.argv) < 3:
        print("error miss para: {} tme_defer/qq_defer YYYY-MM".format(sys.argv[0]))
        sys.exit()
    task_type = sys.argv[1]
