#!/usr/bin/env python3
# encoding: utf-8
# @Time    : 2022/2/17 2:30 下午
from common.date_tool import getDayAll
from dao.tabledao import TableDao

from util.table_db_map import TABLE_DB_MAP
import time


class GetTableInfo(object):
    def __init__(self):
        self.table_dao = TableDao()

        nowdate10 = time.strftime('%Y-%m-%d', time.localtime(time.time()))
        self.now_date8 = nowdate10.replace("-", "")
        self.now_month6 = nowdate10.replace("-", "")[0:6]

    def get_table_field(self, tablename):
        # 处理包月的按月分区表
        if "YYYYMM" in tablename:
            db_name = TABLE_DB_MAP[tablename]
            table_name = tablename.replace("YYYYMM", "202201")
        else:
            db_name = TABLE_DB_MAP[tablename]
            table_name = tablename
        return self.table_dao.get_table_field(db_name, table_name)

    def get_day_member_data(self, table_name, fields=[], Fstat_date="", Fsett_channel="", Fservice_type=""):
        if len(fields) > 0:
            selectlist = fields[0]
            for i in range(1, len(fields)):
                if "Ffee" == fields[i]:
                    selectlist += "," + "sum(Ffee)"
                else:
                    selectlist += "," + fields[i]
        else:
            selectlist = "Fstat_date,Fsett_channel,Fsett_channel_name,Fservice_type,sum(Ffee)"
        if len(Fstat_date) > 0:
            stat_month = Fstat_date.replace("-", "")[0:6]
            stat_day = Fstat_date.replace("-", "")
            tablename = table_name.replace("YYYYMM", stat_month)
        else:
            # stat_month = self.now_month6
            # stat_day = self.now_date8
            stat_month = "202201"
            stat_day = "20220104"
            tablename = table_name.replace("YYYYMM", stat_month)

        dbtable = "{}.{}".format(TABLE_DB_MAP[table_name], tablename)

        if len(Fsett_channel) > 0 and len(Fservice_type) > 0:
            opts = "Fstat_date='{}' and Fsett_channel='{}' and Fservice_type='{}'".format(stat_day, Fsett_channel,
                                                                                          Fservice_type)
        elif len(Fsett_channel) > 0 and len(Fservice_type) == 0:
            opts = "Fstat_date='{}' and Fsett_channel='{}'".format(stat_day, Fsett_channel)
        elif len(Fsett_channel) == 0 and len(Fservice_type) > 0:
            opts = "Fstat_date='{}' and Fservice_type='{}'".format(stat_day, Fservice_type)
        else:
            opts = "Fstat_date='{}'".format(stat_day)
        return self.table_dao.get_day_member_data(selectlist, dbtable, opts)

    def get_many_table_count(self, begindate, enddate):
        table = ["t_provide_pay_data", "t_chan_pay_data",
                 "t_portal_pay_data", "t_pay_provide_data",
                 "t_prepay_stat_all", "t_acct_consume_data",
                 "t_refund_data_from_water", "t_day_balance_dyb",
                 "t_tob_sale_pay_data_from_water"]
        data = self.table_dao.get_data_count(begindate, enddate, table)
        dayall = getDayAll(begindate, enddate)
        data_dict = {}
        for tablename in data:
            data_count = []
            j = 0
            for day in dayall:
                if day in data[tablename]:
                    data_count.append(data[tablename][day])
                else:
                    data_count.append('-')
                j += 1
            data_dict[tablename] = {"date_count": dayall, "data_count": data_count}
        return data_dict
