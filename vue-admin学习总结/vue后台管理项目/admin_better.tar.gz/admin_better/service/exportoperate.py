#!/usr/bin/env python3
# encoding: utf-8
# @Time    : 2022/3/21 10:23 下午

import time


class ExportData(object):
    def __init__(self):
        nowdate10 = time.strftime('%Y-%m-%d', time.localtime(time.time()))
        self.now_date8 = nowdate10.replace("-", "")
        self.now_month6 = nowdate10.replace("-", "")[0:6]

    def run_script(self):
        pass

    def get_file_path(self, connection, sql_template):
        pass
