#!/usr/bin/env python3
# encoding: utf-8
# @Time    : 2022/3/21 3:43 下午
from app import flask_app
from dao.select_dao import SelectDao
import time


class GetSqlData(object):
    def __init__(self):
        self.select_dao = SelectDao()

        nowdate10 = time.strftime('%Y-%m-%d', time.localtime(time.time()))
        self.logger = flask_app.logger
        self.now_date8 = nowdate10.replace("-", "")
        self.now_month6 = nowdate10.replace("-", "")[0:6]

    def get_sql_result(self, connection, sql_template):
        result = self.select_dao.get_select_data(connection, sql_template)
        return result


