#!/usr/bin/env python3
# encoding: utf-8
# @Time    : 2022/1/24 2:55 下午

from dao.userdao import UserDao
from util.token_util import generate_auth_token, verify_auth_token


class UserLogin(object):
    def __init__(self, ):
        self.user_dao = UserDao()

    def verify_login(self, username, password):
        user_info = self.user_dao.get_user_info(username)
        db_password = user_info.get_password()
        if len(password) != 0 and password == db_password:
            # 验证成功生成token
            token = generate_auth_token(username)
            # token 存入数据库
            self.user_dao.update_user_token(username, token)
            return token
        else:
            return "False"

    def verify_token(self, token):
        # 解析token
        result = verify_auth_token(token)
        if result:
            username = result["username"]
            user = self.user_dao.get_user_info(username)
            return user
        else:  # token验证失败
            return False


if __name__ == '__main__':
    UserLogin().verify_login("felixsfan", "felixsfan")
