#!/usr/bin/env python3
# encoding: utf-8
# @Time    : 2022/2/23 12:29 下午
from dao.taskdao import TaskDao


class TaskOperate(object):
    def __init__(self):
        self.task_dao = TaskDao()

    def get_all_task(self):
        result = self.task_dao.get_all_task()
        task_all = []
        for task in result:
            task_all.append({"taskid": task.taskid, "describe": task.task_describe, "path": task.task_path,
                             "order": task.task_order, "begin": task.task_begin,
                             "end": task.task_end,
                             "status": task.task_status})  # key和前端字段名字保持一致
        return task_all

    def edit_task(self, task_info):
        return self.task_dao.edit_task(task_info)

    def add_task(self, task_info):
        return self.task_dao.add_task(task_info)

    def del_task(self, task_info):
        return self.task_dao.del_task(task_info)
