package com.atguigu.bigdata.spark.core.framework.dao

import com.atguigu.bigdata.spark.core.framework.common.TDao

// 持久层
class WordCountDao extends TDao{

}
