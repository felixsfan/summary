package com.atguigu.bigdata.spark.core

object Test {

    def main(args: Array[String]): Unit = {

        println("Hello Spark")

    }
}
