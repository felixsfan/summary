package com.atguigu.bigdata.spark.core.framework.common

trait TController {
    def dispatch(): Unit
}
