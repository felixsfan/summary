package com.atguigu.bigdata.spark.core.framework.common

trait TService {
    def dataAnalysis():Any
}
